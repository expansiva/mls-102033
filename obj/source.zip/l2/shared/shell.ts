/// <mls fileReference="_102033_/l2/shared/shell.ts" enhancement="_blank" />
import type { MasterFrontendBootConfig } from '/_102029_/l2/contracts/bootstrap.js';
import type {
  MasterFrontendAsideMode,
  MasterFrontendBlockingErrorState,
  MasterFrontendDeviceKind,
  MasterFrontendDynamicRegionConfig,
  MasterFrontendInteractionState,
  MasterFrontendRegionName,
  MasterFrontendRegionRendererConfig,
  MasterFrontendRouteDefinition,
} from '/_102033_/l2/shared/contracts/bootstrap.js';
import { asideProjectId } from '/_102033_/l2/shared/layout/aura-aside.js';
import '/_102033_/l2/shared/layout/aura-header.js';
import {
  AURA_CLOSE_ASIDE_EVENT,
  AURA_OPEN_ASIDE_EVENT,
  AURA_TOGGLE_ASIDE_EVENT,
} from '/_102033_/l2/shared/layout/aura-shell-events.js';
import {
  bindExpectedNavigationLoad,
  clearBlockingError,
  consumeExpectedNavigationLoad,
  retryBlockingError,
  subscribeToInteractionState,
} from '/_102033_/l2/shared/interactionRuntime.js';
import {
  getNextRuntimeLanguage,
  getRuntimeLanguage,
  listRuntimeLanguages,
  setRuntimeLanguage,
} from '/_102033_/l2/shared/languageRuntime.js';
import {
  designSystemProjectId,
  getNextRuntimeDesignSystem,
  getRuntimeDesignSystem,
  listRuntimeDesignSystems,
  setRuntimeDesignSystem,
} from '/_102033_/l2/shared/designSystemRuntime.js';
import { getCollabRouteChunkCache, loadAuraRouteChunk, matchAuraRoute } from '/_102033_/l2/shared/routeRuntime.js';
import { isInternalModuleHref } from '/_102033_/l2/shared/layout/auraNavigate.js';
import {
  findModuleTabForPath,
  isTabPinned,
  pinnedTabRoute,
  moduleTabOpenActivates,
  mountModuleTabOnActivate,
  pinBasePathForTab,
  rememberShellRoute,
  restorePinnedModuleTabs,
  revealModuleTabForLocation,
  settleClosedContentTab,
  syncHistoryForContentTab,
  toggleModuleTabPin,
} from '/_102033_/l2/shared/moduleTab.js';
import { siteProjectFromBoot } from '/_102033_/l2/shared/siteProject.js';
import { MOBILE_BREAKPOINT_PX } from '/_102033_/l2/shared/breakpoints.js';
import { describeContentPageGenomeChange } from '/_102033_/l2/shared/contentPageGenome.js';
import { describeContentPageDeviceChange } from '/_102033_/l2/shared/contentPageDevice.js';
import { rememberElementSwapForNextBoot } from '/_102033_/l2/shared/elementSwapRegistry.js';
import { NAV3_TAB_CHANGE_EVENT, activeTabHost, tabChanged, type IAnnouncedTab, type INav3TabChange } from '/_102033_/l2/shared/nav3ActiveTab.js';
import { onStudioExit, readCollabReleaseId, rememberRelease } from '/_102033_/l2/cbe/studioExitReload.js';
import { enterStudioTheme, leaveStudioTheme } from '/_102033_/l2/cbe/studioTheme.js';
import { contentDevice, isStudioDevice, readStudioDevice, rememberStudioDevice, type StudioDevice } from '/_102033_/l2/cbe/studioDevice.js';
import {
  applyCollabModeNotice,
  enterDraft,
  loadRecordedMode,
  postDraftEnter,
  requestModeChange,
  resolveDefaultDraftFromMls,
  sendServiceWorkerMode,
  type CollabRunMode,
} from '/_102033_/l2/cbe/studioDraft.js';
import { contentPageGenomeToPreserve } from '/_102033_/l2/shared/contentPageGenomePreserve.js';
import {
  attachViewportMsizeListeners,
  createCoalescedRunner,
  msizeForRect,
  writeMsize,
} from '/_102033_/l2/shared/regionMsize.js';
import { nextTopBandState, type TopBandState } from '/_102033_/l2/shared/topBandScroll.js';
import { initialMobilePane, otherMobilePane, type MobilePane } from '/_102033_/l2/shared/mobilePane.js';
import { createSitesMenuControls } from '/_102033_/l2/cbe/sitesMenu.js';
import { LitElement, html } from 'lit';

/** Pin number encoded in `mod-<base>#n`. The free tab, including `app`, has none. */
export function contentTabPinNumber(tabId: string): number | undefined {
  const match = /#(\d+)$/u.exec(tabId);
  if (!match) return undefined;
  const number = Number(match[1]);
  return number > 0 ? number : undefined;
}

/** Pinned tabs show the module title plus the pin order. */
export function contentTabLabel(title: string, tabId: string): string {
  const number = contentTabPinNumber(tabId);
  if (!number) return title;
  const suffix = ` #${number}`;
  return title.endsWith(suffix) ? title : `${title}${suffix}`;
}

/** The pin mark unpins; the close mark closes. */
export function contentTabMarkAction(tabId: string): 'unpin' | 'close' {
  return contentTabPinNumber(tabId) ? 'unpin' : 'close';
}

const tabMarkLabels: Record<string, { unpin: string; close: string }> = {
  en: { unpin: 'Unpin', close: 'Close' },
  pt: { unpin: 'Desafixar', close: 'Fechar' },
};

export function contentTabMarkTitle(tabId: string, language: string): string {
  const code = language.toLowerCase().startsWith('pt') ? 'pt' : 'en';
  return contentTabMarkAction(tabId) === 'unpin' ? tabMarkLabels[code].unpin : tabMarkLabels[code].close;
}

function traceLazy(event: string, details?: Record<string, unknown>) {
  if (!window.isTraceLazy) {
    return;
  }
  console.log('[traceLazy][shell]', event, details ?? {});
}

/** Same name the draft panel dispatches. No import between 102020 and 102033. */
export const COLLAB_DRAFT_SAVED = 'collabDraftSaved';

export interface CollabDraftSavedDetail {
  project: number;
  paths: string[];
}

type StudioAside = HTMLElement & {
  syncStudioNavigation?: (studioOn: boolean) => Promise<void>;
};

const SITE_CONFIG_PATH = 'l5/config.json';

function asDraftSavedDetail(value: unknown): CollabDraftSavedDetail | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as { project?: unknown; paths?: unknown };
  if (typeof record.project !== 'number' || !Number.isInteger(record.project)) return null;
  if (!Array.isArray(record.paths)) return null;
  const paths: string[] = [];
  for (const path of record.paths) {
    if (typeof path !== 'string') return null;
    paths.push(path);
  }
  return { project: record.project, paths };
}

/** True when this send wrote the site's `l5/config.json` while Studio is on. */
export function draftSavedShouldRefresh(
  detail: CollabDraftSavedDetail,
  studioOn: boolean,
  siteProject: number | null,
): boolean {
  if (!studioOn) return false;
  if (siteProject === null) return false;
  if (detail.project !== siteProject) return false;
  return detail.paths.includes(SITE_CONFIG_PATH);
}

/**
 * Listen for a successful draft send. `mls.stor.setContents` is a read-only lib export, so it
 * cannot be wrapped; the panel dispatches `collabDraftSaved` after `afterDraftSave`.
 */
export function attachCollabDraftSavedWatch(
  target: EventTarget,
  onSaved: (detail: CollabDraftSavedDetail) => void,
): () => void {
  const listener = (event: Event): void => {
    const detail = asDraftSavedDetail((event as CustomEvent<unknown>).detail);
    if (!detail) {
      console.error('[shell] collabDraftSaved detail is invalid; aside was not reread');
      return;
    }
    onSaved(detail);
  };
  target.addEventListener(COLLAB_DRAFT_SAVED, listener);
  return () => {
    target.removeEventListener(COLLAB_DRAFT_SAVED, listener);
  };
}

function isAuraBootConfig(value: unknown): value is MasterFrontendBootConfig {
  if (!value || typeof value !== 'object') {
    return false;
  }

  const candidate = value as Record<string, unknown>;
  return (
    typeof candidate.projectId === 'string' &&
    typeof candidate.moduleId === 'string' &&
    typeof candidate.basePath === 'string' &&
    typeof candidate.shellMode === 'string' &&
    typeof candidate.device === 'string' &&
    Array.isArray(candidate.routes)
  );
}

type AuraDynamicRegionName = Exclude<MasterFrontendRegionName, 'content'>;
type AuraRegionRendererState = MasterFrontendRegionRendererConfig & { fallback?: boolean };
type AuraContentRenderer = { tag: string; entrypoint: string };
type AuraRegionElement = HTMLElement & {
  bootConfig?: MasterFrontendBootConfig;
  regionProps?: Record<string, unknown>;
};
type AuraSitesControls = {
  register?: (impl: Record<string, unknown>) => void;
  getLanguage?: () => string | undefined;
  setLanguage?: (language: string) => void;
  listLanguages?: () => string[];
  getDS?: () => string | undefined;
  setDS?: (designSystem: string) => Promise<void>;
  listDS?: () => string[];
  getMode?: () => CollabRunMode;
  setMode?: (mode: CollabRunMode) => Promise<void>;
  getDevice?: () => MasterFrontendDeviceKind;
  setDevice?: (device: MasterFrontendDeviceKind) => Promise<boolean>;
  getMenu?: () => Promise<unknown[]>;
  updateMenu?: () => void;
};

const DEFAULT_REGION_TAGS: Record<Exclude<MasterFrontendRegionName, 'content'>, string> = {
  header: 'collab-aura-header',
  aside: 'collab-aura-aside',
};

export class CollabAuraShell extends LitElement {
  static properties = {
    bootConfig: { attribute: false },
    statusMessage: { state: true },
    routeStatusMessage: { state: true },
    interactionState: { attribute: false },
    resolvedDevice: { state: true },
    isAsideOpen: { state: true },
    activeRoute: { attribute: false },
    contentTabs: { state: true },
    activeContentTabId: { state: true },
    appTabOpen: { state: true },
  };

  declare bootConfig?: MasterFrontendBootConfig;
  declare statusMessage: string;
  routeStatusMessage = '';
  interactionState: MasterFrontendInteractionState = {
    busy: false,
    busyPhase: 'idle',
    clearContentWhileBusy: false,
  };
  resolvedDevice: MasterFrontendDeviceKind = 'desktop';
  // The page variant the studio picked (Desktop | Mobile), only while studio mode is on. It moves the
  // PAGE only: the layout keeps following `resolvedDevice`, or the studio split would fold into one pane.
  private studioDevicePick: StudioDevice | null = null;
  isAsideOpen = false;
  activeRoute?: MasterFrontendRouteDefinition;
  private mobileMediaQuery?: MediaQueryList;
  private detachViewportMsizeListeners?: () => void;
  private readonly regionMsizeCoalesce = createCoalescedRunner(
    () => this.syncAllHostedMsize(),
    (cb) => requestAnimationFrame(cb),
    (id) => cancelAnimationFrame(id),
  );
  private unsubscribeInteraction?: () => void;
  private dynamicRegionRenderers: Partial<Record<AuraDynamicRegionName, AuraRegionRendererState>> = {};
  private dynamicRegionProps: Partial<Record<AuraDynamicRegionName, Record<string, unknown>>> = {};
  private activeAsideWidthPx?: number;
  // Fixed header band height from the active header profile (heightPx). When every
  // header profile declares the same value, switching profiles (e.g. client app
  // header <-> studio nav1/nav2/nav3, Ctrl+Alt+S) causes zero layout shift.
  private activeHeaderHeightPx?: number;
  // ── Unified nav3: the content region hosts N tabs. Tab 'app' is the client app.
  // The outer shell always shows the bar (one tab is enough). An embedded shell
  // stays content-only. `appTabOpen` hides the app tab until a route of this
  // module opens it again, or until it was the last tab and comes back at basePath.
  declare contentTabs: Array<{ id: string; title: string; element: HTMLElement; closable: boolean }>;
  declare activeContentTabId: string;
  appTabOpen = true;
  /** The tab on screen as last announced with NAV3_TAB_CHANGE_EVENT. */
  private announcedTab: IAnnouncedTab<HTMLElement> | null = null;
  // ── Progressive upgrade to the on.collab.codes structure (option C final):
  // after first paint, the shell mounts collab-page>nav1+spliter[nav2+nav3 × 2]
  // in background and the runtime services adopt the aside/content panels.
  // Production vs studio differs ONLY in the top 66px: the client banner is a
  // fixed overlay covering nav1+nav2; Ctrl+Alt+S hides/shows the banner.
  private structureUpgraded = false;
  private structureUpgradeFailed = false;
  private studioModeOn = false;
  private structureUpgradeAttempted = false;
  // Bumped when a service-worker broadcast arrives, so an in-flight setMode does not
  // apply a stale reply over the mode the other tabs already published.
  private modeEpoch = 0;
  // Set once this tab asks for a mode, so the boot `getMode` does not paint over it.
  private modeChosenLocally = false;
  // The mode that arrived before the structure was upgraded; applied right after it.
  private pendingStudioOn: boolean | undefined;
  private modeChain: Promise<void> = Promise.resolve();
  private stopConfigWatch: (() => void) | undefined;
  /** Set when the aside should be told the current mode; cleared once the element accepts it. */
  private asideNavPending = false;
  private reportedMissingProject = false;
  private structureRetriesLeft = 67;
  // Phone: the same structure shows one nav3 at a time (mobilePane.ts). The header's ☰ — the aside
  // toggle of the classic layout — switches between them; navigating shows the app.
  private mobilePane: MobilePane = 'messages';
  // Last layout handed to the spliter (device|pane|studio), so updated() re-applies only on change.
  private appliedStructureLayout = '';
  // ── Top band scroll (rt37): on mobile, with the structure upgraded, the 66px band (client
  // banner + collab-nav-1/2) hides on a sustained scroll-down and returns on a sustained
  // scroll-up — the Chrome address-bar behavior. The decision itself is pure (topBandScroll.ts);
  // this is just the DOM wiring (listener + attribute + the one layout() per state change).
  private topBandState: TopBandState = 'visible';
  private topBandAccumulated = 0;
  private topBandLastScrollTop = 0;
  private topBandLastTarget: EventTarget | null = null;
  private topBandListenerAttached = false;
  private topBandScrollHost: HTMLElement | null = null;
  // Set once the classic header/aside/content regions have mounted (see
  // mountModuleRoot) — the structure upgrade adopts those DOM nodes, so it
  // must not run ahead of them.
  private regionsMounted = false;
  // Embedded (iframe) mode: foreign modules opened as nav3 content tabs by the
  // unified shell (openProgramUnified). The OUTER shell already provides
  // navigation (Apps menu) and framing — rendering this module's own header +
  // aside/hamburger would show its item menu twice on screen, so the frame is
  // content-only. Also gates the structure upgrade (no nested mini-studio).
  private readonly isEmbedded = (() => {
    try { return window.self !== window.top; } catch { return true; }
  })();
  // Ctrl+Alt+E cycles the content page through its UX variants (genome page11 -> page21 -> page31 ...).
  // Ctrl+Alt+L cycles the configured runtime languages.
  // Ctrl+Alt+D cycles the configured runtime design systems.
  // mls.sites.setPage(n) sets one directly. Override the content renderer with the picked variant;
  // navigation preserves the current genome when the next route has the same pageNN variant.
  private contentVariantRenderer?: AuraContentRenderer & { routeKey: string };
  private sitesRetryTimer?: ReturnType<typeof setTimeout>;
  // Bounded retry (~20s at 300ms) matching cbeMiniCfe's mls-lib load window.
  private sitesRetriesLeft = 67;

  createRenderRoot() {
    return this;
  }

  connectedCallback() {
    super.connectedCallback();
    // Drop the retired draft cookie once on boot. No /desenv/sair and no reload.
    document.cookie = 'collab-draft=; Max-Age=0; Path=/';
    if (!isAuraBootConfig(window.collabBoot)) {
      this.statusMessage = 'Invalid or missing window.collabBoot.';
      return;
    }

    this.bootConfig = window.collabBoot;
    this.resolvedDevice = this.resolveDevice();
    this.mobilePane = initialMobilePane(window.location.pathname, this.bootConfig.basePath);
    this.isAsideOpen = this.getDefaultAsideOpen(this.resolvedDevice);
    this.contentTabs = [];
    this.activeContentTabId = 'app';
    this.appTabOpen = true;
    this.initializeDynamicRegions();
    window.collabMasterFrontendShellControls = {
      toggleAside: this.handleToggleAside,
      openAside: this.handleOpenAside,
      closeAside: this.handleCloseAside,
      setHeaderRenderer: this.setHeaderRenderer,
      setAsideRenderer: this.setAsideRenderer,
      setShellProfile: this.setShellProfile,
    };
    // Unified nav3 tab API — for the shell's own pages, the collab-messages
    // environment (Detail tab) and, later, studio services.
    window.collabRuntimeNav3 = {
      // Contract types element as unknown (DOM-free for backend consumers);
      // the implementation validates it is an HTMLElement.
      openTab: (tab) => this.openContentTab(tab as { id: string; title: string; element: HTMLElement; closable?: boolean }),
      closeTab: this.closeContentTab,
      activateTab: this.activateContentTab,
      listTabs: () => [
        ...(this.appTabOpen ? ['app'] : []),
        ...this.contentTabs.map((tab) => tab.id),
      ],
      activeTab: () => this.activeContentTabId,
      activeTabElement: () => this.activeContentTabElement(),
      togglePin: this.toggleContentTabPin,
      isPinned: (id) => isTabPinned(
        id,
        this.bootConfig?.basePath ?? '',
        `${window.location.pathname}${window.location.search}${window.location.hash}`,
      ),
    };
    this.registerSitesControls();
    this.ensureConfigWatch();
    setTimeout(() => this.maybeUpgradeStructure(), 1200);
    this.mobileMediaQuery = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT_PX}px)`);
    this.mobileMediaQuery.addEventListener('change', this.handleViewportChange);
    this.detachViewportMsizeListeners = attachViewportMsizeListeners(window, this.handleViewportChange);
    window.addEventListener(AURA_TOGGLE_ASIDE_EVENT, this.handleToggleAside as EventListener);
    window.addEventListener(AURA_OPEN_ASIDE_EVENT, this.handleOpenAside as EventListener);
    window.addEventListener(AURA_CLOSE_ASIDE_EVENT, this.handleCloseAside as EventListener);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('popstate', this.handlePopState);
    navigator.serviceWorker?.addEventListener('message', this.handleServiceWorkerMode);
    void this.adoptRecordedMode();
    this.unsubscribeInteraction = subscribeToInteractionState((state) => {
      this.interactionState = state;
      this.requestUpdate();
    });
    void this.mountModuleRoot();
  }

  disconnectedCallback() {
    this.stopConfigWatch?.();
    this.stopConfigWatch = undefined;
    if (this.sitesRetryTimer) {
      clearTimeout(this.sitesRetryTimer);
      this.sitesRetryTimer = undefined;
    }
    delete window.collabMasterFrontendShellControls;
    delete window.collabRuntimeNav3;
    this.detachViewportMsizeListeners?.();
    this.detachViewportMsizeListeners = undefined;
    this.regionMsizeCoalesce.cancel();
    this.mobileMediaQuery?.removeEventListener('change', this.handleViewportChange);
    window.removeEventListener(AURA_TOGGLE_ASIDE_EVENT, this.handleToggleAside as EventListener);
    window.removeEventListener(AURA_OPEN_ASIDE_EVENT, this.handleOpenAside as EventListener);
    window.removeEventListener(AURA_CLOSE_ASIDE_EVENT, this.handleCloseAside as EventListener);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('popstate', this.handlePopState);
    navigator.serviceWorker?.removeEventListener('message', this.handleServiceWorkerMode);
    this.unsubscribeInteraction?.();
    this.topBandScrollHost?.removeEventListener('scroll', this.handleTopBandScroll, true);
    super.disconnectedCallback();
  }

  private async mountModuleRoot() {
    if (!this.bootConfig) {
      return;
    }

    try {
      await Promise.all([
        this.importRegion('header'),
        this.importRegion('aside'),
      ]);
      await restorePinnedModuleTabs();
      await this.loadActiveRoute();
      this.regionsMounted = true;
      this.requestUpdate();
    } catch (error) {
      this.statusMessage = error instanceof Error ? error.message : String(error);
    }
  }

  private readonly handleViewportChange = () => {
    this.syncResolvedDevice();
    this.scheduleRegionMsizeSync();
  };

  private readonly handleToggleAside = () => {
    this.syncResolvedDevice();
    // Phone, structure up: the ☰ is the only way back to the menu (the classic `.body`/aside is
    // hidden under the structure) — it alternates the visible pane instead of a drawer. Decided
    // BEFORE the early return below, which would swallow it on a module that hides its own aside.
    if (this.usesMobilePanes()) {
      this.showMobilePane(otherMobilePane(this.mobilePane));
      return;
    }
    const asideMode = this.getResolvedAsideMode();
    if (asideMode === 'inline' || !this.getBaseRegionVisibility('aside')) {
      return;
    }
    this.isAsideOpen = !this.isAsideOpen;
    this.requestUpdate();
  };

  private readonly handleOpenAside = () => {
    this.syncResolvedDevice();
    if (this.usesMobilePanes()) {
      this.showMobilePane('messages');
      return;
    }
    if (this.getResolvedAsideMode() === 'inline' || !this.getBaseRegionVisibility('aside')) {
      return;
    }
    this.isAsideOpen = true;
    this.requestUpdate();
  };

  private readonly handleCloseAside = () => {
    this.syncResolvedDevice();
    // Picking something off the APPS menu closes the aside in the classic layout (aura-aside.ts);
    // the same "menu was just used" signal shows the app pane on a phone (openProgramUnified).
    if (this.usesMobilePanes()) {
      this.showMobilePane('app');
      return;
    }
    if (this.getResolvedAsideMode() === 'inline') {
      return;
    }
    this.isAsideOpen = false;
    this.requestUpdate();
  };

  // The structure on a phone, in client mode — studio mode keeps the studio level's own split.
  private usesMobilePanes(): boolean {
    return this.structureUpgraded && !this.studioModeOn && this.resolvedDevice === 'mobile';
  }

  private showMobilePane(pane: MobilePane): void {
    if (pane === this.mobilePane) return;
    this.mobilePane = pane;
    // rt37: the newly-shown pane never starts with the top band already hidden.
    this.showTopBand();
    this.requestUpdate();
  }

  /**
   * Hands the client layout to the spliter when what decides it changed: the device, the phone's
   * pane, or the way back from studio mode. Reads the attributes updated() just wrote (applyRuntimeSplit
   * takes them from the shell), so it runs from there.
   */
  private syncStructureLayout(): void {
    if (!this.structureUpgraded) return;
    const layout = `${this.resolvedDevice}|${this.mobilePane}|${this.studioModeOn}`;
    if (layout === this.appliedStructureLayout) return;
    this.appliedStructureLayout = layout;
    if (this.studioModeOn) return;
    const host = this.querySelector('.studio-structure-host');
    if (!host) return;
    void import('/_102033_/l2/cbe/studioSplit.js')
      .then((module) => (module as { applyRuntimeSplit?: (host: ParentNode) => void }).applyRuntimeSplit?.(host))
      .catch((error) => console.warn('[aura-shell] could not sync the structure layout', error));
  }

  private readonly setHeaderRenderer = async (
    renderer: MasterFrontendRegionRendererConfig,
    props?: Record<string, unknown>,
  ) => {
    await this.setRegionRenderer('header', renderer, props);
  };

  private readonly setAsideRenderer = async (
    renderer: MasterFrontendRegionRendererConfig,
    props?: Record<string, unknown>,
  ) => {
    const widthPx = typeof props?.widthPx === 'number' ? props.widthPx : undefined;
    await this.setRegionRenderer('aside', renderer, props, widthPx);
  };

  private readonly setShellProfile = async (profileName: string) => {
    if (!profileName) {
      return;
    }

    const changes: Array<Promise<void>> = [];
    if (this.getRegionProfile('header', profileName)) {
      changes.push(this.setRegionProfile('header', profileName));
    }
    if (this.getRegionProfile('aside', profileName)) {
      changes.push(this.setRegionProfile('aside', profileName));
    }

    if (changes.length === 0) {
      throw new Error(`Shell profile "${profileName}" is not configured.`);
    }

    if (this.bootConfig?.clientShell) {
      this.bootConfig.clientShell.activeProfile = profileName;
    }

    await Promise.all(changes);
  };

  private async setRegionProfile(region: AuraDynamicRegionName, profileName: string) {
    const profile = this.getRegionProfile(region, profileName);
    if (!profile) {
      return;
    }

    const regionConfig = this.bootConfig?.clientShell?.regions[region];
    if (regionConfig) {
      regionConfig.activeProfile = profileName;
    }

    await this.setRegionRenderer(
      region,
      profile.renderer,
      this.getRegionPropsFromProfile(profile, profileName),
      profile.widthPx,
      profile.heightPx,
    );

    if (region === 'header') this.showRuntimeServices();
  }

  /**
   * Loads Monaco (if not already loaded) and registers the TypeScript definition models of the
   * project chain, so Monaco resolves the cross-project imports through them.
   *
   * Both deferred to the studio switch on purpose: an app user never opens an editor, so neither
   * cost has a reason to be paid at login. Monaco used to download unconditionally for every
   * visitor from cbeMiniCfe.ts — it's claimed here instead now (idempotent either way, so a
   * concurrent load kicked off elsewhere, e.g. a message preview, is just awaited, not repeated).
   */
  /**
   * Hands nav1 the studio services — on the first studio entry only (idempotent per structure).
   *
   * The client boot gives nav1 only the client services: nav1 downloads the code of every service on
   * its list to read its details, so the studio ones would cost every app visitor.
   */
  private loadStudioServices(): void {
    const host = this.querySelector('.studio-structure-host');
    if (!host || !this.structureUpgraded) return;
    const siteProject = siteProjectFromBoot(this.bootConfig);
    void import('/_102033_/l2/cbe/studioStructure.js')
      .then((module) => (module as {
        loadStudioServicesIntoStructure?: (host: ParentNode, siteProject: number) => Promise<void>;
      }).loadStudioServicesIntoStructure?.(host, siteProject))
      .catch((error) => console.warn('[aura-shell] could not load the studio services', error));
  }

  private loadStudioDefinitions(): { monaco: Promise<void>; definitions: Promise<void> } {
    const project = siteProjectFromBoot(this.bootConfig);
    if (!project) {
      return { monaco: Promise.resolve(), definitions: Promise.resolve() };
    }

    type StudioBoot = {
      initStudio?: (mls: unknown) => Promise<void>;
      loadProjectDefinitions?: (project: number) => Promise<void>;
    };
    const boot = import('/_102033_/l2/cbe/initStudio.js').then((module) => module as StudioBoot);

    // Resolves even when Monaco fails, so the Studio level still opens.
    let loaded: StudioBoot | null = null;
    const monaco = boot
      .then(async (mod) => {
        if (window.mls) await mod.initStudio?.(window.mls);
        loaded = mod;
      })
      .catch((error) => {
        console.warn('[aura-shell] monaco failed; studio services shown anyway', error);
        loaded = null;
      });

    const definitions = monaco
      .then(async () => {
        if (!loaded) return;
        await loaded.loadProjectDefinitions?.(project);
      })
      .catch((error) => console.warn('[aura-shell] could not load the project definitions', error));

    return { monaco, definitions };
  }



  /**
   * Puts the client's own services (messages + app) back on the structure's nav3 pair.
   *
   * Called whenever the shell leaves studio mode, by either door: the Ctrl+Alt+S toggle or a
   * header profile switch. No-op while the structure is not up.
   */
  private showRuntimeServices(): void {
    const host = this.querySelector('.studio-structure-host');
    if (!host || !this.structureUpgraded) return;
    void import('/_102033_/l2/cbe/studioStructure.js')
      .then((module) => (module as { showRuntimeServices?: (host: ParentNode) => void }).showRuntimeServices?.(host))
      .catch((error) => console.warn('[aura-shell] could not restore the runtime services', error));
  }

  /**
   * Swaps the spliter between the client layout (messages at 375px, the app taking the rest) and the
   * layout the studio level the user is on prefers.
   *
   * Ctrl+Alt+S used to restore only the nav3 services, so a studio session that ended on l2 dropped
   * the client into the 50/50 that level 2 defaults to. The nav1 tab is deliberately NOT touched:
   * it holds the studio context, and re-entering has to land where the user left.
   */
  private syncStructureSplit(studio: boolean): void {
    const host = this.querySelector('.studio-structure-host');
    if (!host || !this.structureUpgraded) return;
    void import('/_102033_/l2/cbe/studioSplit.js')
      .then((module) => {
        const mod = module as {
          applyRuntimeSplit?: (host: ParentNode) => void;
          restoreStudioSplit?: (host: ParentNode) => void;
        };
        if (studio) mod.restoreStudioSplit?.(host);
        else mod.applyRuntimeSplit?.(host);
      })
      .catch((error) => console.warn('[aura-shell] could not sync the structure split', error));
  }

  // ── Top band scroll (rt37) ──────────────────────────────────────────────

  /**
   * Attaches the capture-phase `scroll` listener once, mobile + structure-upgraded only. Called
   * from both places that can first satisfy that condition: the structure upgrade landing while
   * already on mobile, and a later breakpoint crossing INTO mobile after an upgrade that already
   * happened on desktop. Internally idempotent, so callers never have to check first.
   */
  private maybeAttachTopBandScroll(): void {
    if (this.topBandListenerAttached || this.resolvedDevice !== 'mobile' || !this.structureUpgraded) return;
    const host = this.querySelector('.studio-structure-host') as HTMLElement | null;
    if (!host) return;
    host.addEventListener('scroll', this.handleTopBandScroll, true);
    this.topBandScrollHost = host;
    this.topBandListenerAttached = true;
  }

  // Scroll does not bubble, so this is added in CAPTURE on an ancestor (`.studio-structure-host`)
  // to see it regardless of which descendant panel is actually scrolling (`.nav3-panel`, the
  // collab-messages container, …). Re-checks the mobile/upgraded gate itself (see
  // maybeAttachTopBandScroll) rather than trusting it stays true for the listener's lifetime.
  private readonly handleTopBandScroll = (event: Event): void => {
    if (this.resolvedDevice !== 'mobile' || !this.structureUpgraded) return;
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const scrollTop = target.scrollTop;
    if (target !== this.topBandLastTarget) {
      // First sample from this particular scrolling element — record it, decide nothing (a
      // baseline-less delta would be meaningless and could false-trigger a hide/show).
      this.topBandLastTarget = target;
      this.topBandLastScrollTop = scrollTop;
      return;
    }
    const result = nextTopBandState({
      state: this.topBandState,
      prevScrollTop: this.topBandLastScrollTop,
      scrollTop,
      accumulated: this.topBandAccumulated,
    });
    this.topBandLastScrollTop = scrollTop;
    this.topBandAccumulated = result.accumulated;
    if (result.state !== this.topBandState) {
      this.topBandState = result.state;
      this.applyTopBandState();
    }
  };

  private showTopBand(): void {
    if (this.topBandState === 'visible') return;
    this.topBandState = 'visible';
    this.topBandAccumulated = 0;
    this.applyTopBandState();
  }

  // Flips the `data-top-band` attribute (plain DOM attribute, not a Lit reactive property — the
  // CSS transition reacts to it immediately, no render needed) and runs collab-page.layout() ONCE
  // the transition settles, not per scroll event — the structure host resized (grew/shrank by
  // 66px, see the CSS), and collab-page caches its own size from getBoundingClientRect() (same
  // caveat as the structure upgrade above). `prefers-reduced-motion` skips the animation, so there
  // is no transitionend to wait for — run the remeasure right away instead.
  private applyTopBandState(): void {
    this.setAttribute('data-top-band', this.topBandState);
    const host = this.querySelector('.studio-structure-host') as HTMLElement | null;
    if (!host) return;
    const runLayout = () => {
      (host.querySelector('collab-page') as (HTMLElement & { layout?: () => void }) | null)?.layout?.();
    };
    const prefersReducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    if (prefersReducedMotion) {
      runLayout();
      return;
    }
    host.addEventListener('transitionend', runLayout, { once: true });
  }

  private async setRegionRenderer(
    region: AuraDynamicRegionName,
    renderer: MasterFrontendRegionRendererConfig,
    props?: Record<string, unknown>,
    widthPx?: number,
    heightPx?: number,
  ) {
    if (!renderer.entrypoint || !renderer.tag) {
      throw new Error(`Aura ${region} renderer requires entrypoint and tag.`);
    }

    await loadAuraRouteChunk(renderer.entrypoint);
    this.dynamicRegionRenderers[region] = {
      ...renderer,
      fallback: false,
    };
    this.dynamicRegionProps[region] = props ?? {};
    if (region === 'aside' && typeof widthPx === 'number' && widthPx > 0) {
      this.activeAsideWidthPx = widthPx;
    }
    if (region === 'header' && typeof heightPx === 'number' && heightPx > 0) {
      this.activeHeaderHeightPx = heightPx;
    }
    this.mountRegion(region);
    this.requestUpdate();
  }

  /** Body of Ctrl+Alt+S once the structure is up. The mode change goes through `setMode`. */
  private async toggleStudioMode(): Promise<void> {
    await this.setMode(this.studioModeOn ? 'production' : 'studio');
  }

  /** Monaco and the studio services. Callers decide the mode; this only paints it. */
  private async applyStudioInterface(studioOn: boolean): Promise<void> {
    // The studio level lives in the upgraded structure. A mode that arrives earlier (the boot
    // `getMode`, a broadcast) waits for it, as the boot re-entry always did.
    if (!this.structureUpgraded) {
      this.pendingStudioOn = studioOn;
      return;
    }
    if (this.studioModeOn === studioOn) return;
    this.studioModeOn = studioOn;
    this.requestUpdate();
    if (!this.studioModeOn) {
      // The light/dark switched while editing was the studio's: the app gets its own back.
      leaveStudioTheme();
      this.dropStudioDevice();
      this.refreshAsideNavigation('mode');
      this.showRuntimeServices();
      this.syncStructureSplit(false);
      return;
    }
    // Arms the live update of edited elements — on the NEXT boot, not this one. The stand-in
    // has to be installed before the first `define`, which is long past by the time anyone can
    // press this. So the first studio session on a browser costs one reload; from then on it
    // is already armed.
    rememberElementSwapForNextBoot();
    enterStudioTheme();
    const rememberedDevice = readStudioDevice();
    if (rememberedDevice) void this.setStudioDevice(rememberedDevice);
    const { monaco } = this.loadStudioDefinitions();
    // The studio services (the plugin scan) were left out of the client boot; first entry
    // brings them.
    this.loadStudioServices();
    await monaco;
    // Left during the wait (Ctrl+Alt+S): do not open the studio level.
    if (!this.studioModeOn) return;
    // Back to the level the nav1 never left, with its own split. After Monaco, so the first
    // InitMonaco a remembered service runs is the one initStudio already finished.
    this.syncStructureSplit(true);
    void rememberRelease(readCollabReleaseId);
    // After initStudio, so `l5/config.json` is already in `mls.stor`.
    this.ensureConfigWatch();
    this.refreshAsideNavigation('mode');
  }

  private getMode(): CollabRunMode {
    return this.studioModeOn ? 'studio' : 'production';
  }

  private setMode(mode: CollabRunMode): Promise<void> {
    const run = this.modeChain.then(() => this.commitMode(mode));
    this.modeChain = run.then(
      () => undefined,
      (error: unknown) => {
        console.error('[shell] setMode failed:', error);
      },
    );
    return run;
  }

  private async commitMode(mode: CollabRunMode): Promise<void> {
    if (mode !== 'studio' && mode !== 'production') {
      console.error('[shell] setMode: mode must be studio or production:', mode);
      return;
    }
    this.modeChosenLocally = true;
    const epoch = this.modeEpoch;
    const outcome = await requestModeChange(this.getMode(), mode, {
      project: siteProjectFromBoot(this.bootConfig),
      resolveDraft: resolveDefaultDraftFromMls,
      enterDraft: (project, slug) => enterDraft(project, slug, { postExec: postDraftEnter }),
      sendToServiceWorker: (message) => sendServiceWorkerMode(message),
      reportError: (message) => console.error(message),
    });
    if (epoch !== this.modeEpoch) return;
    const wantOn = outcome.mode === 'studio';
    if (wantOn === this.studioModeOn) return;
    void this.applyStudioInterface(wantOn);
  }

  /**
   * `{action:'getMode'}` once, so this tab is born in the mode the service worker stored.
   * Does not call `setMode` back (that would echo) and does not reload.
   */
  private async adoptRecordedMode(): Promise<void> {
    const epoch = this.modeEpoch;
    const stillCurrent = () => epoch === this.modeEpoch && !this.modeChosenLocally && this.isConnected;
    let state: { mode: CollabRunMode };
    try {
      state = await loadRecordedMode({
        send: (message) => sendServiceWorkerMode(message),
        reportError: (message) => console.error(message),
        reportWarning: (message) => console.warn(message),
        stillCurrent,
      });
    } catch (err) {
      console.error('[shell] getMode failed:', err);
      return;
    }
    if (!stillCurrent()) return;
    if (state.mode === this.getMode()) return;
    void this.applyStudioInterface(state.mode === 'studio');
  }

  /** `{type:'collab-mode'}` from the service worker. Does not call `setMode` back and does not reload. */
  private readonly handleServiceWorkerMode = (event: MessageEvent): void => {
    const next = applyCollabModeNotice(this.getMode(), event.data);
    if (next === this.getMode()) return;
    this.modeEpoch += 1;
    void this.applyStudioInterface(next === 'studio');
  };

  private applyPendingStudioMode(): void {
    const wanted = this.pendingStudioOn;
    this.pendingStudioOn = undefined;
    if (wanted === undefined) return;
    void this.applyStudioInterface(wanted);
  }

  /** Spent before entering, so the reload that follows a draft sync cannot re-enter a second time. */
  private reenterStudioAfterDraftSync(): void {
    if (sessionStorage.getItem('collabStudioReenter') !== '1') return;
    sessionStorage.removeItem('collabStudioReenter');
    void this.toggleStudioMode();
  }

  private readonly handleKeyDown = (event: KeyboardEvent) => {
    if (this.interactionState.busy) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    this.syncResolvedDevice();
    // Ctrl+Alt+E cycles the current page through its UX variants (page11 -> page21 -> page31 -> ...).
    // Match by event.code ('KeyE') because Alt can change event.key to a composed character on some layouts.
    if (event.ctrlKey && event.altKey && !event.shiftKey && !event.metaKey && event.code === 'KeyE') {
      event.preventDefault();
      void this.rotateContentVariant();
      return;
    }
    // Ctrl+Alt+L cycles the configured languages (en -> pt -> ...).
    if (event.ctrlKey && event.altKey && !event.shiftKey && !event.metaKey && event.code === 'KeyL') {
      event.preventDefault();
      this.rotateLanguage();
      return;
    }
    // Ctrl+Alt+D cycles the configured design systems (Default -> Natal -> ...).
    if (event.ctrlKey && event.altKey && !event.shiftKey && !event.metaKey && event.code === 'KeyD') {
      event.preventDefault();
      void this.rotateDesignSystem();
      return;
    }
    // Ctrl+Alt+S toggles the client banner overlay (production covers nav1+nav2; studio reveals
    // them). Below those 66px the DOM is the same either way, but WHICH services the nav3s show and
    // HOW the spliter is divided belong to the mode, and both have to be swapped by hand.
    // Classic layout: rotate header profiles.
    if (event.ctrlKey && event.altKey && !event.shiftKey && !event.metaKey && event.code === 'KeyS') {
      event.preventDefault();
      if (this.structureUpgraded) {
        const leaving = this.studioModeOn;
        void this.toggleStudioMode().then(() => {
          // `applyStudioInterface` already put the client services and the client split back.
          // Reload only when the published release id changed.
          if (leaving && !this.studioModeOn) {
            void onStudioExit(() => location.reload());
          }
        }).catch((error: unknown) => {
          console.error('[shell] setMode failed:', error);
        });
      } else {
        this.rotateHeaderProfile();
      }
      return;
    }
    if (event.key === 'Escape' && this.getResolvedAsideMode() !== 'inline' && this.isAsideOpen) {
      this.isAsideOpen = false;
      this.requestUpdate();
    }
  };

  private readonly handlePopState = () => {
    traceLazy('handlePopState', {
      pathname: window.location.pathname,
    });
    this.syncResolvedDevice();
    if (this.getResolvedAsideMode() !== 'inline') {
      this.isAsideOpen = false;
    }
    // A page was opened (messages' Apps menu, or back/forward): on a phone it has to be the pane on
    // screen.
    if (this.usesMobilePanes()) {
      this.showMobilePane('app');
    }
    // Settle the aside's expected navigation load with the real route load: without this
    // bind the beginExpectedNavigationLoad promise never resolves and every menu
    // navigation ends in a 10s TIMEOUT (no network request involved).
    const pendingLoad = consumeExpectedNavigationLoad();
    const path = window.location.pathname;
    const href = `${path}${window.location.search}${window.location.hash}`;
    const bootBase = this.bootConfig?.basePath ?? '';
    const ownedByBoot = Boolean(bootBase) && isInternalModuleHref(path, bootBase);
    const moduleTab = ownedByBoot ? undefined : findModuleTabForPath(path);
    if (moduleTab) {
      bindExpectedNavigationLoad(pendingLoad, revealModuleTabForLocation(href));
    } else {
      if (ownedByBoot) {
        rememberShellRoute(href);
        if (!this.appTabOpen || this.activeContentTabId.startsWith('mod-')) this.activateContentTab('app');
      }
      bindExpectedNavigationLoad(pendingLoad, this.loadActiveRoute());
    }
    this.requestUpdate();
  };

  private syncResolvedDevice() {
    const nextDevice = this.resolveDevice();
    if (nextDevice === this.resolvedDevice) {
      return;
    }

    this.resolvedDevice = nextDevice;
    this.isAsideOpen = this.getDefaultAsideOpen(nextDevice);
    // Crossing the breakpoint (rotating a tablet, resizing, toggling "request desktop site")
    // swaps the content to the variant of the new device, without a reload. Not while the studio
    // holds a pick: then only the layout follows the width.
    if (this.activeRoute && this.studioDevicePick === null) {
      void this.applyContentPageDevice(nextDevice, true);
    }
    // Which layout the spliter shows (client split or one pane) follows from updated() →
    // syncStructureLayout, since the device is part of its key.
    if (nextDevice === 'mobile') this.maybeAttachTopBandScroll();
    // rt37: crossing the 768px breakpoint always restores the top band — desktop never hides it
    // (no listener runs there), and mobile should not land mid-gesture on whatever state a
    // previous mobile session left behind.
    this.showTopBand();
    this.requestUpdate();
  }

  private resolveDevice(): MasterFrontendDeviceKind {
    if (typeof window.matchMedia === 'function') {
      return window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT_PX}px)`).matches ? 'mobile' : 'desktop';
    }
    return this.bootConfig?.device ?? 'desktop';
  }

  /** The variant the content region mounts: the studio pick while there is one, the width otherwise. */
  private getContentDevice(): MasterFrontendDeviceKind {
    return contentDevice(this.studioDevicePick, this.resolvedDevice);
  }

  /**
   * The studio's Desktop | Mobile switch. Outside studio mode it refuses: the width is the app's rule.
   * False when the variant is missing or did not load — the page stays as it was, and so does the
   * pick (the reason already went to the console). Resolves after the new page is in the DOM, so the
   * caller can read it.
   */
  private async setStudioDevice(device: MasterFrontendDeviceKind): Promise<boolean> {
    if (!this.studioModeOn || !isStudioDevice(device)) return false;
    const previous = this.studioDevicePick;
    this.studioDevicePick = device;
    const ok = this.activeRoute ? await this.applyContentPageDevice(device, true) : true;
    if (!ok) {
      this.studioDevicePick = previous;
      return false;
    }
    rememberStudioDevice(device);
    // The pick is not a reactive property, and without a route nothing else re-renders: the frame needs updated().
    this.requestUpdate();
    await this.updateComplete;
    return true;
  }

  /** Leaving studio mode: the pick goes, and the page goes back to the variant the width asks for. */
  private dropStudioDevice(): void {
    if (this.studioDevicePick === null) return;
    this.studioDevicePick = null;
    if (this.activeRoute) void this.applyContentPageDevice(this.resolvedDevice, true);
    this.requestUpdate();
  }

  private getDefaultAsideOpen(device: MasterFrontendDeviceKind) {
    return this.getAsideModeForDevice(device) === 'inline';
  }

  private initializeDynamicRegions() {
    (['header', 'aside'] as AuraDynamicRegionName[]).forEach((region) => {
      const regionConfig = this.bootConfig?.clientShell?.regions[region];
      const profileName = regionConfig?.activeProfile;
      if (!profileName) {
        return;
      }

      const profile = this.getRegionProfile(region, profileName);
      if (!profile) {
        return;
      }

      this.dynamicRegionRenderers[region] = {
        ...profile.renderer,
        fallback: false,
      };
      this.dynamicRegionProps[region] = this.getRegionPropsFromProfile(profile, profileName);
      if (region === 'aside' && typeof profile.widthPx === 'number' && profile.widthPx > 0) {
        this.activeAsideWidthPx = profile.widthPx;
      }
      if (region === 'header' && typeof profile.heightPx === 'number' && profile.heightPx > 0) {
        this.activeHeaderHeightPx = profile.heightPx;
      }
    });
  }

  private getRegionProfile(region: AuraDynamicRegionName, profileName: string) {
    return this.bootConfig?.clientShell?.regions[region]?.profiles[profileName];
  }

  private getRegionPropsFromProfile(profile: MasterFrontendDynamicRegionConfig, profileName: string): Record<string, unknown> {
    const {
      renderer: _renderer,
      widthPx: _widthPx,
      heightPx: _heightPx,
      source: _source,
      switchWithoutRouteReload: _switchWithoutRouteReload,
      props,
      ...regionProps
    } = profile;

    return {
      ...regionProps,
      ...(props ?? {}),
      profileName,
    };
  }

  private getAsideModeForDevice(device: MasterFrontendDeviceKind): MasterFrontendAsideMode {
    return this.bootConfig?.layout.asideMode[device] ?? (device === 'mobile' ? 'drawer' : 'inline');
  }

  private getResolvedAsideMode(): MasterFrontendAsideMode {
    return this.getAsideModeForDevice(this.resolvedDevice);
  }

  private getAsideWidthPx() {
    return this.activeAsideWidthPx ?? this.bootConfig?.layout.asideSize?.desktopWidthPx ?? 280;
  }

  private getAsideDrawerWidthPx() {
    return this.activeAsideWidthPx ?? this.bootConfig?.layout.asideSize?.drawerWidthPx ?? 320;
  }

  private getRegionProps(region: MasterFrontendRegionName) {
    if (region === 'content') {
      return undefined;
    }
    return this.dynamicRegionProps[region];
  }

  // Effective content renderer: the picked UX variant when set for the current route, else the route default.
  private getActiveContentRenderer(): AuraContentRenderer | undefined {
    if (!this.activeRoute?.entrypoint || !this.activeRoute.tag) {
      return undefined;
    }
    if (this.contentVariantRenderer && this.contentVariantRenderer.routeKey === this.activeRoute.path) {
      return { tag: this.contentVariantRenderer.tag, entrypoint: this.contentVariantRenderer.entrypoint };
    }
    return { tag: this.activeRoute.tag, entrypoint: this.activeRoute.entrypoint };
  }

  private reportContentPageMiss(genome: number, reason: string): false {
    const message = `setPage(${genome}) skipped: ${reason}`;
    console.warn(`[aura-shell] ${message}`);
    this.routeStatusMessage = message;
    this.requestUpdate();
    return false;
  }

  private async applyContentPageGenome(genome: number, shouldMount: boolean): Promise<boolean> {
    const current = this.getActiveContentRenderer();
    const change = describeContentPageGenomeChange(current, genome);
    if (!change.ok) {
      return this.reportContentPageMiss(genome, change.reason);
    }
    if (change.nextTag === current?.tag && change.nextEntrypoint === current?.entrypoint) {
      return true;
    }

    try {
      await loadAuraRouteChunk(change.nextEntrypoint);
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      return this.reportContentPageMiss(genome, `failed to load chunk ${change.nextEntrypoint} (${detail})`);
    }

    if (!customElements.get(change.nextTag)) {
      return this.reportContentPageMiss(genome, `custom element '${change.nextTag}' is not registered`);
    }

    this.contentVariantRenderer = { tag: change.nextTag, entrypoint: change.nextEntrypoint, routeKey: this.activeRoute?.path ?? '' };
    this.routeStatusMessage = '';
    if (shouldMount) {
      this.mountRegion('content');
      this.requestUpdate();
    }
    return true;
  }

  // A missing mobile variant is not a blocking error: the desktop page stays on screen. It is not
  // silent either — the route, the entrypoint tried and the cause go to the console.
  private reportContentPageDeviceMiss(device: MasterFrontendDeviceKind, entrypoint: string, reason: string): false {
    const route = this.activeRoute?.path ?? window.location.pathname;
    console.warn(`[aura-shell] ${device} content variant skipped for route '${route}' (entrypoint ${entrypoint || 'none'}): ${reason} — keeping the desktop page.`);
    return false;
  }

  // Width decides which of the mirrored web/<device>/pageNN variants is mounted. Applied AFTER the
  // genome, so Ctrl+Alt+E and the preserved pageNN keep working on the phone.
  private async applyContentPageDevice(device: MasterFrontendDeviceKind, shouldMount: boolean): Promise<boolean> {
    // syncResolvedDevice cannot await (it is sync and two of its call sites start loadActiveRoute
    // right after), so the route may change while the chunk loads. Writing then would mount the
    // previous route's variant under the new route's key.
    const routeKeyAtStart = this.activeRoute?.path ?? '';
    const current = this.getActiveContentRenderer();
    const change = describeContentPageDeviceChange(current, device);
    if (!change.ok) {
      return this.reportContentPageDeviceMiss(device, change.nextEntrypoint, change.reason);
    }
    if (change.nextTag === current?.tag && change.nextEntrypoint === current?.entrypoint) {
      return true;
    }

    try {
      await loadAuraRouteChunk(change.nextEntrypoint);
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      return this.reportContentPageDeviceMiss(device, change.nextEntrypoint, `failed to load chunk (${detail})`);
    }

    if (!customElements.get(change.nextTag)) {
      return this.reportContentPageDeviceMiss(device, change.nextEntrypoint, `custom element '${change.nextTag}' is not registered`);
    }

    if ((this.activeRoute?.path ?? '') !== routeKeyAtStart) {
      return this.reportContentPageDeviceMiss(device, change.nextEntrypoint, `route changed to '${this.activeRoute?.path ?? 'none'}' while the chunk was loading`);
    }

    this.contentVariantRenderer = { tag: change.nextTag, entrypoint: change.nextEntrypoint, routeKey: routeKeyAtStart };
    if (shouldMount) {
      this.mountRegion('content');
      this.requestUpdate();
    }
    return true;
  }

  // Ordered UX layout indices from the config (project.json/config.json "layouts"); falls back to 1..3.
  private getAvailableUxLayouts(): number[] {
    const layouts = (this.bootConfig as { layouts?: Record<string, unknown> } | undefined)?.layouts
      ?? (window.collabBoot as { layouts?: Record<string, unknown> } | undefined)?.layouts;
    if (layouts && typeof layouts === 'object') {
      const indices = Object.keys(layouts)
        .map((key) => Number(key))
        .filter((value) => Number.isInteger(value) && value >= 1)
        .sort((left, right) => left - right);
      if (indices.length > 0) {
        return indices;
      }
    }
    return [1, 2, 3];
  }

  private listLanguages(): string[] {
    return listRuntimeLanguages(this.bootConfig?.languages);
  }

  private getLanguage(): string | undefined {
    return getRuntimeLanguage(this.listLanguages(), document.documentElement.lang);
  }

  private setLanguage(language: string): void {
    setRuntimeLanguage(language, this.listLanguages());
  }

  private rotateLanguage(): void {
    const languages = this.listLanguages();
    const nextLanguage = getNextRuntimeLanguage(languages, document.documentElement.lang);
    if (nextLanguage) {
      this.setLanguage(nextLanguage);
    }
  }

  private listDS(): string[] {
    return listRuntimeDesignSystems(this.bootConfig?.designSystems);
  }

  private getDS(): string | undefined {
    return getRuntimeDesignSystem(this.listDS());
  }

  private async setDS(designSystem: string): Promise<void> {
    const projectId = designSystemProjectId(this.bootConfig);
    if (!projectId) {
      throw new Error('mls.sites.setDS: runtime project is not available.');
    }
    await setRuntimeDesignSystem(designSystem, this.listDS(), projectId);
  }

  private async rotateDesignSystem(): Promise<void> {
    const designSystems = this.listDS();
    const nextDesignSystem = getNextRuntimeDesignSystem(designSystems, this.getDS());
    if (!nextDesignSystem) {
      return;
    }
    try {
      await this.setDS(nextDesignSystem);
    } catch (error) {
      console.warn('[shell] design system switch failed:', error);
    }
  }

  // Cycle the content page to the next existing UX variant (rotative). A variant exists when its
  // module chunk loads and its custom element is registered; missing variants are skipped.
  private async rotateContentVariant(): Promise<void> {
    const current = this.getActiveContentRenderer();
    if (!current) {
      return;
    }
    const genomeMatch = current.tag.match(/--page(\d)(\d)--/);
    if (!genomeMatch) {
      return;
    }
    const currentUx = Number(genomeMatch[1]);
    const uiDigit = genomeMatch[2];
    const uxList = this.getAvailableUxLayouts();
    if (uxList.length <= 1) {
      return;
    }
    const startIndex = Math.max(0, uxList.indexOf(currentUx));
    for (let step = 1; step <= uxList.length; step++) {
      const nextUx = uxList[(startIndex + step) % uxList.length];
      if (nextUx === currentUx) {
        continue;
      }
      const nextTag = current.tag.replace(/--page\d\d--/, `--page${nextUx}${uiDigit}--`);
      const nextEntrypoint = current.entrypoint.replace(/\/page\d\d\//, `/page${nextUx}${uiDigit}/`);
      if (nextTag === current.tag || nextEntrypoint === current.entrypoint) {
        continue;
      }
      try {
        await loadAuraRouteChunk(nextEntrypoint);
      } catch {
        continue;
      }
      if (!customElements.get(nextTag)) {
        continue;
      }
      this.contentVariantRenderer = { tag: nextTag, entrypoint: nextEntrypoint, routeKey: this.activeRoute?.path ?? '' };
      this.routeStatusMessage = '';
      this.mountRegion('content');
      this.requestUpdate();
      return;
    }
  }

  // Inject the console-facing controls into the mls lib (window.mls.sites), so a developer
  // can change header/aside/page/language/design system from devtools. The mls lib loads asynchronously on the
  // runtime VM (cbeMiniCfe injects /libs/mls.js), so retry with a bounded poll until it is
  // present — before it registers, mls.sites getters return undefined and setters are no-ops.
  private readonly registerSitesControls = () => {
    this.sitesRetryTimer = undefined;
    const sites = (window as unknown as {
      mls?: { sites?: AuraSitesControls };
    }).mls?.sites;
    const register = sites?.register;
    if (typeof register === 'function') {
      const languageControls = {
        getLanguage: () => this.getLanguage(),
        setLanguage: (language: string) => this.setLanguage(language),
        listLanguages: () => this.listLanguages(),
      };
      const designSystemControls = {
        getDS: () => this.getDS(),
        setDS: (designSystem: string) => this.setDS(designSystem),
        listDS: () => this.listDS(),
      };
      const modeControls = {
        getMode: () => this.getMode(),
        setMode: (mode: CollabRunMode) => this.setMode(mode),
      };
      const deviceControls = {
        getDevice: () => this.getContentDevice(),
        setDevice: (device: MasterFrontendDeviceKind) => this.setStudioDevice(device),
      };
      const menuControls = createSitesMenuControls();
      register({
        getHeader: () => this.getRegionIndex('header'),
        setHeader: (index: number) => this.setRegionByIndex('header', index),
        getAside: () => this.getRegionIndex('aside'),
        setAside: (index: number) => this.setRegionByIndex('aside', index),
        getPage: () => this.getContentPageGenome(),
        setPage: (genome: number) => { void this.setContentPage(genome); },
        ...languageControls,
        ...designSystemControls,
        ...modeControls,
        ...deviceControls,
        ...menuControls,
      });
      // Compatibility with an already-published mls.js that predates the language/DS/mode
      // forwarders. A future mls.js exposes these itself and this branch is skipped.
      if (sites) {
        sites.getLanguage ??= languageControls.getLanguage;
        sites.setLanguage ??= languageControls.setLanguage;
        sites.listLanguages ??= languageControls.listLanguages;
        sites.getDS ??= designSystemControls.getDS;
        sites.setDS ??= designSystemControls.setDS;
        sites.listDS ??= designSystemControls.listDS;
        sites.getMode ??= modeControls.getMode;
        sites.setMode ??= modeControls.setMode;
        sites.getDevice ??= deviceControls.getDevice;
        sites.setDevice ??= deviceControls.setDevice;
        sites.getMenu ??= menuControls.getMenu;
        sites.updateMenu ??= menuControls.updateMenu;
      }
      return;
    }
    if (this.sitesRetriesLeft <= 0) {
      return; // mls lib never loaded (e.g. lib disabled on this VM) — nothing to register
    }
    this.sitesRetriesLeft -= 1;
    this.sitesRetryTimer = setTimeout(this.registerSitesControls, 300);
  };

  // Ordered profile names for a region, from clientShell.regions[region].profiles in the
  // boot config (config.json). This is the selectable header/aside list mls.sites indexes.
  private getRegionProfileNames(region: AuraDynamicRegionName): string[] {
    const profiles = this.bootConfig?.clientShell?.regions[region]?.profiles;
    return profiles ? Object.keys(profiles) : [];
  }

  // 1-based index of the region's active profile within its profile list, or undefined.
  private getRegionIndex(region: AuraDynamicRegionName): number | undefined {
    const names = this.getRegionProfileNames(region);
    if (names.length === 0) {
      return undefined;
    }
    const active = this.bootConfig?.clientShell?.regions[region]?.activeProfile;
    if (!active) {
      return undefined;
    }
    const index = names.indexOf(active);
    return index >= 0 ? index + 1 : undefined;
  }

  // ── Unified nav3: content tabs ────────────────────────────────────────────

  private readonly openContentTab = (tab: { id: string; title: string; element: HTMLElement; closable?: boolean }): void => {
    if (!tab?.id || tab.id === 'app' || !(tab.element instanceof HTMLElement)) {
      throw new Error('collabRuntimeNav3.openTab: id (!= "app") and element are required.');
    }
    const existing = this.contentTabs.find((entry) => entry.id === tab.id);
    if (existing) {
      existing.title = tab.title || existing.title;
      existing.element = tab.element;
    } else {
      this.contentTabs = [...this.contentTabs, {
        id: tab.id,
        title: tab.title || tab.id,
        element: tab.element,
        closable: tab.closable !== false,
      }];
    }
    if (moduleTabOpenActivates()) this.activeContentTabId = tab.id;
    this.requestUpdate();
  };

  private readonly toggleContentTabPin = (id: string): void => {
    const basePath = pinBasePathForTab(id, this.bootConfig?.basePath ?? '');
    if (!basePath) return;
    const route = id === 'app' || id.startsWith('app#')
      ? `${window.location.pathname}${window.location.search}${window.location.hash}`
      : pinnedTabRoute(id);
    toggleModuleTabPin(basePath, route);
    this.requestUpdate();
  };

  private readonly closeContentTab = (id: string): void => {
    const settled = settleClosedContentTab({
      closedId: id,
      appOpen: this.appTabOpen,
      activeId: this.activeContentTabId,
      tabIds: this.contentTabs.map((tab) => tab.id),
    });
    if (!settled) return;
    this.appTabOpen = settled.appOpen;
    this.contentTabs = this.contentTabs.filter((entry) => settled.tabIds.includes(entry.id));
    this.activeContentTabId = settled.activeId;
    if (settled.reopenInitial) {
      this.reopenAppAtBootRoute();
      return;
    }
    // The URL follows the active tab on EVERY change: open, activate and close.
    if (settled.syncUrl) syncHistoryForContentTab(this.activeContentTabId);
  };

  /** Last tab closed: the app tab comes back on the module root and the URL follows. */
  private reopenAppAtBootRoute(): void {
    this.appTabOpen = true;
    this.activeContentTabId = 'app';
    const initial = this.bootConfig?.basePath || '/';
    rememberShellRoute(initial);
    syncHistoryForContentTab('app');
    void this.loadActiveRoute();
  }

  private renderTabMark(id: string) {
    const language = document.documentElement?.lang ?? 'en';
    const pinned = contentTabMarkAction(id) === 'unpin';
    return html`<span
      class="nav3-tab-close"
      data-pinned=${String(pinned)}
      title=${contentTabMarkTitle(id, language)}
      @click=${(event: Event) => {
        event.stopPropagation();
        if (pinned) this.toggleContentTabPin(id);
        else this.closeContentTab(id);
      }}
    >${pinned
      ? html`<i class="fa-solid fa-thumbtack" aria-label=${contentTabMarkTitle(id, language)}></i>`
      : '×'}</span>`;
  }

  private readonly activateContentTab = (id: string): void => {
    if (id === 'app') {
      this.appTabOpen = true;
    } else if (!this.contentTabs.some((entry) => entry.id === id)) {
      return;
    }
    syncHistoryForContentTab(id);
    this.activeContentTabId = id;
    void mountModuleTabOnActivate(id);
  };

  // Studio nav3 contract for hosted elements: msize="width,height,top,left" +
  // layout() on resize. serviceBase/monaco-based components size themselves
  // from it; plain elements simply ignore the attribute.
  private scheduleRegionMsizeSync(): void {
    this.regionMsizeCoalesce.trigger();
  }

  private syncAllHostedMsize(): void {
    this.syncHostedRegionMsize();
    this.updateContentTabsMsize();
  }

  private syncHostedRegionMsize(): void {
    for (const region of ['header', 'aside', 'content'] as const) {
      const host = this.querySelector(`[data-region-host="${region}"]`) as HTMLElement | null;
      if (!host) continue;
      const rect = host.getBoundingClientRect();
      const msize = msizeForRect(rect);
      if (!msize) continue;
      const target = (host.firstElementChild ?? host) as HTMLElement & { layout?: () => void };
      writeMsize(target, msize);
    }
  }

  private updateContentTabsMsize(): void {
    const panels = this.querySelector('.nav3-panels');
    if (!panels) return;
    const msize = msizeForRect(panels.getBoundingClientRect());
    if (!msize) return;
    for (const tab of this.contentTabs) {
      writeMsize(tab.element as HTMLElement & { layout?: () => void }, msize);
    }
  }

  /** The element the tab on screen hosts (the app region host for `app`). */
  private activeContentTabElement(): HTMLElement | null {
    const appHost = this.querySelector('.nav3-panel-app > [data-region-host="content"]') as HTMLElement | null;
    return activeTabHost(this.activeContentTabId, appHost, this.contentTabs);
  }

  /**
   * After render, so the element is already in its panel: tells whoever follows the page on screen (the Studio edit
   * tools, through serviceClientApp) that the tab, or the element it hosts, changed.
   */
  private announceActiveTab(): void {
    const next = { id: this.activeContentTabId, element: this.activeContentTabElement() };
    if (!tabChanged(this.announcedTab, next)) return;
    this.announcedTab = next;
    window.dispatchEvent(new CustomEvent<INav3TabChange>(NAV3_TAB_CHANGE_EVENT, { detail: { id: next.id } }));
  }

  // After render: make sure each tab panel contains its element (imperative —
  // the elements are caller-owned and must not be re-created by lit).
  private syncContentTabPanels(): void {
    for (const tab of this.contentTabs) {
      const panel = this.querySelector(`.nav3-panel[data-tab="${tab.id}"]`);
      if (panel && tab.element.parentElement !== panel) {
        panel.replaceChildren(tab.element);
      }
    }
    if (this.contentTabs.length > 0) this.updateContentTabsMsize();
  }

  // ── Progressive structure upgrade ────────────────────────────────────────

  private structureRetryPending = false;

  private maybeUpgradeStructure(): void {
    // Phones too: the same structure, one pane at a time (mobilePane.ts).
    if (this.isEmbedded || this.structureUpgradeAttempted || !this.bootConfig) return;
    // Gate on the FULL studio bootstrap (login + cache + preload) — the
    // proven-safe condition. An earlier attempt gated this on just the mls
    // lib being loaded, but when collabMiniCfeReady then landed WHILE the
    // structure's own dynamic-import/whenDefined chain was still in flight
    // (fast/warm-cache runs), the upgrade rendered blank — a race in the
    // shared studio component registration this shell doesn't control.
    // regionsMounted is kept as an extra guard: the upgrade adopts the
    // classic content/aside DOM nodes, so they must already exist.
    const mlsReady = Boolean((window as unknown as { collabMiniCfeReady?: boolean }).collabMiniCfeReady);
    if (!mlsReady || !this.regionsMounted) {
      if (!this.structureRetryPending && this.structureRetriesLeft-- > 0) {
        this.structureRetryPending = true;
        setTimeout(() => { this.structureRetryPending = false; this.maybeUpgradeStructure(); }, 500);
      } else if (this.structureRetriesLeft <= 0) {
        // Gave up waiting — fall back to the classic layout instead of
        // leaving the skeleton on screen forever.
        this.structureUpgradeFailed = true;
        this.requestUpdate();
      }
      return;
    }
    this.structureUpgradeAttempted = true;
    void this.attemptStructureUpgrade();
  }

  // The nav1 -> nav2/nav3 service wiring is itself asynchronous inside the
  // studio components (studioStructure's own applySplit re-applies at 600ms
  // for the same reason) — upgradeToStudioStructure() resolving cleanly does
  // NOT guarantee the runtime service widgets actually landed. Observed in
  // practice: intermittently (more often on fast/warm-cache runs) it
  // resolves but the app/messages panes never appear, leaving the swap blank
  // with nothing left to fall back to. Verify the expected widget exists
  // before committing to 'upgraded'; retry the whole attempt a few times,
  // then give up to the classic layout rather than show a blank page.
  private static readonly STRUCTURE_UPGRADE_MAX_ATTEMPTS = 3;

  private async attemptStructureUpgrade(): Promise<void> {
    const modulePath = '/_102033_/l2/cbe/studioStructure.js';
    for (let attempt = 1; attempt <= CollabAuraShell.STRUCTURE_UPGRADE_MAX_ATTEMPTS; attempt += 1) {
      try {
        const module = (await import(`${modulePath}`)) as {
          upgradeToStudioStructure: (container: HTMLElement, siteProject: number) => Promise<HTMLElement>;
        };
        const host = this.querySelector('.studio-structure-host') as HTMLElement | null;
        if (!host) throw new Error('studio-structure-host not found');
        host.replaceChildren();
        await module.upgradeToStudioStructure(host, siteProjectFromBoot(this.bootConfig));
        if (await this.verifyStudioStructureRendered(host)) {
          this.structureUpgraded = true;
          this.reenterStudioAfterDraftSync();
          this.applyPendingStudioMode();
          this.requestUpdate();
          // collab-page measured its own size via getBoundingClientRect()
          // while .studio-structure-host was still display:none (the CSS
          // only reveals it once data-structure="upgraded" lands, which is
          // NOW) — that first measurement is always 0×0. Force a remeasure
          // once the DOM update above has actually applied, so it sees the
          // real, visible layout instead of relying on its own 500ms retry
          // (which can just as easily fire before this point and re-cache 0).
          await this.updateComplete;
          (host.querySelector('collab-page') as (HTMLElement & { layout?: () => void }) | null)?.layout?.();
          if (this.resolvedDevice === 'mobile') this.maybeAttachTopBandScroll();
          console.info(`[aura-shell] structure upgraded to the unified studio layout (attempt ${attempt})`);
          return;
        }
        console.warn(`[aura-shell] studio structure rendered without the runtime service widgets (attempt ${attempt}/${CollabAuraShell.STRUCTURE_UPGRADE_MAX_ATTEMPTS})`);
      } catch (error) {
        console.warn(`[aura-shell] studio structure upgrade attempt ${attempt}/${CollabAuraShell.STRUCTURE_UPGRADE_MAX_ATTEMPTS} failed:`, error);
      }
    }
    console.warn('[aura-shell] studio structure upgrade skipped after retries (classic layout stays)');
    this.structureUpgradeFailed = true;
    this.requestUpdate();
  }

  // Gives the nav1->nav2/nav3 service cascade time to settle (past
  // studioStructure's own 600ms applySplit re-apply) before judging whether
  // the upgrade actually produced visible content.
  private verifyStudioStructureRendered(host: HTMLElement): Promise<boolean> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(Boolean(host.querySelector('cbe--service-client-app-102033')));
      }, 800);
    });
  }

  // Whether this connection will (attempt to) end up in the unified studio
  // structure — governs the skeleton shown from first paint, so the classic
  // aside/menu never has to flash before the real swap. Any device: a phone
  // gets the same structure with one pane at a time.
  private wantsStudioStructure(): boolean {
    return !this.isEmbedded;
  }

  private get structureState(): 'classic' | 'pending' | 'upgraded' {
    if (this.structureUpgraded) return 'upgraded';
    if (this.wantsStudioStructure() && !this.structureUpgradeFailed) return 'pending';
    return 'classic';
  }

  // Ctrl+Alt+S: advance to the next header profile in the clientShell list
  // (banner <-> studio nav1+nav2; wraps around). No-op with fewer than two.
  private rotateHeaderProfile(): void {
    const names = this.getRegionProfileNames('header');
    if (names.length < 2) {
      return;
    }
    const active = this.bootConfig?.clientShell?.regions.header?.activeProfile ?? names[0];
    const next = names[(Math.max(0, names.indexOf(active)) + 1) % names.length];
    void this.setRegionProfile('header', next)
      .catch((error) => console.error('[aura-shell] failed to rotate header profile', error));
  }

  // Switch a region to the nth profile (1-based) of its clientShell list. Throws synchronously
  // on an out-of-range index so the console call surfaces the error; applies asynchronously.
  private setRegionByIndex(region: AuraDynamicRegionName, index: number): void {
    const names = this.getRegionProfileNames(region);
    if (!Number.isInteger(index) || index < 1 || index > names.length) {
      const name = region === 'header' ? 'setHeader' : 'setAside';
      throw new Error(`mls.sites.${name}(${index}): index out of range (valid: 1..${names.length}).`);
    }
    void this.setRegionProfile(region, names[index - 1])
      .catch((error) => console.error(`[mls.sites] failed to set ${region}`, error));
  }

  // Current content page genome (e.g. 11, 21) parsed from the active renderer tag, or undefined.
  private getContentPageGenome(): number | undefined {
    const match = this.getActiveContentRenderer()?.tag.match(/--page(\d\d)--/);
    return match ? Number(match[1]) : undefined;
  }

  // Set the active content page to an absolute two-digit genome (e.g. 21). Fail-safe: if the
  // variant chunk does not load or its element is not registered, the current page is kept.
  private async setContentPage(genome: number): Promise<void> {
    await this.applyContentPageGenome(genome, true);
  }

  private getRenderer(region: MasterFrontendRegionName) {
    if (!this.bootConfig) {
      return null;
    }

    if (region === 'content') {
      const content = this.getActiveContentRenderer();
      if (!content) {
        throw new Error('Aura shell requires an active route renderer in window.collabBoot.');
      }
      return {
        entrypoint: content.entrypoint,
        tag: content.tag,
        fallback: false,
      };
    }

    const dynamicRenderer = this.dynamicRegionRenderers[region];
    if (dynamicRenderer) {
      return dynamicRenderer;
    }

    const entrypoint = region === 'header' ? this.bootConfig.headerEntrypoint : this.bootConfig.asideEntrypoint;
    const tag = region === 'header' ? this.bootConfig.headerTag : this.bootConfig.asideTag;
    if (entrypoint && tag) {
      return {
        entrypoint,
        tag,
        fallback: false,
      };
    }

    return {
      entrypoint: '',
      tag: DEFAULT_REGION_TAGS[region],
      fallback: true,
    };
  }

  private async importRegion(region: MasterFrontendRegionName) {
    const renderer = this.getRenderer(region);
    if (!renderer || renderer.fallback) {
      return;
    }

    try {
      traceLazy('importRegion.start', {
        region,
        entrypoint: renderer.entrypoint,
      });
      await loadAuraRouteChunk(renderer.entrypoint);
      traceLazy('importRegion.success', {
        region,
        entrypoint: renderer.entrypoint,
      });
    } catch (error) {
      throw new Error(`Could not load Aura ${region} renderer from ${renderer.entrypoint}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private async loadActiveRoute() {
    if (!this.bootConfig) {
      return;
    }

    const previousContentGenome = this.getContentPageGenome();
    traceLazy('loadActiveRoute.start', {
      pathname: window.location.pathname,
      requestedContentGenome: previousContentGenome,
    });
    const nextRoute = matchAuraRoute(this.bootConfig.routes, window.location.pathname);
    if (!nextRoute) {
      this.activeRoute = undefined;
      this.routeStatusMessage = `Route not registered for ${window.location.pathname}.`;
      return;
    }

    this.activeRoute = nextRoute;
    this.contentVariantRenderer = undefined;
    // rt37: a route change always restores the top band (no-op when it was already visible,
    // e.g. desktop or the very first route load).
    this.showTopBand();
    const nextContentGenome = this.getContentPageGenome();
    const requestedContentGenome = contentPageGenomeToPreserve(previousContentGenome, nextContentGenome);
    if (requestedContentGenome !== undefined && requestedContentGenome !== nextContentGenome) {
      await this.applyContentPageGenome(requestedContentGenome, false);
    }
    // The server registers one entrypoint per route — the desktop one — so only mobile needs the
    // swap here. Before the chunk cache is read, or the loading state and importRegion would run
    // against the desktop entrypoint.
    if (this.getContentDevice() === 'mobile') {
      await this.applyContentPageDevice('mobile', false);
    }
    const loadedChunks = getCollabRouteChunkCache();
    const activeRenderer = this.getActiveContentRenderer() ?? nextRoute;
    const shouldShowLoading = !loadedChunks.has(activeRenderer.entrypoint);
    traceLazy('loadActiveRoute.matched', {
      path: nextRoute.path,
      entrypoint: activeRenderer.entrypoint,
      shouldShowLoading,
    });
    this.routeStatusMessage = shouldShowLoading ? `Loading ${nextRoute.title}...` : '';

    try {
      await this.importRegion('content');
      this.routeStatusMessage = '';
      traceLazy('loadActiveRoute.ready', {
        path: nextRoute.path,
        tag: nextRoute.tag,
      });
      this.requestUpdate();
    } catch (error) {
      this.routeStatusMessage = error instanceof Error ? error.message : String(error);
    }
  }

  private getBaseRegionVisibility(region: MasterFrontendRegionName) {
    if (this.isEmbedded && region !== 'content') return false;
    const visibility = this.bootConfig?.layout.regions[this.resolvedDevice];
    return visibility?.[region] ?? true;
  }

  private getActualAsideOpen() {
    if (!this.getBaseRegionVisibility('aside')) {
      return false;
    }

    return this.getResolvedAsideMode() === 'inline' ? true : this.isAsideOpen;
  }

  private getRegionVisibility(region: MasterFrontendRegionName) {
    if (!this.getBaseRegionVisibility(region)) {
      return false;
    }

    const asideMode = this.getResolvedAsideMode();
    const isAsideOpen = this.getActualAsideOpen();

    if (region === 'aside') {
      return isAsideOpen;
    }

    if (asideMode === 'fullscreen' && isAsideOpen) {
      return false;
    }

    return true;
  }

  private mountRegion(region: MasterFrontendRegionName) {
    if (!this.bootConfig) {
      return;
    }

    const host = this.querySelector(`[data-region-host="${region}"]`);
    if (!host) {
      return;
    }

    if (!this.getBaseRegionVisibility(region)) {
      host.replaceChildren();
      return;
    }

    if (region === 'content' && !this.activeRoute) {
      host.replaceChildren();
      return;
    }

    const renderer = this.getRenderer(region);
    if (!renderer) {
      host.replaceChildren();
      return;
    }

    const currentTagName = host.firstElementChild?.tagName.toLowerCase();
    if (currentTagName === renderer.tag) {
      traceLazy('mountRegion.reuse', {
        region,
        tag: renderer.tag,
      });
      const currentElement = host.firstElementChild as AuraRegionElement | null;
      if (currentElement) {
        currentElement.bootConfig = this.bootConfig;
        currentElement.regionProps = this.getRegionProps(region);
      }
      if (region === 'aside') this.flushAsideNavigation('mode');
      return;
    }

    traceLazy('mountRegion.replace', {
      region,
      tag: renderer.tag,
    });
    const element = document.createElement(renderer.tag) as AuraRegionElement;
    element.bootConfig = this.bootConfig;
    element.regionProps = this.getRegionProps(region);
    host.replaceChildren(element);
    if (region === 'aside') this.flushAsideNavigation('mode');
  }

  /** The panel dispatches `collabDraftSaved` after a successful send. Listen for the life of this shell. */
  private ensureConfigWatch(): void {
    if (this.isEmbedded || this.stopConfigWatch) return;
    this.stopConfigWatch = attachCollabDraftSavedWatch(window, (detail) => this.onDraftSaved(detail));
  }

  private onDraftSaved(detail: CollabDraftSavedDetail): void {
    const project = asideProjectId(window.collabBoot ?? this.bootConfig);
    if (this.studioModeOn && project === null && detail.paths.includes(SITE_CONFIG_PATH)) {
      if (!this.reportedMissingProject) {
        this.reportedMissingProject = true;
        console.error('[shell] studio mode is on and collabBoot.projectId is missing; aside was not reread');
      }
      return;
    }
    const refresh = draftSavedShouldRefresh(detail, this.studioModeOn, project);
    console.info('[shell] collabDraftSaved', { studioModeOn: this.studioModeOn, project, paths: detail.paths, refresh });
    if (!refresh) return;
    this.refreshAsideNavigation('send');
  }

  private refreshAsideNavigation(reason: 'mode' | 'send'): void {
    this.asideNavPending = true;
    this.flushAsideNavigation(reason);
  }

  private flushAsideNavigation(reason: 'mode' | 'send'): void {
    if (!this.asideNavPending) return;
    const aside = (this.querySelector('collab-aura-aside')
      ?? document.querySelector('collab-aura-aside')) as StudioAside | null;
    if (!aside || typeof aside.syncStudioNavigation !== 'function') {
      if (reason === 'send') {
        console.error('[shell] collab-aura-aside is not mounted; the draft config send did not refresh the menu');
      }
      return;
    }
    this.asideNavPending = false;
    const studioOn = this.studioModeOn;
    console.info('[shell] aside refresh', {
      reason,
      studioOn,
      instances: document.querySelectorAll('collab-aura-aside').length,
      connected: aside.isConnected,
      visible: aside.offsetParent !== null,
    });
    void aside.syncStudioNavigation(studioOn).catch((err: unknown) => {
      console.error('[shell] aside navigation refresh failed:', err);
    });
  }

  updated() {
    if (!this.bootConfig) {
      return;
    }
    this.setAttribute('data-device', this.resolvedDevice);
    this.setAttribute('data-aside-mode', this.getResolvedAsideMode());
    this.setAttribute('data-aside-open', String(this.getActualAsideOpen()));
    this.setAttribute('data-structure', this.structureState);
    this.setAttribute('data-studio-mode', String(this.studioModeOn));
    // The phone frame around the app region: only when the studio picked Mobile on a desktop-wide window. On a
    // narrow window the app already is the mobile app, full width, and a frame would add nothing.
    this.setAttribute('data-studio-frame', String(this.studioModeOn && this.studioDevicePick === 'mobile' && this.resolvedDevice === 'desktop'));
    this.setAttribute('data-mobile-pane', this.mobilePane);
    const environmentBadge = document.getElementById('collab-env-badge');
    if (environmentBadge) environmentBadge.hidden = this.studioModeOn;
    this.mountRegion('header');
    this.mountRegion('aside');
    this.mountRegion('content');
    this.syncStructureLayout();
    this.scheduleRegionMsizeSync();
    this.syncContentTabPanels();
    this.announceActiveTab();
    // Redundant trigger: the connectedCallback timer can be lost across early
    // shell remounts (observed on some boots) — the attempted/mls guards make
    // this re-check free once the upgrade ran or started.
    this.maybeUpgradeStructure();
  }

  private renderBlockingError(blockingError: MasterFrontendBlockingErrorState) {
    return html`
      <section class="shell-error-card" role="alert" aria-live="assertive">
        <p class="shell-error-eyebrow">Falha de carregamento</p>
        <h2>${blockingError.title}</h2>
        <p class="shell-error-message">${blockingError.error.message}</p>
        ${blockingError.error.details ? html`<pre class="shell-error-details">${String(blockingError.error.details)}</pre>` : null}
        <div class="shell-error-actions">
          ${blockingError.canRetry
            ? html`<button type="button" class="shell-primary-button" @click=${() => void retryBlockingError()}>Tentar novamente</button>`
            : null}
          <button type="button" class="shell-secondary-button" @click=${() => clearBlockingError()}>Fechar</button>
        </div>
      </section>
    `;
  }

  render() {
    const styles = html`<style>
      collab-aura-shell {
        display: block;
        min-height: 100vh;
        color: #102a43;
        font-family: "Segoe UI", sans-serif;
        --aura-region-header-display: block;
        --aura-region-aside-display: block;
        --aura-region-content-display: block;
      }

      collab-aura-shell .layout {
        display: grid;
        min-height: 100vh;
        grid-template-rows: auto 1fr;
        background: #fffdfa;
      }

      /* ── Upgraded structure (on.collab.codes layout) ─────────────────────
         The studio DOM (collab-page > nav1 + spliter[nav2+nav3 ×2]) fills the
         viewport; the runtime services inside the nav3 pair adopted the
         messages/app panels. The classic .body is emptied+hidden. The client
         banner becomes a fixed 66px overlay covering exactly nav1+nav2 —
         production shows the banner, studio mode (Ctrl+Alt+S) hides it. */
      collab-aura-shell .studio-structure-host { display: none; }

      collab-aura-shell[data-structure="upgraded"] .studio-structure-host {
        display: block;
        position: fixed;
        inset: 0;
      }

      /* ── rt37: mobile top band scroll ────────────────────────────────────
         Mobile-only (gated in JS by resolvedDevice === 'mobile'): on a sustained scroll-down the
         66px band (client banner + collab-nav-1/2, see the .region.header rule below) rises off
         screen and the structure host grows into the space it leaves — nav1/nav2 are fixed-height
         flex children of collab-page, so the extra height flows entirely to the flexible nav3
         panels, never revealing the Studio bars underneath. A sustained scroll-up (or the state
         resets listed in topBandScroll's callers) brings it back. */
      collab-aura-shell[data-device="mobile"][data-structure="upgraded"] .studio-structure-host {
        transition: top 0.25s ease;
      }

      collab-aura-shell[data-device="mobile"][data-structure="upgraded"][data-top-band="hidden"] .studio-structure-host {
        top: -66px;
      }

      @media (prefers-reduced-motion: reduce) {
        collab-aura-shell[data-device="mobile"][data-structure="upgraded"] .studio-structure-host {
          transition: none;
        }
      }

      /* ── Pending structure (desktop, upgrade attempt in flight) ──────────
         Same footprint the upgraded structure will occupy, but filled with a
         static shimmer skeleton instead of collab-page — shown from FIRST
         paint on desktop so the classic aside/menu never flashes on screen.
         Swapped out for the real structure the instant the upgrade lands. */
      collab-aura-shell .studio-structure-skeleton { display: none; }

      collab-aura-shell[data-structure="pending"] .studio-structure-skeleton {
        display: flex;
        flex-direction: column;
        position: fixed;
        inset: 0;
        background: #f6f6f6;
      }

      collab-aura-shell .skeleton-nav1 {
        flex: 0 0 30px;
        background: #dfdfdf;
      }

      collab-aura-shell .skeleton-body {
        flex: 1 1 auto;
        display: flex;
        min-height: 0;
      }

      collab-aura-shell .skeleton-pane {
        display: flex;
        flex-direction: column;
        min-width: 0;
        border-right: 1px solid #e2e8f0;
      }

      collab-aura-shell .skeleton-pane:last-child {
        border-right: none;
      }

      collab-aura-shell .skeleton-pane-left {
        flex: 0 0 375px;
      }

      collab-aura-shell .skeleton-pane-right {
        flex: 1 1 auto;
      }

      collab-aura-shell .skeleton-nav2 {
        flex: 0 0 36px;
        background: #dfdfdf;
      }

      collab-aura-shell .skeleton-content {
        flex: 1 1 auto;
        margin: 16px;
        border-radius: 8px;
        background: linear-gradient(90deg, #eceff1 25%, #e3e6e8 37%, #eceff1 63%);
        background-size: 400% 100%;
        animation: shell-skeleton-shimmer 1.4s ease infinite;
      }

      /* Phone: one pane at a time (mobilePane.ts) — the skeleton shows one. The spliter's 8px
         separator stays: every panel msize is computed with it. */
      collab-aura-shell[data-device="mobile"] .skeleton-pane-left {
        flex: 1 1 auto;
        border-right: none;
      }

      collab-aura-shell[data-device="mobile"] .skeleton-pane-right {
        display: none;
      }

      @keyframes shell-skeleton-shimmer {
        0% { background-position: 100% 50%; }
        100% { background-position: 0 50%; }
      }

      collab-aura-shell[data-structure="upgraded"] .layout .body,
      collab-aura-shell[data-structure="pending"] .layout .body {
        display: none;
      }

      collab-aura-shell[data-structure="upgraded"] .region.header,
      collab-aura-shell[data-structure="pending"] .region.header {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        height: 66px;
        z-index: 50;
        overflow: hidden;
      }

      collab-aura-shell[data-structure="upgraded"][data-studio-mode="true"] .region.header {
        display: none;
      }

      /* rt37: the banner rises together with the structure host above — see that rule's comment. */
      collab-aura-shell[data-device="mobile"][data-structure="upgraded"] .region.header {
        transition: transform 0.25s ease;
      }

      collab-aura-shell[data-device="mobile"][data-structure="upgraded"][data-top-band="hidden"] .region.header {
        transform: translateY(-66px);
      }

      @media (prefers-reduced-motion: reduce) {
        collab-aura-shell[data-device="mobile"][data-structure="upgraded"] .region.header {
          transition: none;
        }
      }

      collab-aura-shell .body {
        display: grid;
        grid-template-columns: var(--aura-aside-width, 280px) minmax(0, 1fr);
        min-height: 0;
        background: #fffdfa;
        position: relative;
      }

      collab-aura-shell .body[data-aside-mode="drawer"],
      collab-aura-shell .body[data-aside-mode="fullscreen"],
      collab-aura-shell .body[data-aside-visible="false"] {
        grid-template-columns: minmax(0, 1fr);
      }

      collab-aura-shell .region {
        min-width: 0;
        min-height: 0;
      }

      /* Only the app's own regions read the DS font — the studio chrome around them (nav1/nav2,
         nav3 tabs and panels) keeps the shell font. Unprefixed: in studio mode the content region
         is adopted by serviceClientApp. */
      [data-region-host="header"],
      [data-region-host="aside"],
      [data-region-host="content"] {
        font-family: var(--font-family-primary, "Segoe UI", sans-serif);
      }

      collab-aura-shell .region.header {
        display: var(--aura-region-header-display);
        height: var(--aura-header-height, auto);
        overflow: hidden;
      }

      collab-aura-shell .region.header [data-region-host="header"],
      collab-aura-shell .region.header [data-region-host="header"] > * {
        height: 100%;
      }

      collab-aura-shell .region.aside {
        display: var(--aura-region-aside-display);
        height: 100%;
      }

      collab-aura-shell .body[data-aside-mode="drawer"] .region.aside,
      collab-aura-shell .body[data-aside-mode="fullscreen"] .region.aside {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        z-index: 30;
        max-width: min(var(--aura-aside-drawer-width, 320px), calc(100vw - 32px));
        width: 100%;
        box-shadow: 0 20px 50px rgba(15, 23, 42, 0.28);
      }

      collab-aura-shell .body[data-aside-mode="fullscreen"] .region.aside {
        max-width: 100vw;
      }

      collab-aura-shell .region.content {
        display: var(--aura-region-content-display);
        background:
          radial-gradient(circle at top right, rgba(255, 207, 117, 0.28), transparent 26%),
          linear-gradient(180deg, #f7f4ea 0%, #fffdfa 100%);
      }

      /* Studio picked Mobile on a wide window: the app region (adopted by the client app service, still inside
         this shell) becomes a phone-wide column. Only the region — the studio's own columns are untouched. */
      collab-aura-shell[data-studio-frame="true"] cbe--service-client-app-102033 {
        background: #d1d5db;
      }

      .dark collab-aura-shell[data-studio-frame="true"] cbe--service-client-app-102033 {
        background: #111827;
      }

      collab-aura-shell[data-studio-frame="true"] main[data-region="content"] {
        width: 390px;
        max-width: 100%;
        margin-inline: auto;
        box-sizing: border-box;
        border-inline: 1px solid rgba(0, 0, 0, 0.15);
        box-shadow: 0 0 24px rgba(0, 0, 0, 0.18);
      }

      /* Unified nav3: the outer shell is always a tab host, including one tab. */
      collab-aura-shell .region.content[data-has-tabs="true"] {
        display: flex;
        flex-direction: column;
        min-height: 0;
      }

      collab-aura-shell .nav3-tabs {
        display: flex;
        gap: 2px;
        flex: 0 0 36px;
        align-items: stretch;
        padding: 0 8px;
        background: var(--collab-nav-bg-2, #e8e4da);
        border-bottom: 1px solid #d9e2ec;
      }

      collab-aura-shell .nav3-tab {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-top: 4px;
        padding: 0 14px;
        border: none;
        border-radius: 6px 6px 0 0;
        background: transparent;
        color: var(--collab-nav-color, #52606d);
        font-size: 0.85rem;
        cursor: pointer;
        white-space: nowrap;
      }

      collab-aura-shell .nav3-tab[data-active="true"] {
        background: var(--collab-nav-bg-3, #fffdfa);
        color: var(--collab-nav-color-active, #102a43);
        font-weight: 600;
        cursor: default;
      }

      collab-aura-shell .nav3-tab-close {
        font-size: 1rem;
        line-height: 1;
        opacity: 0.6;
        cursor: pointer;
      }

      collab-aura-shell .nav3-tab-close[data-pinned="true"] {
        font-size: 0.85rem;
      }

      collab-aura-shell .nav3-tab-close:hover {
        opacity: 1;
      }

      collab-aura-shell .nav3-panels {
        flex: 1 1 auto;
        min-height: 0;
        position: relative;
      }

      collab-aura-shell .nav3-panel {
        height: 100%;
        min-height: 0;
        overflow: auto;
      }

      collab-aura-shell .nav3-panel[data-active="false"] {
        display: none;
      }

      collab-aura-shell .nav3-panel-app {
        box-sizing: border-box;
      }

      collab-aura-shell [data-region-host="aside"] {
        height: 100%;
      }

      collab-aura-shell .backdrop {
        position: fixed;
        inset: 0;
        z-index: 20;
        background: rgba(15, 23, 42, 0.42);
      }

      collab-aura-shell .error {
        margin: 24px;
        padding: 16px 18px;
        border-radius: 14px;
        border: 1px solid #f7c6c7;
        background: #fff1f2;
        color: #7a1f2a;
      }

      collab-aura-shell .shell-guard {
        position: fixed;
        inset: 0;
        z-index: 80;
        pointer-events: auto;
      }

      collab-aura-shell .shell-guard.subtle {
        background: rgba(255, 253, 250, 0.08);
      }

      collab-aura-shell .shell-guard.dimmed {
        background: rgba(15, 23, 42, 0.24);
        backdrop-filter: blur(2px);
      }

      collab-aura-shell .guard-label {
        position: fixed;
        top: 20px;
        right: 24px;
        border-radius: 999px;
        padding: 10px 14px;
        background: rgba(255, 255, 255, 0.92);
        color: #102a43;
        font-size: 0.9rem;
        box-shadow: 0 14px 34px rgba(15, 23, 42, 0.14);
      }

      collab-aura-shell .shell-error-card {
        margin: 24px 0;
        border-radius: 28px;
        border: 1px solid #fecaca;
        background: #fff7f7;
        padding: 28px;
        box-shadow: 0 18px 40px rgba(127, 29, 29, 0.08);
      }

      collab-aura-shell .shell-error-eyebrow {
        margin: 0 0 10px;
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.16em;
        text-transform: uppercase;
        color: #b91c1c;
      }

      collab-aura-shell .shell-error-card h2 {
        margin: 0;
        font-size: 1.5rem;
        color: #7f1d1d;
      }

      collab-aura-shell .shell-error-message {
        margin: 14px 0 0;
        color: #7f1d1d;
        line-height: 1.6;
      }

      collab-aura-shell .shell-error-details {
        margin: 16px 0 0;
        overflow-x: auto;
        border-radius: 18px;
        background: #fff;
        padding: 14px;
        font-size: 0.84rem;
        color: #7f1d1d;
      }

      collab-aura-shell .shell-error-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-top: 20px;
      }

      collab-aura-shell .shell-primary-button,
      collab-aura-shell .shell-secondary-button {
        border-radius: 999px;
        padding: 11px 18px;
        font-weight: 600;
        cursor: pointer;
      }

      collab-aura-shell .shell-primary-button {
        border: none;
        background: #102a43;
        color: #fff;
      }

      collab-aura-shell .shell-secondary-button {
        border: 1px solid #d9e2ec;
        background: #fff;
        color: #102a43;
      }

    </style>`;

    if (!this.bootConfig) {
      return html`${styles}<div class="error">${this.statusMessage ?? 'Shell bootstrap was not provided.'}</div>`;
    }

    if (this.statusMessage) {
      return html`${styles}<div class="error">${this.statusMessage}</div>`;
    }

    const headerVisible = this.getRegionVisibility('header');
    const asideVisible = this.getRegionVisibility('aside');
    const contentVisible = this.getRegionVisibility('content');
    const asideMode = this.getResolvedAsideMode();
    const isAsideOpen = this.getActualAsideOpen();
    const blockingError = this.interactionState.blockingError;
    const shellStyle = [
      `--aura-region-header-display: ${headerVisible ? 'block' : 'none'}`,
      `--aura-region-aside-display: ${asideVisible ? 'block' : 'none'}`,
      `--aura-region-content-display: ${contentVisible ? 'block' : 'none'}`,
      `--aura-aside-width: ${this.getAsideWidthPx()}px`,
      `--aura-aside-drawer-width: ${this.getAsideDrawerWidthPx()}px`,
      `--aura-header-height: ${this.activeHeaderHeightPx && this.activeHeaderHeightPx > 0 ? `${this.activeHeaderHeightPx}px` : 'auto'}`,
    ].join('; ');

    return html`
      <div
        style=${shellStyle}
        data-device=${this.resolvedDevice}
        data-aside-mode=${asideMode}
        data-aside-open=${String(isAsideOpen)}
      >
        ${styles}
        ${this.interactionState.busy
          ? html`
              <div class="shell-guard ${this.interactionState.busyPhase}">
                ${this.interactionState.busyPhase === 'dimmed'
                  ? html`<div class="guard-label">${this.interactionState.busyLabel ?? 'Processando...'}</div>`
                  : null}
              </div>
            `
          : null}
        <div class="studio-structure-host"></div>
        <div class="studio-structure-skeleton" aria-hidden="true">
          <div class="skeleton-nav1"></div>
          <div class="skeleton-body">
            <div class="skeleton-pane skeleton-pane-left">
              <div class="skeleton-nav2"></div>
              <div class="skeleton-content"></div>
            </div>
            <div class="skeleton-pane skeleton-pane-right">
              <div class="skeleton-nav2"></div>
              <div class="skeleton-content"></div>
            </div>
          </div>
        </div>
        <div class="layout">
          <section class="region header" data-region="header" data-visible=${String(headerVisible)}>
            <div data-region-host="header"></div>
          </section>
          <div
            class="body"
            data-aside-visible=${String(asideVisible)}
            data-device=${this.resolvedDevice}
            data-aside-mode=${asideMode}
            data-aside-open=${String(isAsideOpen)}
          >
            ${asideMode !== 'inline' && isAsideOpen
        ? html`<button class="backdrop" type="button" aria-label="Close aside" @click=${this.handleCloseAside}></button>`
        : null}
            <aside class="region aside" data-region="aside" data-visible=${String(asideVisible)}>
              <div data-region-host="aside"></div>
            </aside>
            <main class="region content" data-region="content" data-visible=${String(contentVisible)} data-has-tabs=${String(!this.isEmbedded)}>
              ${this.isEmbedded
        ? null
        : html`
                  <div class="nav3-tabs" role="tablist">
                    ${this.appTabOpen
            ? html`
                    <button class="nav3-tab" role="tab" data-active=${String(this.activeContentTabId === 'app')} @click=${() => this.activateContentTab('app')}>
                      ${contentTabLabel(this.bootConfig?.pageTitle ?? 'App', 'app')}
                      <span class="nav3-tab-close" data-pinned="false" title=${contentTabMarkTitle('app', document.documentElement?.lang ?? 'en')} @click=${(event: Event) => { event.stopPropagation(); this.closeContentTab('app'); }}>×</span>
                    </button>`
            : null}
                    ${this.contentTabs.map((tab) => html`
                      <button class="nav3-tab" role="tab" data-active=${String(this.activeContentTabId === tab.id)} @click=${() => this.activateContentTab(tab.id)}>
                        ${contentTabLabel(tab.title, tab.id)}
                        ${tab.closable ? this.renderTabMark(tab.id) : null}
                      </button>
                    `)}
                  </div>
                `}
              <div class="nav3-panels">
                <div class="nav3-panel nav3-panel-app" data-tab="app" data-active=${String(this.activeContentTabId === 'app')}>
                  ${blockingError ? this.renderBlockingError(blockingError) : null}
                  ${!blockingError && this.routeStatusMessage
        ? html`<div class="error">${this.routeStatusMessage}</div>`
        : null}
                  ${blockingError ? null : html`<div data-region-host="content"></div>`}
                </div>
                ${this.contentTabs.map((tab) => html`
                  <div class="nav3-panel" data-tab=${tab.id} data-active=${String(this.activeContentTabId === tab.id)}></div>
                `)}
              </div>
            </main>
          </div>
        </div>
      </div>
    `;
  }
}

customElements.define('collab-aura-shell', CollabAuraShell);
