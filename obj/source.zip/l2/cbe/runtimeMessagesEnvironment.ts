/// <mls fileReference="_102033_/l2/cbe/runtimeMessagesEnvironment.ts" enhancement="_blank" />
// Generic collab-messages environment for ANY client project on the runtime
// VM (extracted from the 102051 messagesAside so projects without their own
// aside — e.g. 102045 — get messages out of the box in the unified nav3):
// same-origin /msg API with cookie credentials, apps menu from the composed
// config.json (monitor.config.load), task details in the nav3 Detail tab,
// and menu mode 'custom' (the nav3 toolbar owns the mode tabs).

import { setEnvironment, type CollabMessagesEnvironment, type CollabProgramMenu, type CollabProgramMenuItem } from '/_102036_/l2/environmentContract.js';
import type { ExecutionContext, IAgentMeta } from '/_102036_/l2/shared/interfaces.js';
import { notificationsRuntime } from '/_102025_/l2/notificationsRuntime.js';
import { collabMessagesEnvironmentBase } from '/_102025_/l2/collabMessagesEnvironmentBase.js';
import { closeAuraAside } from '/_102033_/l2/shellEvents.js';
import { openModuleTab } from '/_102033_/l2/shared/moduleTab.js';
import { MOBILE_BREAKPOINT_PX } from '/_102033_/l2/shared/breakpoints.js';
// brings the global Window.collabBoot declaration into every program that compiles this file
import type { MasterFrontendBootConfig } from '/_102029_/l2/contracts/bootstrap.js';
import { readDraftModules, type ConfigModule, type ConfigNavItem } from '/_102033_/l2/cbe/studioDraftConfig.js';
import { siteProjectFromBoot } from '/_102033_/l2/shared/siteProject.js';

function moduleToMenu(moduleConfig: ConfigModule, project: number): CollabProgramMenu | null {
  if (!moduleConfig.moduleId) return null;
  const basePath = moduleConfig.basePath ?? `/${moduleConfig.moduleId}`;
  const navigation = (moduleConfig.navigation ?? []).filter((nav) => nav.href);
  const menu: CollabProgramMenuItem[] = navigation.length > 0
    ? navigation.map((nav) => ({
        title: nav.label ?? nav.id ?? nav.href ?? '',
        icon: typeof nav.icon === 'string' && nav.icon !== '' ? nav.icon : '',
        url: nav.href ?? '',
        pageName: nav.id ?? nav.href ?? '',
      }))
    : [{ title: moduleConfig.moduleId, icon: '', url: basePath, pageName: moduleConfig.moduleId }];
  return { name: moduleConfig.moduleId, icon: '', project, path: basePath, menu };
}

async function callBff<T>(routine: string): Promise<T | undefined> {
  try {
    const response = await fetch('/execBff', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ routine, params: {}, meta: { source: 'http' } }),
    });
    const rc = await response.json() as { ok?: boolean; data?: T };
    return rc.ok ? rc.data : undefined;
  } catch {
    return undefined;
  }
}

function studioModeOn(): boolean {
  const sites = (globalThis as { mls?: { sites?: { getMode?: () => string | undefined } } }).mls?.sites;
  if (typeof sites?.getMode !== 'function') return false;
  try {
    return sites.getMode() === 'studio';
  } catch (err) {
    console.error('[runtimeMessagesEnvironment] failed to read studio mode:', err);
    return false;
  }
}

function siteProjectId(): number | null {
  const id = siteProjectFromBoot((globalThis as { collabBoot?: { projectId?: string; clientProjectId?: string } }).collabBoot);
  return id > 0 ? id : null;
}

function replaceSiteMenus(menus: CollabProgramMenu[], project: number, draftMenus: CollabProgramMenu[]): CollabProgramMenu[] {
  const next: CollabProgramMenu[] = [];
  let placed = false;
  for (const menu of menus) {
    if (menu.project !== project) {
      next.push(menu);
      continue;
    }
    if (!placed) {
      next.push(...draftMenus);
      placed = true;
    }
  }
  if (!placed) next.push(...draftMenus);
  return next;
}

async function menusFromBff(): Promise<CollabProgramMenu[]> {
  // Preferred: monitor.appsMenu.load — every hosted app with its RESOLVED
  // navigation (includes the master modules monitor/audit/mdm, whose menu
  // lives in module.ts, not in the composed config.json).
  const appsMenu = await callBff<{ apps?: Array<{ projectId?: string | number; moduleId?: string; basePath?: string; navigation?: ConfigNavItem[] }> }>('monitor.appsMenu.load');
  if (appsMenu?.apps?.length) {
    const menus = appsMenu.apps
      .map((app) => moduleToMenu({ moduleId: app.moduleId, basePath: app.basePath, navigation: app.navigation }, Number(app.projectId) || 0))
      .filter((menu): menu is CollabProgramMenu => menu !== null);
    if (menus.length > 0) return menus;
  }

  // Fallback (older backend releases): the composed config.json.
  const config = await callBff<{ projects?: Record<string, { modules?: ConfigModule[] }> }>('monitor.config.load');
  if (config?.projects) {
    const menus: CollabProgramMenu[] = [];
    for (const [projectId, project] of Object.entries(config.projects)) {
      for (const moduleConfig of project.modules ?? []) {
        const menu = moduleToMenu(moduleConfig, Number(projectId) || 0);
        if (menu) menus.push(menu);
      }
    }
    if (menus.length > 0) return menus;
  }
  return [];
}

export async function buildProgramMenu(): Promise<CollabProgramMenu[]> {
  const menus = await menusFromBff();
  if (!studioModeOn()) return menus;
  const project = siteProjectId();
  if (project === null) {
    console.error('[runtimeMessagesEnvironment] studio mode is on and collabBoot.projectId is missing; apps menu stays on the release');
    return menus;
  }
  // Site project comes from the draft config. Master modules (other projects) stay on the BFF menu.
  const modules = await readDraftModules(project);
  if (!modules) {
    console.info('[runtimeMessagesEnvironment] apps menu', { studio: true, source: 'release', reason: 'draft config not read' });
    return menus;
  }
  const draftMenus = modules
    .map((moduleConfig) => moduleToMenu(moduleConfig, project))
    .filter((menu): menu is CollabProgramMenu => menu !== null);
  console.info('[runtimeMessagesEnvironment] apps menu', { studio: true, source: 'draft', siteModules: draftMenus.length });
  return replaceSiteMenus(menus, project, draftMenus);
}

// The app's tabs/panels live adopted inside serviceClientApp, on the right
// nav3 — if some OTHER right-side service is active (e.g. a studio panel
// selected via the header's own nav2), the region is there but hidden behind
// it. Opening/activating an app must bring serviceClientApp back to front.
export function ensureAppServiceVisible(): void {
  const nav3Right = document.querySelector('collab-nav-3[toolbarposition="right"]');
  if (nav3Right && nav3Right.getAttribute('data-service') !== '_102033_/l2/cbe/serviceClientApp') {
    nav3Right.setAttribute('data-service', '_102033_/l2/cbe/serviceClientApp');
  }
}

/**
 * Program navigation for the unified shell:
 * - Pages of the CURRENT app: SPA navigation (pushState + popstate), no reload.
 * - Other apps (monitor, audit, another module): a nav3 content tab whose div
 *   mounts that module's page in this document. No iframe.
 * - Fallback (no nav3 yet): plain navigation.
 */
export async function openProgramUnified(item: { url?: string; pageName?: string }): Promise<void> {
  if (!item.url) return;
  ensureAppServiceVisible();
  // On a phone the messages pane covers the app (one pane at a time); whatever opens next has to be
  // seen. In-module routes would switch via popstate anyway — tabs and iframes would not. No-op on
  // desktop, where the aside is inline.
  closeAuraAside();
  const basePath = window.collabBoot?.basePath ?? '';
  if (basePath && item.url.startsWith(basePath)) {
    window.history.pushState({}, '', item.url);
    window.dispatchEvent(new PopStateEvent('popstate'));
    // The app renders in the 'app' tab — bring it to front, or the navigation
    // is invisible while a foreign-module tab (monitor/audit) is active.
    window.collabRuntimeNav3?.activateTab('app');
    return;
  }
  const nav3 = window.collabRuntimeNav3;
  if (nav3) {
    const moduleName = item.url.replace(/^\//u, '').split('/')[0] || item.pageName || 'app';
    await openModuleTab(`/${moduleName}`, item.url);
    return;
  }
  window.location.href = item.url;
}

// ── Agents ───────────────────────────────────────────────────────
// Without this section the contract falls back to defaultAgents, whose
// executeAgent RESOLVES doing nothing: on the VM an "@@agent" message spins
// forever and nothing is logged, because the chat calls executeAgent
// fire-and-forget and its try/catch never sees a failure. Same two functions
// the Studio wires in _102020_/l2/collabMessagesEnvironment.ts.
//
// generateSvgAvatar stays on the contract default on purpose: the runtime
// config keeps generateSvgAvatarEnabled() false (no UI calls it), and the
// avatar agent lives in 102020 — a dependency a generic client app has no
// reason to carry.
//
// The orchestration lib loads LAZILY. This module is applied on every
// self-hosted messages panel, including apps whose studio bootstrap
// (cbeMiniCfe) never finishes; pulling the whole agent stack at module load
// would be dead weight there, and one more way to fail before the chat even
// renders.

/**
 * The loader resolves an agent from mls.stor.files, filled by cbeMiniCfe
 * (cbeLogin + preloadStorFiles). With an empty store it finds nothing and
 * returns undefined, which reads downstream as "invalid agent" — so name the
 * real cause here instead.
 */
function assertAgentRuntimeReady(): void {
  const runtime = window as unknown as {
    mls?: { stor?: { files?: Record<string, unknown> } };
    collabMiniCfeReady?: boolean;
  };
  const files = runtime.mls?.stor?.files;
  if (files && Object.keys(files).length > 0) return;
  throw new Error(
    '[runtimeMessagesEnvironment] agents unavailable: mls.stor.files is empty, the studio bootstrap did not finish'
    + ` (window.mls=${Boolean(runtime.mls)}, window.collabMiniCfeReady=${Boolean(runtime.collabMiniCfeReady)})`,
  );
}

async function orchestration() {
  assertAgentRuntimeReady();
  return import('/_102027_/l2/aiAgentOrchestration.js');
}

async function runtimeLoadAgent(agentName: string): Promise<IAgentMeta | null> {
  const { loadAgent } = await orchestration();
  const agent = await loadAgent(agentName);
  return (agent ?? null) as IAgentMeta | null;
}

async function runtimeExecuteAgent(agentToCall: string, context: ExecutionContext): Promise<void> {
  const { loadAgent, executeBeforePrompt } = await orchestration();
  const agent = await loadAgent(agentToCall);
  if (!agent) throw new Error(`[runtimeMessagesEnvironment] agent not found: ${agentToCall}`);
  await executeBeforePrompt(agent, context);
}

/** Shared with project-provided asides (e.g. the 102051 cafe-flow aside), so
 * the two hosts of collab-messages on the VM run agents the same way. */
export const runtimeAgents: NonNullable<CollabMessagesEnvironment['agents']> = {
  executeAgent: (agentToCall: string, context: ExecutionContext) => runtimeExecuteAgent(agentToCall, context),
  loadAgent: (agentName: string) => runtimeLoadAgent(agentName),
};

/** Applies the generic runtime environment (call only when self-hosting —
 * a project-provided messages aside brings its own environment). */
/**
 * "See more" of a long chat message opens in the right-hand detail tab, the same `detail` tab as a task (one replaces the other).
 * Phone layout or no detail panel: false, and the chat expands the content in place as before.
 * Typed locally until the contract (102036 `details.openContent`) lands; extra keys are ignored by an older contract.
 */
export const runtimeDetails = {
  openContent: async ({ id, title, element }: { id: string; title: string; element: HTMLElement }): Promise<boolean> => {
    const nav3 = window.collabRuntimeNav3;
    if (!nav3) return false;
    if (window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT_PX}px)`).matches) return false;
    ensureAppServiceVisible();
    const host = document.createElement('service-detail-100554');
    host.style.display = 'block';
    host.style.height = '100%';
    host.appendChild(element);
    nav3.openTab({ id, title, element: host });
    closeAuraAside();
    return true;
  },
};

/** Aside de projeto (ex.: 102051): traz o ambiente dele. Sem isso, o runtime aplica o seu. */
export function projectMessagesAside(): Element | null {
  const asideContent = document.querySelector('[data-region-host="aside"] > *');
  if (!asideContent?.tagName.toLowerCase().includes('messages')) return null;
  return asideContent;
}

let runtimeMessagesEnvironmentApplied = false;

/** Aplica o ambiente genérico uma vez. Aside de projeto ou visita anterior: não faz nada. */
export function ensureRuntimeMessagesEnvironment(): void {
  if (runtimeMessagesEnvironmentApplied || projectMessagesAside()) return;
  applyRuntimeMessagesEnvironment();
  runtimeMessagesEnvironmentApplied = true;
}

export function applyRuntimeMessagesEnvironment(): void {
  const environment: CollabMessagesEnvironment = {
    ...collabMessagesEnvironmentBase,
    notifications: notificationsRuntime,
    agents: runtimeAgents,
    config: {
      getMenuMode: () => 'custom',
      getApiUrl: () => `${window.location.origin}/msg`,
      getApiCredentials: () => 'same-origin',
      getDefaultUserName: () => window.collabBoot?.pageTitle ?? 'App',
    },
    apps: {
      getProgramMenu: () => buildProgramMenu(),
      openProgram: (item) => openProgramUnified(item),
    },
    tasks: {
      openTaskDetails: async (messageId, _taskId, task, message) => {
        const nav3 = window.collabRuntimeNav3;
        if (!nav3) return { openLocal: false, element: undefined };
        ensureAppServiceVisible();
        await import('/_102025_/l2/collabMessagesTaskInfo.js');
        const info = document.createElement('collab-messages-task-info-102025') as HTMLElement & { task?: unknown; message?: unknown };
        info.setAttribute('messageId', messageId);
        info.task = task;
        info.message = message;
        const host = document.createElement('service-detail-100554');
        host.style.display = 'block';
        host.style.height = '100%';
        host.appendChild(info);
        nav3.openTab({ id: 'detail', title: 'Detail', element: host });
        closeAuraAside();
        return { openLocal: false, element: undefined };
      },
    },
  };
  setEnvironment(Object.assign(environment, { details: runtimeDetails }));
}
