/// <mls fileReference="_102033_/l2/cbe/cbeMiniCfe.ts" enhancement="_blank" />
// Mini 'cfe' bootstrap for the runtime VM. Loads the mls lib (window.mls) from
// /libs/mls.js — served by the cbe module in mls-102034 — and performs the cbe
// login. The login populates mls.stor.orgs (memory) and the mlsDB IndexedDB
// with the workspace project sources, leaving the studio environment prepared
// in the background while the normal app page renders untouched.
//
// Inspect the result in the browser console:
//   window.mls                      -> the loaded lib
//   mls.stor.orgs                   -> orgs/projects returned by the login
//   mls.stor.localDB.getAllKeys()   -> keys persisted in IndexedDB (mlsDB)

import { getLoginUser, showLoginGateIfNeeded } from '/_102033_/l2/cbe/cbeAuth.js';
import { setOrgActual, listenForLoadMonaco } from '/_102033_/l2/cbe/initStudio.js';
import { loadMlsScript } from '/_102033_/l2/cbe/cbeMiniCfeLoad.js';
import { installReleaseConsoleHelper } from '/_102033_/l2/cbe/releaseInfo.js';
import type { StudioMls } from '/_102033_/l2/cbe/global.js';

// Base project of the studio environment (the studio core, mls-100554). Same
// hardcode the on.collab.codes site carries in its nav1 markup
// (mls-102041/l2/index.html: <collab-nav-1 initialproject="100554">). The VM
// shell has no nav1, so cbeMiniCfe provides the equivalent marker below —
// groundwork for running studio widgets (collab-messages) in the SPA aside.
const CBE_BASE_PROJECT = 100554;

// Bump on every change so the console shows which build is live on the VM.
const CBE_MINI_CFE_VERSION = '1.3.2';

export async function initCbeMiniCfe(): Promise<void> {
  // Embedded frames (foreign modules in nav3 content tabs) render content
  // only — the TOP page owns the studio bootstrap; a nested login/upgrade
  // would duplicate work and mount a mini-studio inside the tab.
  try {
    if (window.self !== window.top) {
      console.info(`[cbeMiniCfe] v${CBE_MINI_CFE_VERSION} embedded frame — studio bootstrap skipped`);
      return;
    }
  } catch {
    return;
  }
  console.info(`[cbeMiniCfe] v${CBE_MINI_CFE_VERSION} starting`);
  // Before anything can fail: whatever happens to the bootstrap below, the console
  // must be able to ask which release is answering — that is often the first
  // question when something looks stale. Pure function publishing, no I/O.
  installReleaseConsoleHelper();
  // Gated host without a loginUser cookie: show the sign-in page RIGHT AWAY —
  // before the mls lib loads and the /exec login round-trip runs — so an
  // anonymous visitor never stares at a half-booted app. The post-login call
  // below removes it once the session exists.
  showLoginGateIfNeeded();
  try {
    const t0 = performance.now();
    await loadMlsScript();
    const mls = window.mls;
    if (!mls) return;

    // Monaco is NOT loaded here anymore — it used to download unconditionally for every
    // visitor (a multi-MB payload nobody but a developer or the message previews below ever
    // needed at boot). It now loads on demand: from the Ctrl+Alt+S studio switch
    // (shell.ts's loadStudioDefinitions), and from LoadMonaco (102025 previews fire it
    // the first time either actually needs to render an editor). Listen only — cheap.
    listenForLoadMonaco();

    // The service worker backs the js cache used by updateProjectFilesInfo —
    // without it the files processing awaits navigator.serviceWorker.ready
    // forever. Same order the studio uses (mls2.html).
    await mls.stor.cache.installIfNeeded();

    // Make the login request faithful to the studio's: actualProject = the
    // site's project, baseProject = the studio core (via the collabNav1
    // marker, the exact DOM channel the cfe reads in api.ts cbeLogin).
    prepareStudioLoginContext(mls);

    // The cfe cbeLogin surfaces alertMessage/errorMessage through
    // window.collabMessages — the studio toast system, absent on the VM app
    // page. Without a stub, a 'login required' response would throw inside
    // cbeLogin and lose the whole rc.
    const withToasts = window as unknown as { collabMessages?: { add: (msg: string, type: string, opts?: unknown) => void } };
    if (!withToasts.collabMessages) {
      withToasts.collabMessages = {
        add: (msg, type) => (type === 'error' ? console.error : console.info)(`[collab] ${msg}`),
      };
    }

    const rc = await mls.api.cbeLogin();

    // Sets mls.l5.actualOrg now that the login has populated mls.stor.orgs —
    // mirrors collabInit's setProjectActual -> setOrgActual sequence (see
    // initStudio.setOrgActual for why this port is needed on the VM). Calling
    // it any earlier (e.g. inside prepareStudioLoginContext, before login)
    // finds nothing yet and silently leaves actualOrg undefined.
    setOrgActual(getSiteProjectId() || CBE_BASE_PROJECT);

    // Host requires a session (real domain) and none exists: show the sign-in
    // page (collab-auth redirect). The 'login' action itself never logs anyone
    // in — it only delivers studio sources once a JWT session exists.
    showLoginGateIfNeeded();

    // NOTE: the storage drivers are deliberately NOT registered here. They are
    // instantiated on demand, when the studio opens (initStudio.loadProjectDefinitions,
    // reached by Ctrl+Alt+S, and studioHeader) — an app visitor never reads a .ts
    // source, so an app page pays nothing for them. The cost of this choice: any
    // source read attempted before the studio opens finds an empty slot.

    // Preload mls.stor.files for the site's project + dependencies. This is
    // what "opening" a project in the studio does; here everything resolves
    // from the IndexedDB the login just filled (the driver is only consulted
    // on a cache miss), so no external call happens on the VM.
    await preloadStorFiles(mls);

    const keys = await mls.stor.localDB.getAllKeys();
    // Signals the shell that the mini-studio env is FULLY ready (login done,
    // stor preloaded) — the structure upgrade waits for this, not just for
    // window.mls, or the nav service scan runs against a half-filled store.
    (window as unknown as { collabMiniCfeReady?: boolean }).collabMiniCfeReady = true;
    const elapsed = Math.round(performance.now() - t0);
    console.info(
      `[cbeMiniCfe] studio environment ready in ${elapsed}ms`,
      {
        loginStatus: rc?.statusCode,
        loginUser: getLoginUser() || 'anonymous',
        orgs: Object.keys(mls.stor.orgs),
        indexedDbKeys: keys.length,
        storFiles: Object.keys(mls.stor.files).length,
      },
    );
  } catch (err) {
    // The app page must render regardless of the studio bootstrap outcome.
    console.warn('[cbeMiniCfe] studio bootstrap skipped:', err);
    // Even a failed bootstrap must offer sign-in on a gated host.
    showLoginGateIfNeeded();
  }
}

/** The site's project id from the boot config (0 when absent/invalid). */
function getSiteProjectId(): number {
  const boot = (window as unknown as { collabBoot?: { projectId?: string | number } }).collabBoot;
  const projectId = Number(boot?.projectId) || 0;
  return projectId >= 100000 ? projectId : 0;
}

/**
 * Aligns the login request with the studio's shape: mls.actualProject = the
 * site's project, and a collabNav1 marker carrying initialproject=100554 so
 * the cfe sends baseProject exactly like on.collab.codes does.
 */
function prepareStudioLoginContext(mls: NonNullable<Window['mls']>): void {
  const projectId = getSiteProjectId();
  if (projectId && typeof mls.setActualProject === 'function') {
    mls.setActualProject(projectId);
  }
  if (!document.getElementById('collabNav1')) {
    const marker = document.createElement('meta');
    marker.id = 'collabNav1';
    marker.setAttribute('initialproject', String(CBE_BASE_PROJECT));
    document.head.appendChild(marker);
  }
}

/**
 * Loads into mls.stor.files the site's project and the studio base project
 * (100554), each with its transitive dependencies. The base project chain is
 * what studio widgets mounted in the shell aside (collab-messages) will need.
 */
async function preloadStorFiles(mls: NonNullable<Window['mls']>): Promise<void> {
  const projectId = getSiteProjectId();
  if (!projectId) {
    console.warn('[cbeMiniCfe] preload skipped: no valid collabBoot.projectId');
    return;
  }
  const seen = new Set<number>();
  for (const root of [projectId, CBE_BASE_PROJECT]) {
    try {
      await mls.stor.server.loadProjectInfoIfNeeded(root);
      const pending: number[] = [root];
      while (pending.length > 0) {
        const current = pending.shift() as number;
        if (seen.has(current)) continue;
        seen.add(current);
        const loadedDeps = await mls.stor.loadProjectdependenciesInfoIfNeed(current);
        pending.push(...loadedDeps);
      }
    } catch (err) {
      console.warn(`[cbeMiniCfe] preload of stor.files failed for project ${root}:`, err);
    }
  }
}

// Fire-and-forget: the shell mounts independently of the studio bootstrap.
void initCbeMiniCfe();
