/// <mls fileReference="_102033_/l2/cbe/studioDraftL2.ts" enhancement="_blank" />
// Compile, in this browser, the l2 sources the current draft changed against main.
// The draft text comes from /exec.
// It is applied on the editor model directly: storFile.getContent() would return production,
// except an included path that still has a local copy. That text is getContent(), the same text Save sent.

const DRAFT_SLUG = /^(team|user)-[a-z0-9_.-]{1,64}$/;
const L2_STATUS = new Set(['A', 'M', 'R']);
const L2_IMPORT = /^\/?_(\d+)_\/l2\/(.+?)(\.js)?$/;
/** One cache since st32. The draft copy is the same name with `~<slug>` before `?v=`. */
const DRAFT_CACHE_NAME = 'mls-v2';
/** `/local/_<project>_<path>.js~<slug>?v=<17 digits or sha>`. Production has no `~`. */
const DRAFT_COMPILED_L2_URL = /^\/local\/_(\d+)_(.+)\.js~([^?]+)\?v=([^&]+)$/;

export interface DraftDiffName {
  status: string;
  path: string;
  /** Blob sha from `draftDiff`. `null` when the server has none. */
  sha: string | null;
}

interface StaleCacheRequest {
  url: string;
}

interface StaleCache {
  keys(): Promise<Iterable<StaleCacheRequest>>;
  delete(request: StaleCacheRequest): Promise<boolean>;
}

interface StaleCacheStorage {
  keys(): Promise<string[]>;
  open(name: string): Promise<StaleCache>;
}

export interface ForgetStaleDeps {
  caches?: StaleCacheStorage;
  hasLocalEdit(project: number, path: string): boolean;
}

interface L2File {
  folder: string;
  shortName: string;
}

/** Compiled l2 sent to the service worker. `path` is `_project_folder/name.js`, with no `-d<slug>` cache. */
export interface DraftCompiledJs {
  path: string;
  version: string;
  content: string;
}

/** Same body as `mls.stor.cache.addIfNeed` (`mls.js` `addIfNeed`), plus the draft slug. */
export interface DraftWorkerAdd {
  action: 'add';
  path: string;
  version: string;
  content: string;
  contentType: 'application/javascript';
  draft: string;
}

export interface PublishDraftL2Deps {
  draftDiff(project: number, slug: string): Promise<{ head: string; files: DraftDiffName[] }>;
  /** One `getContents` for every path still missing from the service worker. */
  readDraftTexts(project: number, paths: readonly string[]): Promise<ReadonlyMap<string, string>>;
  apply(project: number, path: string, text: string): Promise<void>;
  /** `saveCache` is false. `null` when the compile produced nothing to send. */
  compile(project: number, path: string): Promise<DraftCompiledJs | null>;
  postAdd(message: DraftWorkerAdd): Promise<unknown>;
  hasLocalEdit(project: number, path: string): boolean;
  /** `getURL` with `sha`. A string means that draft copy is already in the service worker. */
  cachedDraft(project: number, path: string, sha: string): Promise<string | null>;
  /** Included local edit. Production reads `mls.stor.files[key].getContent()`. */
  readLocalText?(project: number, path: string): Promise<string | null>;
}

export interface L2ImportFile {
  project: number;
  folder: string;
  shortName: string;
}

function errorText(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** l2 TypeScript sources, excluding tests and declarations. Folder may be nested. */
function parseL2Ts(path: string): L2File | undefined {
  if (!path.startsWith('l2/') || !path.endsWith('.ts')) return undefined;
  if (path.endsWith('.d.ts') || path.endsWith('.test.ts')) return undefined;
  const rest = path.slice(3, -3);
  if (rest.length === 0 || rest.startsWith('/') || rest.endsWith('/')) return undefined;
  const slash = rest.lastIndexOf('/');
  const folder = slash === -1 ? '' : rest.slice(0, slash);
  const shortName = slash === -1 ? rest : rest.slice(slash + 1);
  if (!shortName || (slash !== -1 && !folder)) return undefined;
  return { folder, shortName };
}

/** `/_102047_/l2/a/b/c.js` → the stor identity of that l2 source. Anything else → null. */
export function importToL2File(importName: string): L2ImportFile | null {
  const match = L2_IMPORT.exec(importName);
  if (!match) return null;
  const rest = match[2];
  const slash = rest.lastIndexOf('/');
  const folder = slash === -1 ? '' : rest.slice(0, slash);
  const shortName = slash === -1 ? rest : rest.slice(slash + 1);
  if (!shortName || (slash !== -1 && !folder)) return null;
  return { project: Number(match[1]), folder, shortName };
}

export function draftL2Targets(files: { status: string; path: string }[]): string[] {
  const targets: string[] = [];
  for (const file of files) {
    if (!L2_STATUS.has(file.status)) continue;
    if (!parseL2Ts(file.path)) continue;
    targets.push(file.path);
  }
  return targets;
}

async function postExec(body: Record<string, unknown>): Promise<unknown> {
  let response: Response;
  try {
    response = await fetch('/exec', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch (err) {
    throw new Error(errorText(err));
  }
  let parsed: unknown;
  try {
    parsed = await response.json();
  } catch (err) {
    throw new Error(errorText(err));
  }
  if (!response.ok) {
    const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : `HTTP ${response.status}`;
    throw new Error(msg);
  }
  return parsed;
}

async function requestDraftDiff(project: number, slug: string): Promise<{ head: string; files: DraftDiffName[] }> {
  const parsed = await postExec({ action: 'draftDiff', project, draft: slug, names: true });
  if (!isRecord(parsed) || parsed.status !== 'files' || typeof parsed.head !== 'string' || parsed.head.length === 0) {
    const code = isRecord(parsed) && typeof parsed.code === 'string' ? parsed.code : 'bad response';
    throw new Error(code);
  }
  if (!Array.isArray(parsed.files)) throw new Error('draftDiff response has no files array');
  const files: DraftDiffName[] = [];
  for (const item of parsed.files) {
    if (!isRecord(item) || typeof item.status !== 'string' || typeof item.path !== 'string') {
      throw new Error('draftDiff file entry is invalid');
    }
    const sha = item.sha;
    if (typeof sha !== 'string' && sha !== null) throw new Error('draftDiff file entry is invalid');
    files.push({ status: item.status, path: item.path, sha });
  }
  return { head: parsed.head, files };
}

async function requestDraftTexts(project: number, paths: readonly string[]): Promise<Map<string, string>> {
  const texts = new Map<string, string>();
  if (paths.length === 0) return texts;
  const parsed = await postExec({ action: 'getContents', project, shortPaths: [...paths] });
  if (!isRecord(parsed) || parsed.statusCode !== 200 || !Array.isArray(parsed.files)) {
    const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : 'getContents failed';
    throw new Error(msg);
  }
  for (const item of parsed.files) {
    if (!isRecord(item) || typeof item.shortPath !== 'string') {
      console.error('[studioDraftL2] getContents file entry is invalid');
      continue;
    }
    if (typeof item.content !== 'string') {
      console.error(`[studioDraftL2] ${item.shortPath}: getContents missing content`);
      continue;
    }
    texts.set(item.shortPath, item.encoding === 'base64' ? atob(item.content) : item.content);
  }
  return texts;
}

function l2FileBase(project: number, loc: L2File): mls.stor.IFileInfoBase {
  return {
    project,
    level: 2,
    shortName: loc.shortName,
    folder: loc.folder,
    extension: '.ts',
  };
}

function storFileFor(project: number, loc: L2File): mls.stor.IFileInfo {
  const base = l2FileBase(project, loc);
  const existing = mls.stor.files[mls.stor.getKeyToFile(base)];
  if (existing) return existing;
  // Not registered yet (a file the draft added). Identity fields are enough for
  // createModelTS and the cache key; getContent would serve the release.
  const unused = (name: string) => Promise.reject(new Error(`[studioDraftL2] ${name} is not used`));
  return {
    ...base,
    versionRef: '',
    projectDependencies: null,
    isLocalVersionOutdated: false,
    inLocalStorage: false,
    status: 'nochange',
    hasError: false,
    getContent: () => unused('getContent'),
    getHistory: () => unused('getHistory'),
    getHistoryContent: () => unused('getHistoryContent'),
    saveContentInCacheIfNeed: () => unused('saveContentInCacheIfNeed'),
    getOrCreateModel: () => unused('getOrCreateModel'),
  };
}

export async function applyDraft(project: number, path: string, text: string): Promise<void> {
  const loc = parseL2Ts(path);
  if (!loc) throw new Error(`not an l2 source: ${path}`);
  const existing = mls.editor.getModels(project, loc.shortName, loc.folder, 2)?.ts;
  const model = existing ?? await mls.editor.createModelTS(storFileFor(project, loc), text);
  model.model.setValue(text);
  const { setModelEventAny } = await import('/_102027_/l2/libModel.js');
  await setModelEventAny(model, model.storFile);
}

function workerPath(project: number, loc: L2File): string {
  return `_${project}_${loc.folder ? `${loc.folder}/` : ''}${loc.shortName}.js`;
}

/** Compiles one l2 source and keeps the bytes. `saveCache` stays false: the worker stores the draft copy. */
export async function compileDraftForWorker(project: number, path: string): Promise<DraftCompiledJs | null> {
  const loc = parseL2Ts(path);
  if (!loc) throw new Error(`not an l2 source: ${path}`);
  const model = mls.editor.getModels(project, loc.shortName, loc.folder, 2)?.ts;
  if (!model) throw new Error(`model missing: ${path}`);
  if (model.compilerResults) model.compilerResults.modelNeedCompile = true;
  const ok = await mls.l2.typescript.compileAndPostProcess(model, true, false);
  if (!ok) return null;
  const version = model.compilerResults?.cacheVersion;
  const content = model.compilerResults?.prodJS;
  if (!version || !content) {
    console.error(`[studioDraftL2] ${path}: compile produced no version or prodJS`);
    return null;
  }
  return { path: workerPath(project, loc), version, content };
}

/** `addIfNeed` posts `{action:'add', path, version, content, contentType}` on `registration.active`. This adds `draft`. */
async function postDraftAdd(message: DraftWorkerAdd): Promise<unknown> {
  const sw = globalThis.navigator?.serviceWorker;
  if (!sw || typeof MessageChannel === 'undefined') {
    throw new Error('service workers are not supported in this browser');
  }
  const registration = await sw.ready;
  const worker = registration.active;
  if (!worker) throw new Error('no active service worker to receive the message');
  const channel = new MessageChannel();
  const nodePort = channel.port1 as MessagePort & { unref?: () => void };
  nodePort.unref?.();
  (channel.port2 as MessagePort & { unref?: () => void }).unref?.();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      channel.port1.close();
      reject(new Error('service worker add timed out'));
    }, 3000);
    channel.port1.onmessage = (event: MessageEvent) => {
      clearTimeout(timer);
      channel.port1.close();
      const data: unknown = event.data;
      if (typeof data === 'string' && data.startsWith('Error')) {
        reject(new Error(data));
        return;
      }
      resolve(data);
    };
    try {
      worker.postMessage(message, [channel.port2]);
    } catch (err) {
      clearTimeout(timer);
      channel.port1.close();
      reject(err instanceof Error ? err : new Error(errorText(err)));
    }
  });
}

/** `/local/_<project>_….js~<slug>?v=…` of this draft → `l2/….ts`. Production, another slug, another project → undefined. */
function compiledDraftL2Source(project: number, slug: string, url: string): string | undefined {
  let path = url;
  if (!path.startsWith('/')) {
    try {
      const parsed = new URL(url);
      path = parsed.pathname + parsed.search;
    } catch (err) {
      console.error(`[studioDraftL2] ${url}: ${errorText(err)}`);
      return undefined;
    }
  }
  const match = DRAFT_COMPILED_L2_URL.exec(path);
  if (!match || Number(match[1]) !== project || match[3] !== slug || match[4].length === 0) return undefined;
  return `l2/${match[2]}.ts`;
}

function browserCaches(): StaleCacheStorage | undefined {
  return (globalThis.caches as StaleCacheStorage | undefined) ?? undefined;
}

/** Drop `~<slug>` l2 entries in `mls-v2` that are no longer in `keep` or a local edit. Production keys stay. */
export async function forgetStaleDraftL2(
  project: number,
  slug: string,
  keep: ReadonlySet<string>,
  deps: Partial<ForgetStaleDeps> = {},
): Promise<number> {
  const caches = deps.caches ?? browserCaches();
  const hasLocalEdit = deps.hasLocalEdit ?? defaultHasLocalEdit;
  const count = caches ? await deleteStaleCompiled(project, slug, keep, caches, hasLocalEdit) : 0;
  console.info(`[studioDraftL2] forgot ${count} compiled l2 entries`);
  return count;
}

async function deleteStaleCompiled(
  project: number,
  slug: string,
  keep: ReadonlySet<string>,
  caches: StaleCacheStorage,
  hasLocalEdit: (project: number, path: string) => boolean,
): Promise<number> {
  let names: string[];
  try {
    names = await caches.keys();
  } catch (err) {
    console.warn(`[studioDraftL2] forget stale caches: ${errorText(err)}`);
    return 0;
  }
  if (!names.includes(DRAFT_CACHE_NAME)) return 0;
  let cache: StaleCache;
  try {
    cache = await caches.open(DRAFT_CACHE_NAME);
  } catch (err) {
    console.warn(`[studioDraftL2] forget stale ${DRAFT_CACHE_NAME}: ${errorText(err)}`);
    return 0;
  }
  let requests: Iterable<StaleCacheRequest>;
  try {
    requests = await cache.keys();
  } catch (err) {
    console.warn(`[studioDraftL2] forget stale ${DRAFT_CACHE_NAME}: ${errorText(err)}`);
    return 0;
  }
  let count = 0;
  for (const request of requests) {
    const source = compiledDraftL2Source(project, slug, request.url);
    if (!source || keep.has(source)) continue;
    let local = false;
    try {
      local = hasLocalEdit(project, source);
    } catch (err) {
      console.error(`[studioDraftL2] ${source}: ${errorText(err)}`);
      continue;
    }
    if (local) continue;
    try {
      if (await cache.delete(request)) count += 1;
    } catch (err) {
      console.error(`[studioDraftL2] ${request.url}: ${errorText(err)}`);
    }
  }
  return count;
}

/** `getURL` with the draft sha. Studio mode looks up the draft copy before the release copy. */
async function cachedDraftUrl(project: number, path: string, sha: string): Promise<string | null> {
  const loc = parseL2Ts(path);
  if (!loc) {
    console.error(`[studioDraftL2] ${path}: cache check is not an l2 source`);
    return null;
  }
  return mls.stor.cache.getURL(project, loc.folder || null, loc.shortName, '.js', sha);
}

const defaultPublishDeps: PublishDraftL2Deps = {
  draftDiff: requestDraftDiff,
  readDraftTexts: requestDraftTexts,
  apply: applyDraft,
  compile: compileDraftForWorker,
  postAdd: postDraftAdd,
  hasLocalEdit: defaultHasLocalEdit,
  cachedDraft: cachedDraftUrl,
};

interface PendingDraftL2 {
  path: string;
  version: string;
  /** Set when the text is the local copy, not `getContents`. */
  localText?: string;
}

/** CRC of the local source. The service worker stores this as `?v=` so a saved copy is not the cached sha. */
function textCrc(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      const mask = -(crc & 1);
      crc = (crc >>> 1) ^ (0xedb88320 & mask);
    }
  }
  return ((crc ^ 0xffffffff) >>> 0).toString(16).padStart(8, '0');
}

async function defaultReadLocalText(project: number, path: string): Promise<string | null> {
  const loc = parseL2Ts(path);
  if (!loc) return null;
  const file = mls.stor.files[mls.stor.getKeyToFile(l2FileBase(project, loc))];
  if (!file) return null;
  const content = await file.getContent();
  return typeof content === 'string' ? content : null;
}

async function localTextOf(deps: PublishDraftL2Deps, project: number, path: string): Promise<string | null> {
  const read = deps.readLocalText ?? defaultReadLocalText;
  try {
    const text = await read(project, path);
    if (typeof text !== 'string') {
      console.error(`[studioDraftL2] ${path}: local text is missing`);
      return null;
    }
    return text;
  } catch (err) {
    console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
    return null;
  }
}

/**
 * l2 sources the draft changed: skip a sha the service worker already has, read the rest in one
 * `getContents`, apply them, then compile and send `{action:'add', draft:slug}` with `version: sha`.
 * A local edit is left as it is, unless its path is in `include` (Save already matched the accepted draft).
 * That copy is compiled from `getContent` and sent with the CRC of that text.
 * Does not reload and does not touch a `-d<slug>` cache.
 * `keep` is every l2 path still in the diff. It is `null` when the diff was not read.
 */
export interface PublishDraftL2Result {
  sent: number;
  keep: ReadonlySet<string> | null;
}

export async function publishDraftL2(
  project: number,
  slug: string,
  deps: PublishDraftL2Deps = defaultPublishDeps,
  known?: { head: string; files: DraftDiffName[] },
  include?: readonly string[],
): Promise<PublishDraftL2Result> {
  if (!DRAFT_SLUG.test(slug)) {
    console.error(`[studioDraftL2] ${slug}: draft slug is invalid; versions were not sent`);
    return { sent: 0, keep: null };
  }
  let diff: { head: string; files: DraftDiffName[] };
  if (known) {
    diff = known;
  } else {
    try {
      diff = await deps.draftDiff(project, slug);
    } catch (err) {
      console.error(`[studioDraftL2] draftDiff: ${errorText(err)}`);
      return { sent: 0, keep: null };
    }
  }
  const byPath = new Map(diff.files.map((file) => [file.path, file]));
  const included = new Set(include ?? []);
  const keep = new Set(draftL2Targets(diff.files));
  const pending: PendingDraftL2[] = [];
  for (const path of draftL2Targets(diff.files)) {
    const local = deps.hasLocalEdit(project, path);
    if (local && !included.has(path)) {
      console.info(`[studioDraftL2] ${path}: local edit kept`);
      continue;
    }
    if (local) {
      const localText = await localTextOf(deps, project, path);
      if (localText === null) continue;
      const version = textCrc(localText);
      let cached: string | null = null;
      try {
        cached = await deps.cachedDraft(project, path, version);
      } catch (err) {
        console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
      }
      if (cached) continue;
      pending.push({ path, version, localText });
      continue;
    }
    const sha = byPath.get(path)?.sha;
    if (typeof sha !== 'string' || sha.length === 0) {
      console.error(`[studioDraftL2] ${path}: draft sha is missing; compiled copy was not sent`);
      continue;
    }
    let cached: string | null = null;
    try {
      cached = await deps.cachedDraft(project, path, sha);
    } catch (err) {
      console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
    }
    if (cached) continue;
    pending.push({ path, version: sha });
  }
  if (pending.length === 0) return { sent: 0, keep };
  const texts = new Map<string, string>();
  for (const item of pending) {
    if (item.localText !== undefined) texts.set(item.path, item.localText);
  }
  const draftPaths = pending.filter((item) => item.localText === undefined).map((item) => item.path);
  if (draftPaths.length > 0) {
    try {
      const read = await deps.readDraftTexts(project, draftPaths);
      for (const [path, text] of read) texts.set(path, text);
    } catch (err) {
      console.error(`[studioDraftL2] getContents: ${errorText(err)}`);
      if (texts.size === 0) return { sent: 0, keep };
    }
  }
  const applied: PendingDraftL2[] = [];
  for (const item of pending) {
    const text = texts.get(item.path);
    if (text === undefined) {
      console.error(`[studioDraftL2] ${item.path}: getContents missing content`);
      continue;
    }
    try {
      await deps.apply(project, item.path, text);
      applied.push(item);
    } catch (err) {
      console.error(`[studioDraftL2] ${item.path}: ${errorText(err)}`);
    }
  }
  let sent = 0;
  for (const item of applied) {
    try {
      const compiled = await deps.compile(project, item.path);
      if (!compiled) {
        console.error(`[studioDraftL2] ${item.path}: compile failed`);
        continue;
      }
      await deps.postAdd({
        action: 'add',
        path: compiled.path,
        version: item.version,
        content: compiled.content,
        contentType: 'application/javascript',
        draft: slug,
      });
      sent += 1;
    } catch (err) {
      console.error(`[studioDraftL2] ${item.path}: ${errorText(err)}`);
    }
  }
  return { sent, keep };
}

function defaultHasLocalEdit(project: number, path: string): boolean {
  const loc = parseL2Ts(path);
  if (!loc) {
    console.error(`[studioDraftL2] ${path}: local edit check is not an l2 source`);
    return false;
  }
  const base = l2FileBase(project, loc);
  return mls.stor.files[mls.stor.getKeyToFile(base)]?.inLocalStorage === true;
}
