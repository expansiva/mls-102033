declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102033_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102029_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102033_/l2/utils" {
    export interface IFileInfoBase {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    export interface IResolvedFile {
        project: number;
        shortName: string;
        folder: string;
    }
    export function resolveTagToFile(tag: string): IResolvedFile | undefined;
    export function convertFileToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function isPageFile(folder: string): boolean;
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102029_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102029_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102033_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { TemplateResult, PropertyValues } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class MoleculeAuraElement extends StateLitElement {
        cssClass: string;
        protected slotTags: string[];
        /**
         * Opt in to LIVE slots: the consumer's slot content is MOVED into place as real
         * DOM nodes, instead of being read as a string and re-emitted with unsafeHTML.
         *
         * Why this exists: the snapshot path serializes slot children via `outerHTML` and
         * re-parses them. Serializing destroys event bindings and component identity, so
         * anything interactive the consumer puts in a slot is dead on arrival — and nested
         * molecules had to be made inert to keep the parent's snapshot readable. That makes
         * slots content-only, which defeats composition.
         *
         * With live slots the nodes are never serialized: they are moved, and moving preserves
         * listeners, Lit part references and nested custom elements. A molecule that opts in
         * also stops forcing its slotted descendants to be inert — they render normally.
         *
         * Opt-in per molecule so the two mechanisms coexist. Keep the snapshot path where the
         * slot carries DATA to be parsed (`TableHead key=…`, `Item value=…`); use live slots
         * where it carries CONTENT or CONTROLS (`Action`, `Label`, `Icon`, `Trigger`).
         */
        protected usesLiveSlots: boolean;
        /**
         * The consumer's live nodes, per slot tag, held by reference.
         *
         * Holding them is what makes the mechanism survive the anchor coming and going. When a
         * template branch leaves the render (a hidden modal, a collapsed region), Lit removes
         * the anchor and everything under it — including these nodes. Removing a node from the
         * DOM does not destroy it while something still references it, and its listeners stay
         * attached, so the next projection can simply put it back.
         */
        private _liveNodes;
        /** Last anchor that held each key — see `_currentNodes`. */
        private _liveHosts;
        /** Detached holder per key, so eviction does not lose content. */
        private _liveHolders;
        /**
         * Per-element anchors, for molecules that don't pass a slot through but TRANSFORM it.
         *
         * A table is the motivating case: it reads `TableBody > TableRow > TableCell`, sorts and
         * paginates, then re-emits real `<tr>`/`<td>`. The source of a cell's content is a nested
         * element, not a direct child, and there are N×M of them — so an anchor keyed by tag name
         * can't address it. These map an id to the source element instead.
         *
         * The id lives in a WeakMap so the SAME element always gets the SAME id across renders,
         * which is what lets `_liveNodes` survive a row leaving the page and coming back.
         */
        private _liveRefSeq;
        private _liveRefIds;
        private _liveRefs;
        /**
         * Renders the placeholder where a live slot's content lands.
         *
         * The anchor must stay free of Lit bindings: Lit does not manage children it did not
         * create, so nodes appended here survive every re-render. Put bindings around the
         * anchor, never inside it.
         */
        protected renderLiveSlot(tag: string, cls?: string): TemplateResult;
        /**
         * Same as `renderLiveSlot`, but bound to a specific source ELEMENT instead of a tag.
         *
         * Use it when the molecule transforms the slot structure and one tag maps to many
         * destinations — a table cell, a list item. Pass the LIVE element (from `getLiveSlot`),
         * never a snapshot clone: a clone's children are copies, and moving copies projects
         * dead nodes.
         */
        protected renderLiveSlotFrom(source: Element | null | undefined, cls?: string): TemplateResult;
        /**
         * Text currently rendered for a source element, projected or not.
         *
         * A transforming molecule that sorts or filters by cell text cannot read the source
         * element after projection — its children were moved out, so `textContent` is empty.
         * This reads the projected nodes instead, which keeps the value CURRENT: caching the
         * text at capture time would go stale the moment the consumer changed it.
         */
        protected getLiveText(source: Element | null | undefined): string;
        /**
         * The LIVE slot element for `tag` — not the snapshot clone.
         *
         * Structure reads (how many rows, which attributes) should come from here in a molecule
         * that projects, because the snapshot goes stale between mutations and, worse, a
         * re-snapshot after projection reads the emptied sources.
         */
        protected getLiveSlot(tag: string): Element | null;
        /**
         * Moves each live slot's children into its anchor.
         *
         * Runs from `update()` — right after Lit commits the DOM, so the anchors exist. It is
         * deliberately NOT in `updated()`: most molecules override that without calling super,
         * which would silently skip projection.
         */
        private _projectLiveSlots;
        /** Capture-once + reattach-when-empty, shared by both anchor kinds. */
        private _fillAnchor;
        /**
         * Holder per key: a detached element where the nodes wait while they have no anchor.
         * It exists so eviction does not lose content.
         */
        private _holderFor;
        /**
         * The CURRENT nodes for a key, which are not always the captured ones.
         *
         * `_liveNodes` is the list taken at capture time. It goes stale when the consumer REPLACES the
         * slot's content instead of just updating values — `${loading ? spinner : table}`, for example:
         * Lit removes the old nodes and inserts different ones between the same markers, which are
         * still in the anchor. Reattaching the capture list would hand back only the already-discarded
         * nodes, and the region would come back EMPTY when reopened. Measured on 2026-08-04 with
         * demotable--pedidosdetalhe: opening, closing and opening again showed a blank row.
         *
         * Hence the order of preference: the last anchor that held the key (Lit removes the anchor from
         * the DOM, but its children stay INSIDE it), then the holder, and only then the capture.
         */
        private _currentNodes;
        /** The consumer's slot element for `tag`, among this element's own children. */
        private _findSlotChild;
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        _mutationLock: boolean;
        connectedCallback(): void;
        /**
         * Projection hook.
         *
         * `update()` is where Lit commits the template to the DOM, so the anchors exist right
         * after `super.update()`. Chosen over `updated()` on purpose: most molecules override
         * `updated()` without calling super, and projection would silently never run. No
         * molecule overrides `update()`.
         */
        protected update(changed: PropertyValues): void;
        disconnectedCallback(): void;
        private _stopNativeFormEvent;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
        protected getSlotClass(tag: string): string;
    }
}
declare module "_102033_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102033_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/cbe/cbeMiniCfe" {
    global {
        interface Window {
            mls?: {
                api: {
                    cbeLogin: () => Promise<{
                        statusCode: number;
                    } | undefined>;
                };
                stor: {
                    orgs: Record<string, unknown>;
                    files: Record<string, unknown>;
                    localDB: {
                        getAllKeys: () => Promise<string[]>;
                    };
                    cache: {
                        installIfNeeded: () => Promise<unknown>;
                    };
                    server: {
                        loadProjectInfoIfNeeded: (project: number, forceUpdate?: boolean) => Promise<boolean>;
                    };
                    loadProjectdependenciesInfoIfNeed: (project: number, forceUpdate?: boolean) => Promise<number[]>;
                };
            };
        }
    }
    export function initCbeMiniCfe(): Promise<void>;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        languages?: string[];
        designSystem?: string;
        designSystems?: string[];
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102033_/l2/core/bff-client" {
    export * from "_102029_/l2/bffClient";
}
declare module "_102033_/l2/core/bff-client.test" { }
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102033_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/languageRuntime" {
    type RuntimeLanguageDocument = {
        documentElement: {
            lang: string;
        };
        querySelectorAll: (selector: string) => ArrayLike<unknown> | Iterable<unknown>;
    };
    export function listRuntimeLanguages(languages: readonly string[] | undefined): string[];
    export function resolveRuntimeLanguage(languages: readonly string[], requestedLanguage: string): string | undefined;
    export function getRuntimeLanguage(languages: readonly string[], documentLanguage: string): string | undefined;
    export function getNextRuntimeLanguage(languages: readonly string[], documentLanguage: string): string | undefined;
    export function setRuntimeLanguage(requestedLanguage: string, languages: readonly string[], runtimeDocument?: RuntimeLanguageDocument): void;
}
declare module "_102033_/l2/shared/designSystemRuntime" {
    type RuntimeDesignSystemStyle = {
        id: string;
        textContent: string | null;
        dataset: Record<string, string | undefined>;
    };
    type RuntimeDesignSystemDocument = {
        getElementById: (id: string) => RuntimeDesignSystemStyle | null;
        createElement: (tagName: string) => RuntimeDesignSystemStyle;
        head: {
            appendChild: (element: RuntimeDesignSystemStyle) => unknown;
        };
    };
    type DesignSystemCssLoader = (name: string, path: string) => Promise<string>;
    export function listRuntimeDesignSystems(designSystems: readonly string[] | undefined): string[];
    export function resolveRuntimeDesignSystem(designSystems: readonly string[], requestedDesignSystem: string): string | undefined;
    export function getRuntimeDesignSystem(designSystems: readonly string[], runtimeDocument?: RuntimeDesignSystemDocument): string | undefined;
    export function getNextRuntimeDesignSystem(designSystems: readonly string[], currentDesignSystem: string | undefined): string | undefined;
    export function setRuntimeDesignSystem(requestedDesignSystem: string, designSystems: readonly string[], projectId: string, runtimeDocument?: RuntimeDesignSystemDocument, loadCss?: DesignSystemCssLoader): Promise<void>;
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: MasterFrontendRouteDefinition[], pathname: string): MasterFrontendRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { MasterFrontendBootConfig, MasterFrontendDeviceKind, MasterFrontendInteractionState, MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: MasterFrontendInteractionState;
        resolvedDevice: MasterFrontendDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: MasterFrontendRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        private dynamicRegionRenderers;
        private dynamicRegionProps;
        private activeAsideWidthPx?;
        private contentVariantRenderer?;
        private sitesRetryTimer?;
        private sitesRetriesLeft;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly setHeaderRenderer;
        private readonly setAsideRenderer;
        private readonly setShellProfile;
        private setRegionProfile;
        private setRegionRenderer;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private initializeDynamicRegions;
        private getRegionProfile;
        private getRegionPropsFromProfile;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getAsideWidthPx;
        private getAsideDrawerWidthPx;
        private getRegionProps;
        private getActiveContentRenderer;
        private applyContentPageGenome;
        private getAvailableUxLayouts;
        private listLanguages;
        private getLanguage;
        private setLanguage;
        private rotateLanguage;
        private listDS;
        private getDS;
        private setDS;
        private rotateDesignSystem;
        private rotateContentVariant;
        private readonly registerSitesControls;
        private getRegionProfileNames;
        private getRegionIndex;
        private setRegionByIndex;
        private getContentPageGenome;
        private setContentPage;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102033_/l2/shared/chartRuntime" {
    import * as echarts from 'echarts/core';
    export { echarts };
    export type { ECharts, EChartsCoreOption } from 'echarts/core';
    /**
     * Handlers for ECharts events, by event name (`click`, `legendselectchanged`, `datazoom`, …).
     *
     * ECharts events do NOT reach the DOM: they are emitted on the instance via `chart.on(...)`, so
     * `@chartclick=${…}` in a Lit template is a listener that never fires — and it COMPILES, because any
     * `@name` is a valid Lit binding. A generated page wrote exactly that, which is why the handlers must
     * come through the directive instead.
     */
    export type ChartEvents = Record<string, (params: never) => void>;
    /**
     * Bind an ECharts option to the element this directive sits on.
     *
     * @param option a full EChartsCoreOption. Every chart type and component this runtime registers above is
     *        available — no `echarts.use()` needed at the call site, which is the whole point of the module:
     *        an unregistered piece renders BLANK with no error.
     * @param events optional handlers, e.g. `{ click: (p) => this.selectCategory(p.name) }`. Rebound on every
     *        update, so a closure over fresh state is always the one that runs.
     *
     * The element must have a height (ECharts measures its container; a container of height 0 draws nothing).
     */
    export const chart: any;
}
declare module "_102033_/l2/shared/designSystemRuntime.test" { }
declare module "_102033_/l2/shared/interactionRuntime.test" { }
declare module "_102033_/l2/shared/languageRuntime.test" { }
declare module "_102033_/l2/shared/routeRuntime.test" { }
declare module "_102033_/l2/shared/shell.defs" {
    export const skill: {
        readonly componentId: "collab-aura-shell";
        readonly purpose: "Render the frontend shell, expose header/aside/content regions, and mount module-owned region renderers.";
        readonly responsibilities: readonly ["Read the boot config injected by the server runtime.", "Resolve the active device from the viewport and module preferences.", "Render the shell layout and region visibility state.", "Control the aside mode as inline, drawer, or fullscreen.", "Load the module renderers for header, aside, and content.", "Apply Aura fallback renderers when a module does not define header or aside.", "Mount the active renderer into each region host."];
        readonly regions: readonly ["header", "aside", "content"];
        readonly supportedDevices: readonly ["desktop", "mobile"];
        readonly supportedShellModes: readonly ["spa", "pwa"];
    };
}
declare module "_102033_/l2/shared/layout/aura-contents" {
    import { LitElement } from 'lit';
    export class AuraContents extends LitElement {
        createRenderRoot(): this;
        render(): any;
    }
}
declare module "_102033_/l2/shared/molecules/cn" {
    export function cn(...inputs: (string | undefined | null | false)[]): string;
}
declare module "_102033_/l2/shared/molecules/tableSort" {
    /**
     * The value the cell wants to be sorted by.
     *
     * Sorting by TEXT is misleading in every column whose text does not sort like the data: masked
     * currency, `dd/mm/yyyy` dates, status labels. That is why a cell may declare its real value:
     *
     *     <TableCell sort-value="987">R$ 987,00</TableCell>
     *     <TableCell sort-value="2026-01-02">2 de janeiro</TableCell>
     *
     * `liveText` is for molecules with live slots, which must read from the projected nodes instead of
     * the source `textContent` — the source is empty once projected.
     */
    export function cellSortKey(cell: Element | null | undefined, liveText?: string): string;
    /** Number out of formatted text. `null` when there is no recognizable number. */
    export function parseFormattedNumber(text: string): number | null;
    /**
     * Compares two keys: numeric when both are numbers, otherwise text with natural collation.
     * Always returns the ASCENDING order — direction is up to the caller.
     */
    export function compareSortKeys(a: string, b: string): number;
}
