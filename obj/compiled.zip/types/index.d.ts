declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102033_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class MoleculeAuraElement extends StateLitElement {
        protected slotTags: string[];
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        _mutationLock: boolean;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _stopNativeFormEvent;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
    }
}
declare module "_102033_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102033_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/core/bff-client.test" { }
declare module "_102029_/l2/contracts/bootstrap" {
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: MasterFrontendNavigationItem[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: MasterFrontendNavigationItem[];
        moduleLinks?: MasterFrontendNavigationItem[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        constructor();
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102033_/l2/core/bff-client" {
    export * from "_102029_/l2/bffClient";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102033_/l2/shared/bootstrap" {
    import '/_102033_/l2/shared/shell.js';
}
declare module "_102033_/l2/shared/interactionRuntime.test" { }
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102033_/l2/shared/routeRuntime.test" { }
declare module "_102033_/l2/shared/routeRuntime" {
    import type { MasterFrontendRouteDefinition } from '_102033_/l2/shared/contracts/bootstrap';
    export function matchAuraRoute(routes: MasterFrontendRouteDefinition[], pathname: string): MasterFrontendRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell.defs" {
    export const skill: {
        readonly componentId: "collab-aura-shell";
        readonly purpose: "Render the frontend shell, expose header/aside/content regions, and mount module-owned region renderers.";
        readonly responsibilities: readonly ["Read the boot config injected by the server runtime.", "Resolve the active device from the viewport and module preferences.", "Render the shell layout and region visibility state.", "Control the aside mode as inline, drawer, or fullscreen.", "Load the module renderers for header, aside, and content.", "Apply Aura fallback renderers when a module does not define header or aside.", "Mount the active renderer into each region host."];
        readonly regions: readonly ["header", "aside", "content"];
        readonly supportedDevices: readonly ["desktop", "mobile"];
        readonly supportedShellModes: readonly ["spa", "pwa"];
    };
}
declare module "_102033_/l2/shared/shell" {
    import type { MasterFrontendBootConfig, AuraDeviceKind, MasterFrontendInteractionState, MasterFrontendRouteDefinition } from '_102033_/l2/shared/contracts/bootstrap';
    import '/_102033_/l2/shared/layout/aura-aside.js';
    import '/_102033_/l2/shared/layout/aura-header.js';
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: MasterFrontendInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: MasterFrontendRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        private dynamicRegionRenderers;
        private dynamicRegionProps;
        private activeAsideWidthPx?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly setHeaderRenderer;
        private readonly setAsideRenderer;
        private readonly setShellProfile;
        private setRegionProfile;
        private setRegionRenderer;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private initializeDynamicRegions;
        private getRegionProfile;
        private getRegionPropsFromProfile;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getAsideWidthPx;
        private getAsideDrawerWidthPx;
        private getRegionProps;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from '_102033_/l2/shared/contracts/bootstrap';
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-contents" {
    import { LitElement } from 'lit';
    export class AuraContents extends LitElement {
        createRenderRoot(): this;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from '_102033_/l2/shared/contracts/bootstrap';
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102033_/l2/shellEvents";
}
