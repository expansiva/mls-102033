declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102033_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
     * mls.actualProject is the fallback when the boot payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102029_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102033_/l2/utils" {
    export interface IFileInfoBase {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    export interface IResolvedFile {
        project: number;
        shortName: string;
        folder: string;
    }
    export function resolveTagToFile(tag: string): IResolvedFile | undefined;
    export function convertFileToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function isPageFile(folder: string): boolean;
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102029_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102029_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102033_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { TemplateResult, PropertyValues } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    /**
     * Registra a tag da molécula UMA vez.
     *
     * O runtime pode acabar com duas cópias do mesmo módulo no mesmo documento: o
     * `dist/web` inlina a molécula num chunk, e o service worker do mls serve a
     * forma crua (do IndexedDB) para imports sem extensão e para `.defs.js`/
     * `.test.js` — caminho que o servidor nem vê. Com `@customElement`, a segunda
     * avaliação lança `already been used with this registry`, o módulo fica marcado
     * como falho no module map do browser e a rota morre até o reload.
     *
     * Isto só é seguro porque o Lit é UM só (mls-102033/l2/shared/litRuntime.json):
     * as duas cópias estendem o mesmo `ReactiveElement`, então ficar com a primeira
     * registrada é equivalente. Antes disso, a guarda seria máscara — deixaria um
     * componente construído sobre a classe base errada, e em silêncio.
     *
     * Devolve `true` quando registrou, `false` quando já havia.
     */
    export function defineMoleculeOnce(tag: string, ctor: CustomElementConstructor): boolean;
    export class MoleculeAuraElement extends StateLitElement {
        cssClass: string;
        protected slotTags: string[];
        /**
         * Opt in to LIVE slots: the consumer's slot content is MOVED into place as real
         * DOM nodes, instead of being read as a string and re-emitted with unsafeHTML.
         *
         * Why this exists: the snapshot path serializes slot children via `outerHTML` and
         * re-parses them. Serializing destroys event bindings and component identity, so
         * anything interactive the consumer puts in a slot is dead on arrival — and nested
         * molecules had to be made inert to keep the parent's snapshot readable. That makes
         * slots content-only, which defeats composition.
         *
         * With live slots the nodes are never serialized: they are moved, and moving preserves
         * listeners, Lit part references and nested custom elements. A molecule that opts in
         * also stops forcing its slotted descendants to be inert — they render normally.
         *
         * Opt-in per molecule so the two mechanisms coexist. Keep the snapshot path where the
         * slot carries DATA to be parsed (`TableHead key=…`, `Item value=…`); use live slots
         * where it carries CONTENT or CONTROLS (`Action`, `Label`, `Icon`, `Trigger`).
         */
        protected usesLiveSlots: boolean;
        /**
         * The consumer's live nodes, per slot tag, held by reference.
         *
         * Holding them is what makes the mechanism survive the anchor coming and going. When a
         * template branch leaves the render (a hidden modal, a collapsed region), Lit removes
         * the anchor and everything under it — including these nodes. Removing a node from the
         * DOM does not destroy it while something still references it, and its listeners stay
         * attached, so the next projection can simply put it back.
         */
        private _liveNodes;
        /** Last anchor that held each key — see `_currentNodes`. */
        private _liveHosts;
        /** Detached holder per key, so eviction does not lose content. */
        private _liveHolders;
        /**
         * Per-element anchors, for molecules that don't pass a slot through but TRANSFORM it.
         *
         * A table is the motivating case: it reads `TableBody > TableRow > TableCell`, sorts and
         * paginates, then re-emits real `<tr>`/`<td>`. The source of a cell's content is a nested
         * element, not a direct child, and there are N×M of them — so an anchor keyed by tag name
         * can't address it. These map an id to the source element instead.
         *
         * The id lives in a WeakMap so the SAME element always gets the SAME id across renders,
         * which is what lets `_liveNodes` survive a row leaving the page and coming back.
         */
        private _liveRefSeq;
        private _liveRefIds;
        private _liveRefs;
        /**
         * Renders the placeholder where a live slot's content lands.
         *
         * The anchor must stay free of Lit bindings: Lit does not manage children it did not
         * create, so nodes appended here survive every re-render. Put bindings around the
         * anchor, never inside it.
         */
        protected renderLiveSlot(tag: string, cls?: string): TemplateResult;
        /**
         * Same as `renderLiveSlot`, but bound to a specific source ELEMENT instead of a tag.
         *
         * Use it when the molecule transforms the slot structure and one tag maps to many
         * destinations — a table cell, a list item. Pass the LIVE element (from `getLiveSlot`),
         * never a snapshot clone: a clone's children are copies, and moving copies projects
         * dead nodes.
         */
        protected renderLiveSlotFrom(source: Element | null | undefined, cls?: string): TemplateResult;
        /**
         * Text currently rendered for a source element, projected or not.
         *
         * A transforming molecule that sorts or filters by cell text cannot read the source
         * element after projection — its children were moved out, so `textContent` is empty.
         * This reads the projected nodes instead, which keeps the value CURRENT: caching the
         * text at capture time would go stale the moment the consumer changed it.
         */
        protected getLiveText(source: Element | null | undefined): string;
        /**
         * The LIVE slot element for `tag` — not the snapshot clone.
         *
         * Structure reads (how many rows, which attributes) should come from here in a molecule
         * that projects, because the snapshot goes stale between mutations and, worse, a
         * re-snapshot after projection reads the emptied sources.
         */
        protected getLiveSlot(tag: string): Element | null;
        /**
         * Moves each live slot's children into its anchor.
         *
         * Runs from `update()` — right after Lit commits the DOM, so the anchors exist. It is
         * deliberately NOT in `updated()`: most molecules override that without calling super,
         * which would silently skip projection.
         */
        private _projectLiveSlots;
        /** Capture-once + reattach-when-empty, shared by both anchor kinds. */
        private _fillAnchor;
        /**
         * Holder per key: a detached element where the nodes wait while they have no anchor.
         * It exists so eviction does not lose content.
         */
        private _holderFor;
        /**
         * The CURRENT nodes for a key, which are not always the captured ones.
         *
         * `_liveNodes` is the list taken at capture time. It goes stale when the consumer REPLACES the
         * slot's content instead of just updating values — `${loading ? spinner : table}`, for example:
         * Lit removes the old nodes and inserts different ones between the same markers, which are
         * still in the anchor. Reattaching the capture list would hand back only the already-discarded
         * nodes, and the region would come back EMPTY when reopened. Measured on 2026-08-04 with
         * demotable--pedidosdetalhe: opening, closing and opening again showed a blank row.
         *
         * Hence the order of preference: the last anchor that held the key (Lit removes the anchor from
         * the DOM, but its children stay INSIDE it), then the holder, and only then the capture.
         */
        private _currentNodes;
        /** The consumer's slot element for `tag`, among this element's own children. */
        private _findSlotChild;
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        _mutationLock: boolean;
        connectedCallback(): void;
        /**
         * Projection hook.
         *
         * `update()` is where Lit commits the template to the DOM, so the anchors exist right
         * after `super.update()`. Chosen over `updated()` on purpose: most molecules override
         * `updated()` without calling super, and projection would silently never run. No
         * molecule overrides `update()`.
         */
        protected update(changed: PropertyValues): void;
        disconnectedCallback(): void;
        private _stopNativeFormEvent;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
        protected getSlotClass(tag: string): string;
    }
}
declare module "_102033_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102033_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/cbe/cbeAuth" {
    export type CollabAuthProvider = 'google';
    /** The logged user from the JS-readable `loginUser` cookie ('' when anonymous). */
    export function getLoginUser(): string;
    export function isLoggedIn(): boolean;
    /** Redirects to collab-auth; it returns to this origin with tokens in the fragment. */
    export function startCollabLogin(provider?: CollabAuthProvider): void;
    /** Clears the VM session cookies (cauth/crefresh/loginUser) and reloads. */
    export function logoutCollab(): Promise<void>;
    /**
     * Shows the sign-in page when this host requires a session and there is none.
     * Called by cbeMiniCfe after the login round-trip (the loginUser cookie is the
     * session signal). No-op on localhost and when already signed in.
     */
    export function showLoginGateIfNeeded(): void;
    global {
        interface Window {
            collabRuntimeAuth?: {
                login: (provider?: CollabAuthProvider) => void;
                logout: () => Promise<void>;
                user: () => string;
            };
        }
    }
}
declare module "_102033_/l2/cbe/global" {
    global {
        export interface Window {
            mls?: {
                api: {
                    cbeLogin: () => Promise<{
                        statusCode: number;
                    } | undefined>;
                };
                actualProject?: number;
                setActualProject?: (project?: number) => void;
                baseMonaco?: string;
                editor: {
                    InitMonaco: () => Promise<void>;
                };
                stor: {
                    orgs: Record<string, unknown>;
                    files: Record<string, unknown>;
                    localDB: {
                        getAllKeys: () => Promise<string[]>;
                    };
                    cache: {
                        installIfNeeded: () => Promise<unknown>;
                    };
                    server: {
                        loadProjectInfoIfNeeded: (project: number, forceUpdate?: boolean) => Promise<boolean>;
                    };
                    loadProjectdependenciesInfoIfNeed: (project: number, forceUpdate?: boolean) => Promise<number[]>;
                };
            };
            latest?: {
                www?: string;
                libs?: string;
                monaco?: string;
                indexHTML?: string;
                l7?: string;
            };
            monacoReady?: Promise<void>;
        }
    }
    export interface StudioMls {
        baseMonaco?: string;
        editor: {
            InitMonaco: () => Promise<void>;
        };
    }
}
declare module "_102033_/l2/cbe/driverVm" {
    /**
     * Repository path of a file: `l<level>/<folder>/<shortName><extension>`.
     * Same construction the GitHub driver uses, so both drivers address a file
     * identically (level 0 has no prefix; the extension may come without the dot).
     */
    export function toShortPath(fileInfo: mls.stor.IFileInfoBase): string;
    export class DriverVm extends mls.stor.others.DriverIOBase {
        /** The slot this driver occupies — see the header note. */
        shortName: mls.cbe.Provider;
        /** Not bound to a single project: it serves every project the VM hosts. */
        project: number;
        driverVersion: string;
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], _comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        /**
         * Content to persist, read the same way the GitHub driver does: force
         * inLocalStorage so getContent serves the LOCAL edit — otherwise a cache miss
         * would call this very driver back — and restore the flag afterwards.
         */
        private readFilePayload;
        getHistory(_fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(_fileInfo: mls.stor.IFileInfo, _ref: string): Promise<string | null>;
        getUrl(_file: mls.stor.IFileInfo): string;
        getVersionFromFiles(): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(): Promise<boolean>;
        reviewPullRequest(): Promise<boolean>;
        listPullRequests(): Promise<mls.stor.others.IPullRequest[]>;
        listForks(): Promise<mls.stor.others.IFork[]>;
        listBranches(): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(): Promise<mls.stor.others.IOrg[]>;
        createRepository(): Promise<boolean>;
        deleteRepository(): Promise<boolean>;
        createFork(): Promise<boolean>;
        renameRepository(): Promise<boolean>;
        createFileInRepo(): Promise<boolean>;
        changeVisibility(): Promise<boolean>;
        verifyRepositoryNew(): Promise<'free' | 'reuse' | 'wait' | 'error'>;
        verifyPermission(): Promise<mls.stor.others.IPermission>;
        addVariable(): Promise<boolean>;
        updateVariable(): Promise<boolean>;
        listVariables(): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(): Promise<boolean>;
        checkFork(): Promise<boolean>;
        checkForkIO(): Promise<boolean>;
        syncFork(): Promise<boolean>;
        createNewBranch(): Promise<boolean>;
        createPullRequest(): Promise<boolean>;
    }
}
declare module "_102033_/l2/cbe/initStudio" {
    import type { StudioMls } from "_102033_/l2/cbe/global";
    /** Loads Monaco and initializes it. Idempotent — safe to call more than once. */
    export function initStudio(mls: StudioMls): Promise<void>;
    /**
     * Cheap: does not load Monaco, only listens. The 102025 previews fire LoadMonaco
     * and then await window.monacoReady — this host is the one that creates it.
     */
    export function listenForLoadMonaco(): void;
    /**
     * Sets mls.l5.actualOrg for `project` — port of collabInit.setOrgActual
     * (mls-100554), which never runs on the VM runtime. Without this, actualOrg
     * stays undefined forever here, and any save through serviceSave.ts throws
     * "No organization selected", even for a project whose org index is
     * perfectly resolvable (project 0 in the org list is a valid index, not "no
     * org" — serviceSave.ts's own check must compare against undefined, not use
     * a falsy check, for this to actually take effect).
     */
    export function setOrgActual(project: number): void;
    /**
     * Registers the VM storage driver in the 'github' slot — the slot the cbe login marker points at
     * (see driverVm.ts for why it is that slot). Without it every source read resolves the GitHub
     * driver and fails with `Driver _<project>_GitHub not found`, since no driver is registered at all
     * on the VM.
     *
     * Lives here, not in the studio header: that header only mounts through the `setHeader(2)` path,
     * while Ctrl+Alt+S never creates it — and both need the driver. Dynamic import on purpose
     * (DriverVm extends a class that only exists once the lib is loaded). Idempotent and never fatal.
     */
    export function registerVmDriver(): Promise<void>;
    /**
     * Registers the TypeScript definition model of a project and of every project it depends on, so
     * Monaco resolves imports across the workspace (`/_102027_/l2/...` and friends) instead of
     * flagging them as missing modules.
     *
     * Port of collabInit.initCompileMonaco (mls-100554), which never runs on the VM. Requires BOTH
     * Monaco initialized and the cbe login done — the index of each project comes from the IndexedDB
     * the login fills (`readPrjInfo().indexModules`, fed by the compiled.zip's types/index.d.ts).
     *
     * Runs once per page. A project that fails is logged and skipped: a missing definition degrades
     * the editing experience, it must never break the studio bootstrap.
     */
    export function loadProjectDefinitions(project: number): Promise<void>;
}
declare module "_102033_/l2/cbe/cbeMiniCfe" {
    export function initCbeMiniCfe(): Promise<void>;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "custom" | "default";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { msgApplyIntents } from "_102036_/l2/shared/api";
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** Browser keeps IndexedDB. CLI calls setOrchestrationStorage before loadAgent/pooling. */
    export type OrchestrationStorage = {
        addOrUpdateTask(task: mls.msg.TaskData): Promise<void>;
        getTask(taskId: string): Promise<mls.msg.TaskData | undefined>;
        getMessage(messageId: string): Promise<mls.msg.Message | undefined>;
        addPooling(pooling: {
            taskId: string;
            userId: string;
            startAt: string;
        }): Promise<void>;
        deletePooling(taskId: string): Promise<void>;
        /**
         * The browser (IndexedDB) returns the updated thread; a host with no thread cache returns
         * nothing. Declared as the type the consumer actually needs — `unknown` compiled here and
         * broke at the two call sites that hand the result to `notifyThreadChange`.
         */
        updateThreadPendingTasks(threadId: string, taskId?: string): Promise<mls.msg.Thread | undefined>;
    };
    export function setOrchestrationStorage(next: OrchestrationStorage | null): void;
    type ApplyIntentsFn = typeof msgApplyIntents;
    /** CLI injects Bearer POST /msg. Browser never calls this. */
    export function setApplyIntents(fn: ApplyIntentsFn | null): void;
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    type OrchestrationListener = (event: OrchestrationEvent) => void;
    /** CLI / tests. Browser never subscribes — executeBeforePrompt still swallows the stream. */
    export function subscribeOrchestrationEvents(listener: OrchestrationListener): () => void;
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_pin: any;
    export const collab_star: any;
    export const collab_paperclip: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_circle_check: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
    export const collab_trash: any;
    export const collab_link: any;
    export const collab_plug: any;
    export const collab_robot: any;
    export const collab_refresh: any;
    export const collab_floppy_disk: any;
    export const collab_crm: any;
    export const collab_tasks: any;
    export const collab_connect: any;
    export const collab_moments: any;
    export const collab_apps: any;
    export const collab_warning: any;
    export const collab_signal: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
}
declare module "_102025_/l2/collabMessagesTaskDetails" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTaskDetails extends StateLitElement {
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderTaskModeJson;
        private renderTaskModeDetails;
        private renderDirectResult;
        private renderDirectClarification;
        private hasPendingClarification;
        private renderlLongMemory;
        private renderTaskInfo;
        private renderTaskInteractions;
        private renderPayload;
        private renderPayloadAgent;
        private renderInteration;
        private renderAgent;
        private renderTool;
        private renderClarificationDetails;
        private renderFlexible;
        private renderClarification;
        private renderResult;
        private setClarification;
        private executeHTMLClarificationScript;
        private syntaxHighlight;
        private onTaskChange;
    }
}
declare module "_102025_/l2/requestMonacoLoad" {
    type Fire = (levels: mls.Level[] | mls.Level, types: mls.events.TypeEvent[] | mls.events.TypeEvent, desc?: string, timeout?: number) => Promise<void>;
    /**
     * Ask the host to load Monaco. Does **not** create `window.monacoReady`.
     *
     * If the requester creates that promise first, the host
     * (`ensureMonacoReady` in 102041 / `loadMonacoScript` in 102033) sees it
     * already exists, never captures its resolver, and `script.onload` resolves
     * nothing — the tab hangs forever. Only the host creates and resolves it.
     *
     * `fire(..., 0)` delivers now (`await fireEvents`), so the listener has
     * already run when this returns. Then we await the host's promise.
     */
    export function requestMonacoLoad(mls: {
        events?: {
            fire?: Fire;
        };
    }, timeoutMs?: number): Promise<void>;
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewAgent extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIAgentStep | null;
        agentDescription: string;
        private prompts;
        private mode;
        private monacoLoadError;
        elEditor: IHTMLEditorElement | undefined;
        private lastKey;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): void;
        update(changedProperties: any): void;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderInputs(): any;
        renderTools(tools: any[], toolChoice: any): any;
        private toolName;
        private renderJsonCard;
        renderPayload(): any;
        renderPrompt(prompt: mls.msg.IAMessageInputType, idx: number): any;
        renderResults(): any;
        private init;
        private getDescription;
        private getPrompts;
        private selectTabInput;
        private selectTabInfo;
        private selectTabResult;
        private selectTabPayload;
        private ensureEditorCreated;
        private mountEditor;
        /**
         * Monaco is no longer guaranteed to be loaded outside the Studio dev environment
         * (Ctrl+Alt+S) — this preview (the Payload tab) is a normal end-user feature, so it asks
         * the host via LoadMonaco instead of importing the shell that hosts it.
         */
        private loadMonacoThenMount;
        private createModel;
        private updateEditorContent;
        private getPayloadTabValue;
        private hasPayloadTabValue;
        private getTracePayload;
        private parseTracePayloadItem;
        private isTracePayloadItem;
        private readonly editorConf;
        private canRestartStep;
        private isParallelChild;
        private restartStep;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewClarification extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIClarificationStep | null;
        private mode;
        private tag;
        clarificationid: HTMLDivElement | undefined;
        private elClarification;
        firstUpdated(): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderClarification(): any;
        renderResults(): any;
        private selectTabClarification;
        private selectTabInfo;
        private getFile;
        private getAgentBeforeStep;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewFlexible extends CollabLitElement {
        private mode;
        private monacoLoadError;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        /**
         * Monaco is no longer guaranteed to be loaded outside the Studio dev environment
         * (Ctrl+Alt+S) — this preview is a normal end-user feature, so it asks the host via
         * LoadMonaco instead of importing the shell that hosts it.
         */
        private loadMonacoThenMount;
        private createModel;
        private updateEditorContent;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewTools extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIToolStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderTools(): any;
        renderResults(): any;
        private selectTabTools;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewResult extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIResultStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderResults(): any;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewRaw" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewRaw extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private resizeObserver;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private observeEditorHost;
        private createModel;
        private updateEditorContent;
        private layoutEditor;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderTaskModeDetails;
        private renderTaskInfo;
        private renderlLongMemory;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreview" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_102025_/l2/collabMessagesTaskPreviewAgent";
    import "_102025_/l2/collabMessagesTaskPreviewClarification";
    import "_102025_/l2/collabMessagesTaskPreviewFlexible";
    import "_102025_/l2/collabMessagesTaskPreviewTools";
    import "_102025_/l2/collabMessagesTaskPreviewResult";
    import "_102025_/l2/collabMessagesTaskPreviewRaw";
    export class CollabMessagesTaskPreview extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        modeTest: boolean;
        father: HTMLElement | undefined;
        initialStep: string;
        private stepMap;
        private navigationStack;
        private currentStepId;
        private allSteps;
        private lastStepId;
        private payloadStepIds;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderStep(): any;
        renderNavigation(stepId: number): any;
        private navigableStepIds;
        private setCurrentStep;
        private goFirst;
        private goPrev;
        private goNext;
        private goLast;
        renderStepDetails(step: any | undefined): any;
        renderBreadcrumb(): any;
        renderRaw(): any;
        renderAgent(step: mls.msg.AIAgentStep): any;
        renderClarification(step: mls.msg.AIClarificationStep): any;
        renderFlexible(step: mls.msg.AIFlexibleResultStep): any;
        renderTools(step: mls.msg.AIToolStep): any;
        renderResult(step: mls.msg.AIResultStep): any;
        renderWorkflow(step: {
            stepId: number;
            type: string;
            workflowName?: string;
            status?: string;
            nextSteps?: any[];
        }): any;
        private init;
        private onTaskChange;
        private buildStepMap;
        private tryNext;
        private navigateToStep;
        private goBack;
    }
}
declare module "_102025_/l2/aiAgentDefaultFeedbackTree" {
    export function isTransparentCompletedStep(step: mls.msg.AIPayload): boolean;
    /** True only when a visible branch and every descendant have completed. */
    export function isBranchCompleted(step: mls.msg.AIPayload): boolean;
    /** Counts visible descendant rows, traversing completed transparent nodes. */
    export function countCollapsedRows(step: mls.msg.AIPayload): number;
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    /** Ephemeral step title on the client. No server, store, or intents. */
    export const STEP_TITLE_LOCAL_EVENT = "step-title-local";
    export const LOCAL_STEP_TITLE_MIN_MS = 500;
    export interface LocalStepTitleDetail {
        taskPK: string;
        stepId: number;
        title: string;
    }
    type LocalStepTitleThrottle = {
        at: number;
        title: string;
    };
    /** Pure tick decision: at most one event per step per ~500ms, drop a repeated same title. */
    export function shouldEmitLocalStepTitle(last: LocalStepTitleThrottle | undefined, now: number, title: string, minIntervalMs?: number): boolean;
    export function getLocalStepTitleEventScope(): Window | undefined;
    /**
     * Paint a step title in the open task UI. Fail-soft: no window (headless/CLI) is a silent no-op;
     * any throw is swallowed — an ornament must never kill a run.
     */
    export function changeLocalStepTitle(taskPK: string, stepId: number, title: string): void;
    /** Main-thread tick while a worker/await holds. No-op (and no timer) without window. */
    export function startLocalStepTitleTick(taskPK: string, stepId: number, makeTitle: (elapsedSec: number) => string, intervalMs?: number): () => void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/aiAgentDefaultFeedbackLocalTitle" {
    export interface LocalStepTitleEntry {
        title: string;
        status?: string;
    }
    export type LocalStepTitles = Map<number, LocalStepTitleEntry>;
    export function applyLocalStepTitle(current: LocalStepTitles, shownTaskPK: string | undefined, event: {
        taskPK?: string;
        stepId?: number;
        title?: string;
    }, stepStatus?: string): LocalStepTitles;
    export function dropLocalTitlesOnTaskChange(current: LocalStepTitles, shownTaskPK: string | undefined, eventTaskPK: string | undefined): LocalStepTitles;
    export function dropLocalTitleIfStatusChanged(current: LocalStepTitles, stepId: number, status: string | undefined): LocalStepTitles;
    export function displayedStepTitle(step: {
        stepId: number;
        stepTitle?: string;
        status?: string;
        type?: string;
        agentName?: string;
        toolName?: string;
    }, local: LocalStepTitles): string;
}
declare module "_102025_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class AiAgentDefaultFeedback102025 extends StateLitElement {
        father: HTMLElement | undefined;
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        private openCapableAgents;
        private openedView;
        private userExpanded;
        private userCollapsed;
        private localTitles;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private onLocalStepTitle;
        private onDurableTaskChange;
        private statusOf;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private resolveOpenCapableAgents;
        private clickOpen;
        private renderOpenedView;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private rowIndex;
        private getChildren;
        private toggleBranch;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private clickDetails;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
    }
}
declare module "_102025_/l2/collabMessagesTaskLogPreview" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/aiAgentDefaultFeedback";
    export class PluginTaskLogPreview102025 extends StateLitElement {
        currentStepId: number;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        father: HTMLElement | undefined;
        template?: TemplateResult;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: any): void;
        render(): any;
        private onTaskChange;
        private createFeedBack;
    }
}
declare module "_102025_/l2/shared/api" {
    export * from "_102036_/l2/shared/api";
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<string>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102025_/l2/collabMessagesSyncNotifications" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const threadSyncMap: Map<string, boolean>;
    type NotificationTarget = {
        threadId: string;
        sourceThreadId: string;
        taskId?: string;
    };
    export function removeThreadFromSync(threadId: string): void;
    export function clearThreadNotification(threadId: string): void;
    export function clearTaskNotification(taskId: string): void;
    export function refreshNotificationIndicator(): Promise<void>;
    export function markThreadReadLocally(threadId: string, lastMessageReadTime?: string, notificationTarget?: NotificationTarget): Promise<msg.ThreadPerformanceCache | undefined>;
    export function hasThreadNotificationPending(threadId: string): boolean;
    export function hasTaskNotificationPending(taskId: string): boolean;
    export function getPendingTaskNotificationsForThread(threadId: string): string[];
    export function checkIfNotificationUnread(): Promise<boolean>;
    export function listenToThreadEvents(): Promise<void>;
    export function getThreadUpdateInBackground(reference: string): Promise<void>;
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        alt: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichTextParser" {
    export type RichToken = {
        type: 'text';
        value: string;
    } | {
        type: 'bold';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'italic';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'strike';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'inline-code';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'heading';
        level: number;
        children: RichToken[];
    } | {
        type: 'horizontal-rule';
    } | {
        type: 'blockquote';
        children: RichToken[];
        lines: RichToken[][];
    } | {
        type: 'list';
        ordered: boolean;
        items: RichListItem[];
    };
    export interface RichListItem {
        marker: string;
        children: RichToken[];
    }
    export function parseRichText(input: string): RichToken[];
    export function parseInlineRichText(input: string, skipCodeBlock?: boolean): RichToken[];
}
declare module "_102025_/l2/collabMessagesPromptEditing" {
    export interface EditResult {
        text: string;
        selectionStart: number;
        selectionEnd: number;
    }
    interface LineInfo {
        start: number;
        end: number;
        text: string;
    }
    interface ListMarker {
        indent: string;
        marker: string;
        spacing: string;
        content: string;
        ordered: boolean;
    }
    export function getLineInfo(text: string, cursor: number): LineInfo;
    export function replaceRange(text: string, start: number, end: number, value: string, cursorOffset?: number): EditResult;
    export function insertText(text: string, selectionStart: number, selectionEnd: number, value: string, cursorOffset?: number): EditResult;
    export function getListMarker(line: string): ListMarker | undefined;
    export function getNextListPrefix(marker: ListMarker): string;
    export function applySmartNewline(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function indentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function outdentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function wrapSelection(text: string, selectionStart: number, selectionEnd: number, before: string, after: string, placeholder?: string): EditResult;
    export function makeCodeBlock(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function makeLinePrefix(text: string, selectionStart: number, selectionEnd: number, prefix: string): EditResult;
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export function serializeUserMentions(text: string, users: msg.User[]): string;
    export function deserializeUserMentions(text: string, users?: msg.User[]): string;
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        overlayElement?: HTMLElement;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: msg.User[];
        allUsersValids: msg.User[];
        hasSelection: boolean;
        selectedFiles: File[];
        sendError: string;
        isSending: boolean;
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        allowAttachments: boolean;
        showSubmitButton: boolean;
        submitOnEnter: boolean;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        enableRichPreview?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        private handleScroll;
        private renderRichToken;
        private renderRichOverlay;
        render(): any;
        private renderToolbar;
        private renderReply;
        private renderSelectedAttachments;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private preventToolbarFocus;
        private updateSelectionState;
        private clearSelectionState;
        private applyEditResult;
        private syncTextAreaEdit;
        private applyInlineFormat;
        private applyCodeBlock;
        private applyLinePrefix;
        private applyLink;
        private openAttachmentPicker;
        private handleAttachmentInput;
        private removeSelectedAttachment;
        private emitTextChange;
        private formatFileSize;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private handlePaste;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102025_/l2/collabMessagesChatMessage" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IChatPreferences, IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    export class CollabMessagesChatMessage102025 extends StateLitElement {
        message?: IMessage;
        messageId?: string;
        allThreads: msg.Thread[];
        actualThread: IThreadInfo | undefined;
        usersAvaliables: msg.User[];
        currentUser: msg.User | undefined;
        userId: string | undefined;
        toolbarHighlighted: boolean;
        openedReactionMessageId?: string;
        reactionPickerTarget?: HTMLElement;
        openedMenuFor?: string;
        messageMenuTarget?: HTMLElement;
        openedReactionListMessageId?: string;
        reactionListTarget?: HTMLElement;
        openedFollowupActionsMessageId?: string;
        followupActionTarget?: HTMLElement;
        followupActionAnchor?: DOMRect;
        userPreferenceChat?: IChatPreferences;
        private messageMenuPlacement;
        private reactionListPlacement;
        private isEditingMessage;
        private editContent;
        private showEditHistory;
        private showFullContent;
        private showFullTaskError;
        onTaskClick?: Function;
        private msg;
        private readonly documentClickHandler;
        private readonly documentScrollHandler;
        private readonly reactionEmojis;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(): void;
        render(): any;
        private renderMessage;
        private renderMessageByLanguage;
        private renderMessageContentByLanguage;
        private renderModerationNotice;
        private renderEditMessageForm;
        private renderEditHistory;
        private renderHistoryToggle;
        private hasMessageHistory;
        private hasReadConfirmationHistory;
        private renderAttachments;
        private renderAttachment;
        private renderDeleteAttachmentButton;
        private openAttachment;
        private refreshAttachmentImage;
        private loadAttachmentUrl;
        private onDeleteAttachmentClick;
        private canDeleteAttachment;
        private canWriteThread;
        private canModerateThread;
        private isMessageContentHidden;
        private canDeleteMessage;
        private canModerateMessage;
        private canEditMessage;
        private parseCompactDate;
        private getUserName;
        private formatFileSize;
        private replyCache;
        private renderReplyPreview;
        private loadReplyPreview;
        private onReplyPreviewClick;
        private renderMessageResultByLanguage;
        private renderReadConfirmations;
        private renderExecutionFollowup;
        private getReadConfirmationStatusByUser;
        private getReadConfirmationKind;
        private getActiveExecutionFollowup;
        private getFollowupStatusItems;
        private hasExecutionFollowup;
        private isFollowupReaction;
        private getFollowupReactionForUser;
        private renderFollowupIcon;
        private getFollowupLabel;
        private renderUserLabel;
        private formatLocalDateTime;
        private renderMessageFooterResult;
        private renderCollabMessagesRichPreview;
        private renderSeeMoreButton;
        private onMentionClick;
        private positionModalByTarget;
        private isCurrentThreadDirectMessage;
        private onChannelHover;
        private removeAllUserModal;
        private removeAllChannelModal;
        private getTitleMessageTranslated;
        private renderReactions;
        private renderReactionListPopup;
        private findUser;
        private getEmojiReactionListItems;
        private getFollowupReactionListItems;
        private getReactionListItems;
        private getReactionSummaryItems;
        private getReadConfirmationSummaryItems;
        private getReadConfirmationReactionListItems;
        private getActiveReadConfirmationStatuses;
        private getReactionIcon;
        private getReactionLabel;
        private openReactionList;
        private updateReactionListPlacement;
        private removeReactionFromList;
        private closeReactionList;
        private renderSideAction;
        private renderFollowupQuickActions;
        private getFollowupActions;
        private renderReactionButtonAdd;
        private renderReactionPicker;
        private onPickerEmojiSelect;
        private onReadConfirmationPickerClick;
        private onFollowupActionClick;
        private openFollowupActionMenu;
        private closeFollowupActionMenu;
        private onDocumentClick;
        private isPopupInteractionTarget;
        private closeLocalPopups;
        private openReactionPicker;
        private closeReactionPicker;
        private toggleReaction;
        private updateReactionOnDb;
        private animateReactionPicker;
        private positionReactionPicker;
        private positionFollowupActionMenu;
        private renderSubMenuButton;
        private openMessageMenu;
        private positionMessageMenu;
        private closeMessageMenu;
        private renderMessageMenu;
        private onReplyClick;
        private onCopyTextClick;
        private onCopyLinkClick;
        private getMessageLink;
        private onMarkUnreadClick;
        private onForwardClick;
        private onEditClick;
        private onEditCancelClick;
        private onEditSaveClick;
        private onViewHistoryClick;
        private onHistoryToggleClick;
        private onPinClick;
        private onFavoriteClick;
        private onReadConfirmationClick;
        private onFollowupActionsMenuClick;
        private onMessageActionClick;
        private isPinned;
        private isFavorite;
        private getMentionedUserIds;
        private hasReadConfirmation;
        private hasPendingReadConfirmation;
        private hasAllReadConfirmationsConfirmed;
        private canCancelReadConfirmation;
        private closeAllPopups;
        private updateMessageMenuPlacement;
        private getMessageOrderAt;
        private normalizeMessageId;
    }
}
declare module "_102025_/l2/collabMessagesTaskRoom" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesPrompt";
    export class CollabMessagesTaskRoom extends StateLitElement {
        task: msg.TaskData | undefined;
        message: msg.Message | undefined;
        userId: string | undefined;
        private roomThread;
        private roomUsers;
        private messages;
        private loading;
        private error;
        private showScrollToBottom;
        private messagesContainer?;
        private ensuredKey;
        private lastRenderedMessageCount;
        private didInitialScroll;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onMessagesScroll;
        private scrollToBottom;
        private scrollMessagesToBottom;
        private ensureRoom;
        private ensureRoomOnServer;
        private openKnownRoom;
        private syncMessages;
        private loadLocalMessages;
        private markRoomReadLocally;
        private sendMessage;
        private cacheRoomThread;
        private getLastOrderAt;
        private getResponseLastOrderAt;
        private onThreadChange;
        private onMessageChange;
        private getUserId;
        private getParentThreadId;
        private getEnsureKey;
        private canUseTaskRoom;
        private toMessageView;
    }
}
declare module "_102025_/l2/collabMessagesTaskInfo" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesTaskDetails";
    import "_102025_/l2/collabMessagesTaskPreview";
    import "_102025_/l2/collabMessagesTaskLogPreview";
    import "_102025_/l2/collabMessagesTaskRoom";
    type TaskInfoTab = 'workflow' | 'step' | 'raw' | 'todo' | 'chat' | 'statistics';
    export type TaskLLMCall = {
        stepId: number;
        title: string;
        provider: string;
        model: string;
        alias: string;
        stage: string;
        inputTokens: number;
        outputTokens: number;
        cost: number;
        llmMs: number;
    };
    export type TaskModelStatistic = {
        key: string;
        provider: string;
        model: string;
        alias: string;
        stage: string;
        calls: number;
        inputTokens: number;
        outputTokens: number;
        cost: number;
        llmMs: number;
        tps: number;
    };
    export type TaskExecutionStatistics = {
        totalSteps: number;
        interactions: number;
        totalCost: number;
        interactionCost: number;
        traceCost: number;
        llmCalls: number;
        inputTokens: number;
        outputTokens: number;
        totalLlmMs: number;
        totalExecutionMs: number;
        errorCount: number;
        failedSteps: number;
        fallbackCount: number;
        traceRecords: number;
        jsonTraceRecords: number;
        byStatus: Record<string, number>;
        byType: Record<string, number>;
        models: TaskModelStatistic[];
        slowestCalls: TaskLLMCall[];
        errorLines: string[];
    };
    export function roundMoneyUpToCents(value: number): number;
    export function buildTaskStatistics(task: mls.msg.TaskData | undefined): TaskExecutionStatistics;
    export class CollabMessagesTaskInfo extends StateLitElement {
        private elParent;
        private contentPluginStyle;
        private forceViewRaw;
        private hasTodo;
        private currentStepId;
        private msg;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        restartPooling: boolean;
        isTest: boolean;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        private activeTab;
        isClarificationPending: boolean;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderTab(isClarificationPending?: boolean): any;
        renderTabContent(activeTab: TaskInfoTab): any;
        renderRaw(): any;
        renderStep(): any;
        renderTodo(): any;
        renderChat(): any;
        renderStatistics(): any;
        renderDirectClarification(): any;
        private hasPendingClarification;
        renderClarification(payload: mls.msg.AIClarificationStep): any;
        private clickForceViewRaw;
        private setClarification;
        private executeHTMLClarificationScript;
        private setTab;
        private renderStatKpi;
        private renderModelsTable;
        private renderStatsBars;
        private renderSlowCalls;
        private formatMoney;
        private formatInteger;
        private formatTps;
        private getNumberLocale;
        private formatDuration;
        private canUseTaskRoom;
        private onTaskChange;
        private normalizeServiceDetailContainer;
        private restoreServiceDetailContainer;
    }
}
declare module "_102033_/l2/cbe/runtimeMessagesEnvironment" {
    import { type CollabProgramMenu } from "_102036_/l2/environmentContract";
    export function buildProgramMenu(): Promise<CollabProgramMenu[]>;
    /**
     * Program navigation for the unified shell:
     * - Pages of the CURRENT app: SPA navigation (pushState + popstate), no reload.
     * - Other apps (monitor, audit, another module): a nav3 content TAB hosting an
     *   iframe — no full-page flicker, each app keeps its own design system in its
     *   own context, and the "several screens as tabs" workflow falls out for free.
     * - Fallback (no nav3 yet): plain navigation.
     */
    export function openProgramUnified(item: {
        url?: string;
        pageName?: string;
    }): Promise<void>;
    /** Applies the generic runtime environment (call only when self-hosting —
     * a project-provided messages aside brings its own environment). */
    export function applyRuntimeMessagesEnvironment(): void;
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102033_/l2/cbe/studioEditSlot" {
    /** What a tool needs to attach itself to the running app. */
    export interface IStudioEditHost {
        /**
         * The region the app renders into — what an editor binds to.
         *
         * NOT the page element and NOT a wrapper: the shell reuses the mounted element by comparing
         * `host.firstElementChild.tagName` with the route tag, so anything inserted in between makes it
         * remount the screen on the next render.
         */
        host: HTMLElement;
        /** The element the tool's own chrome measures itself against (the service element). */
        chromeHost: HTMLElement;
        /** Studio mode is on (Ctrl+Alt+S). Enough for the live-update bridge. */
        studioMode: boolean;
        /** The user is on the level that means "editing the page". What arms the in-place editor. */
        editLevel: boolean;
        /** Which level that is — the app side owns the nav semantics; a tool only shows the number. */
        level: number;
        /**
         * This service's panel is the one showing.
         *
         * A tool's overlay is a fixed layer on the body, so it does NOT disappear when the nav3 hands the
         * panel to another service — the selection box used to stay floating over whatever came next.
         */
        panelVisible: boolean;
    }
    /** A tool: called on every change, and with null when the app region goes away. */
    export type StudioEditTool = (state: IStudioEditHost | null) => void;
    /**
     * A tool announces itself. Returns the unregister.
     *
     * It is called immediately with the current state: a tool loaded lazily (the plugin scan only runs
     * when studio mode turns on) would otherwise wait for the NEXT change to learn it should be armed —
     * and the change that armed it already happened.
     */
    export function registerStudioEditTool(tool: StudioEditTool): () => void;
    /** The app side publishes; it does not know who listens. */
    export function publishEditHost(state: IStudioEditHost | null): void;
    /** The state a tool would get if it registered right now. */
    export function currentEditHost(): IStudioEditHost | null;
    /** Only for tests: forget every tool and the last state. */
    export function resetStudioEditSlot(): void;
}
declare module "_102033_/l2/cbe/studioServices" {
    export const STUDIO_BASE_PROJECT = 100554;
    export const ANONYMOUS_SERVICES: string[];
    export const SERVICE_MESSAGES = "_102033_/l2/cbe/serviceRuntimeMessages";
    export const SERVICE_APP = "_102033_/l2/cbe/serviceClientApp";
    export const RUNTIME_STUDIO_SERVICES: readonly ["_100554_serviceDetail", "_100554_serviceReportBug"];
    /**
     * Adds the runtime service pair and the declared studio widgets to a scanned
     * list, per level. Declared studio widgets sit on the RIGHT of every level
     * (after the app service), matching the previous UI.
     *
     * BOTH toolbars need it — the content structure's nav2s and the studio header's — because they
     * drive the SAME nav3s. A toolbar without these entries strands the user: switching header
     * profile would leave no way back to the app or the messages.
     *
     * Also drops the studio's own serviceCollabMessages (on the VM it points at the
     * msg.collab.codes endpoints and blanks out — ours is the messages service here) and seeds each
     * nav2's last-service memory, so a level restore lands on the pair.
     */
    export function withRuntimeServices(services: string[], nav2Left?: Element | null, nav2Right?: Element | null): string[];
    export interface MlsPluginApi {
        plugin?: {
            loadAll?: (project: number, force?: boolean) => Promise<unknown>;
            getAllMenuActions?: (project: number, options: {
                scope: string;
            }) => Array<{
                widget?: string;
                priority?: number;
            }>;
        };
        actualProject?: number;
        l5?: {
            getProjectDependencies?: (project: number, includeBase: boolean) => number[];
        };
        actual?: Array<{
            setFullName: (widget: string) => {
                path?: string;
                getStorFileBase?: () => {
                    shortName?: string;
                } | undefined;
            };
        }>;
        stor?: {
            server?: {
                loadProjectInfoIfNeeded?: (project: number) => Promise<unknown>;
            };
        };
    }
    /**
     * Menu actions per level/position from the site project and its dependencies.
     * Does not scan 100554 — studio widgets the runtime uses are declared in
     * RUNTIME_STUDIO_SERVICES and injected by withRuntimeServices.
     */
    export function buildStudioServices(siteProject: number, api?: MlsPluginApi | undefined): Promise<string[]>;
    /**
     * Scope a plugin uses to declare a module that plugs into the app's edit slot.
     *
     * Same channel the services use (`getAllMenuActions`), on a scope of its own: a tool is not a panel,
     * it has no icon and no level — it is a module that attaches itself to the running app.
     */
    export const STUDIO_TOOLS_SCOPE = "studioTools";
    /**
     * Loads whatever the site project (or one of its dependencies) declares as an editing tool.
     *
     * This is how the master frontend gets an editor without naming the project that provides one. The
     * widget string IS the module path (`_102020_/l2/aura/studio/studioEditTool` ->
     * `/_102020_/l2/aura/studio/studioEditTool.js`), the same shape the services use, and the module
     * registers itself on the slot when it evaluates (studioEditSlot).
     *
     * Best-effort by design: no plugin, no tool, no error — a client app with no Studio simply has no
     * editing tools, which is exactly the intended behaviour.
     */
    export function loadStudioTools(siteProject?: number, api?: MlsPluginApi | undefined, load?: (url: string) => Promise<unknown>): Promise<string[]>;
    /** Only for tests: forget which tools were already imported. */
    export function resetStudioTools(): void;
}
declare module "_102033_/l2/cbe/serviceClientApp" {
    import { ServiceBase, type IService, type IServiceMenu, type IToolbarContent } from "_102027_/l2/serviceBase";
    export class ServiceClientApp extends ServiceBase {
        details: IService;
        private toolsRequested;
        private panelVisible;
        private studioModeObserver?;
        /** Stable reference: mls.events removes a subscriber by identity. */
        private readonly onToolBarSelected;
        private levelSubscribed;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        /**
         * Follows the shell's `data-studio-mode` so the edit tools appear/disappear with Ctrl+Alt+S.
         *
         * Without this the toolbar would only pick the change up on the next onServiceClick, so entering
         * studio mode would show no edit affordance until the user reclicked the service icon.
         *
         * It also DISARMS on the way out: leaving the editor armed in client mode would swallow every
         * pointer event and make the app unusable.
         */
        private watchStudioMode;
        /**
         * Follows the level through `ToolBarSelected`, the lib's own channel.
         *
         * There is no level event in `mls.events` (`TypeEvent` is a closed union); `ToolBarSelected` is a
         * SERVICE SELECTION event that carries the level, and a level switch ends in one: nav1 writes the
         * level, nav2 flags the change and restores the level's last service
         * ([collab-nav-2.ts:371](mls-102041/l2/collab-nav-2.ts#L371)), which fires it
         * ([collab-nav-2.ts:254](mls-102041/l2/collab-nav-2.ts#L254)). Same channel serviceHistories and
         * serviceCollabFileSystem already use.
         *
         * ALL levels, not just the edit one: the event is fired at the level being entered, so subscribing
         * only to 3 would arm the editor and never disarm it.
         *
         * Two consequences of using a selection event as a level signal, both acceptable because
         * `publishEditState` is idempotent: it also fires when the user picks another service in the level
         * (a free re-sync), and `fire` debounces 200ms by default, so arming lags the switch slightly. What
         * it does NOT cover: a level whose restore finds nothing to select emits no event at all — hence the
         * re-check in adoptAppHost, and `onServiceClick` calling the same sync.
         */
        private watchLevel;
        /** True only in studio mode: the shell publishes it, so no shell change is needed. */
        private isStudioMode;
        /**
         * The region host a tool binds to.
         *
         * NOT the page element and NOT a wrapper around it: `mountRegion` reuses the mounted element by
         * comparing `host.firstElementChild.tagName` with the route tag, so anything inserted in between
         * makes the shell remount the screen on its next render.
         */
        private regionHost;
        /**
         * Publishes where the app is and what the user is doing. The single decision point.
         *
         * Studio mode is required on top of the level: leaving studio mode (Ctrl+Alt+S) does NOT reset the
         * nav3 level, so without that condition a tool would stay armed in a client session — capturing
         * every pointer event and making the app unusable.
         *
         * `editLevel` and `studioMode` are separate because the tools are: the in-place editor wants the
         * level, and the live-update bridge does not (someone editing exclusively through the studio's own
         * file editor never arms the overlay, and the hot swap must still reach the running page).
         */
        private publishEditState;
        private adoptRetriesLeft;
        private adoptAppHost;
        attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
        private applyRegionHeight;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesInputTag" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesAdd" {
    import { CollabMessagesInputTag } from "_102025_/l2/collabMessagesInputTag";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesInputTag";
    export class CollabMessagesAdd extends StateLitElement {
        private msg;
        private threadType;
        private threadName;
        private visibility;
        private group;
        private languages;
        private isLoading;
        private dmUser;
        private users;
        agentsBots: IAgentsBots[];
        _selectedAgent: string;
        _initialMessage: string;
        _topics: string[];
        _agentConfig: string;
        _promptToAvatar: string;
        labelOk: string;
        labelError: string;
        userId: string | undefined;
        languageInput?: CollabMessagesInputTag;
        onAddSuccess: Function | undefined;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private loadUsersAvaliables;
        private loadAgentsBotsAvaliables;
        private _renderAdd;
        private _handleChange;
        private renderBotsConfig;
        private renderInitialMessageConfig;
        private renderIconConfig;
        private validateForm;
        private addNewThread;
        private addBot;
        private generateAvatar;
        private extractSvgFromContext;
    }
    interface IAgentsBots {
        id: string;
        name: string;
        description: string;
        avatar_url: string;
        info?: {
            project: number;
            shortName: string;
            folder: string;
        };
    }
}
declare module "_102025_/l2/collabMessagesTask" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTask extends StateLitElement {
        private msg;
        taskid: string;
        threadId: string;
        userId: string;
        messageid: string;
        lastChanged: string;
        status: string;
        notificationPending: boolean;
        task: msg.TaskData | undefined;
        context: msg.ExecutionContext | undefined;
        private secondsPassed;
        private lastStep;
        private timerId;
        private finalSnapshotSyncedKey;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderIconTask(): any;
        private resetTimer;
        private resetTimerState;
        private formatTime;
        private getTaskLocal;
        private shouldSyncFailedSnapshot;
        private getTaskSnapshotKey;
        private syncTaskFromServer;
        private onCardClick;
        private normalizeMessageId;
        private getAllSteps;
        private getNextPendentStep;
        private getTotalCost;
    }
}
declare module "_102025_/l2/collabMessagesTopics" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTopics extends StateLitElement {
        messages: IMessage[];
        topics: string[];
        expanded: boolean;
        selectedTopic: string | null;
        threadTopics: string[];
        render(): any;
        private emitTopic;
        private extractTopics;
        private groupTopics;
        private getHeadersTopicsFromMessages;
        private getTopicsFromMessagesOrdered;
    }
    interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
    }
}
declare module "_102025_/l2/collabMessagesAddParticipant" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAddParticipant extends StateLitElement {
        private msg;
        userId: string | undefined;
        labelOkAddParticipant: string;
        labelErrorAddParticipant: string;
        userIdOrName: string;
        auth: msg.UserAuth;
        isAddParticipant: boolean;
        actualThread: IThreadActual | undefined;
        highlightedIndex: number;
        suggestions: string[];
        allUsers: string[];
        private users;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onInput;
        private onBlur;
        private selectSuggestion;
        private onKeyDown;
        private onFocus;
        private onSubmitAddParticipant;
        private loadUsersAvaliables;
    }
    interface IThreadActual {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesChangeAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabChangeAvatar extends StateLitElement {
        private msg;
        value?: string;
        nameValue?: string;
        userId: string;
        threadId: string;
        private avatarPrompt;
        private avatarFile?;
        private isOpen;
        private generating;
        private preview?;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private onFileSelect;
        private triggerFileInput;
        private generateAvatarFromPrompt;
        private emitValueChanged;
        private safeSvg;
    }
}
declare module "_102025_/l2/collabMessagesThreadDetails" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesInputTag";
    import "_102025_/l2/collabMessagesAddParticipant";
    import "_102025_/l2/collabMessagesChangeAvatar";
    export class CollabMessagesThreadDetails extends StateLitElement {
        private msg;
        userId: string | undefined;
        threadDetails?: IThreadDetails;
        avatarEl?: HTMLElement;
        labelOk: string;
        labelError: string;
        labelErrorRemoveUser: string;
        labelErrorRemoveBoot: string;
        labelErrorAgent: string;
        labelOkAgent: string;
        private isLoading;
        private editedThreadDetails?;
        private isDirectMessage?;
        private isChannel?;
        private isFileChannel?;
        private isEditingDetails;
        private showAgentForm;
        private integrations;
        private selectedIntegrationId;
        private selectedAgentId;
        private isLoadingAgents;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private loadIntegrations;
        updated(changedProperties: Map<string, any>): Promise<void>;
        private getAddedAgentIds;
        private getAvailableAgents;
        private getVisibilityLabel;
        private getCurrentUserNotification;
        private setCurrentUserNotification;
        private getStatusLabel;
        private getCurrentUserThreadAuth;
        private canManageThread;
        private canModerateThread;
        private isLastAdmin;
        private enterEditMode;
        private cancelEditMode;
        render(): any;
        private renderDetailsViewMode;
        private renderDetailsEditMode;
        private renderUsers;
        private renderAvatar;
        private isUrl;
        private renderAgents;
        private renderAgentFormContent;
        private findAgentInfo;
        private openAgentForm;
        private closeAgentForm;
        private addAgentOpenClawInThread;
        private addIntegrationOpenClawInThread;
        private saveAgentOpenClaw;
        private removeAgentOpenClaw;
        private updateStatusAgent;
        private renderBots;
        private removeUser;
        private removeBot;
        private disableBot;
        private getChangedFields;
        private onAddParticipant;
        private saveChanges;
        private removeUserFromThread;
        private getThreadInfo;
    }
    interface IThreadDetails {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesUserModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesUserModal extends StateLitElement {
        private msg;
        open: boolean;
        user?: msg.User;
        actualUserId?: string;
        isDirectMessage: boolean;
        private isLoading;
        private errorMessage;
        private close;
        private handleGlobalClick;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickUserAction;
    }
}
declare module "_102025_/l2/collabMessagesThreadModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export class CollabMessagesThreadModal extends StateLitElement {
        private msg;
        open: boolean;
        thread?: msg.ThreadPerformanceCache;
        private isLoading;
        private errorMessage;
        private handleGlobalMouseMove;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickThreadAction;
    }
}
declare module "_102025_/l2/collabMessagesFilter" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesFilter extends StateLitElement {
        private expanded;
        private query;
        placeholder: string;
        private toggleExpand;
        private handleKey;
        private handleInput;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTextCode" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTextCode extends StateLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        private _resolveRendered;
        private markRendered;
        whenRendered: Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        private getHighlightLanguage;
        private markRenderedAfterPaint;
        setCode(): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichPreviewText" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesTextCode";
    export class CollabMessagesRichPreviewText102025 extends StateLitElement {
        private msg;
        allHelpers: string[];
        allCommands: string[];
        allThreads: msg.Thread[];
        allUsers: msg.User[];
        text: string;
        showMarkers: boolean;
        private expandedCodeBlocks;
        render(): any;
        private renderTokens;
        private renderMarker;
        private renderToken;
        private renderText;
        private renderBold;
        private renderItalic;
        private renderStrike;
        private renderInlineCode;
        private renderCodeBlock;
        private openBugReport;
        private toggleCodeBlock;
        private renderAgent;
        private renderMention;
        private renderChannel;
        private renderCommand;
        private renderHelp;
        private renderLink;
        private renderRawLink;
        private renderHeading;
        private renderBlockquote;
        private renderList;
        private normalizeLinkHref;
        private copyToClipboard;
    }
}
declare module "_102025_/l2/collabMessagesChat" {
    import "_102025_/l2/collabMessagesTask";
    import "_102025_/l2/collabMessagesTaskInfo";
    import "_102025_/l2/collabMessagesTopics";
    import "_102025_/l2/collabMessagesPrompt";
    import "_102025_/l2/collabMessagesAvatar";
    import "_102025_/l2/collabMessagesThreadDetails";
    import "_102025_/l2/collabMessagesUserModal";
    import "_102025_/l2/collabMessagesThreadModal";
    import "_102025_/l2/collabMessagesFilter";
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesRichPreviewText";
    import * as msg from "_102025_/l2/shared/interfaces";
    import { IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    import { CollabMessagesPrompt } from "_102025_/l2/collabMessagesPrompt";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesChat extends StateLitElement {
        private msg;
        collabMessagesPrompt: CollabMessagesPrompt | undefined;
        private unreadEl;
        private messageContainer;
        private isLoadingThread;
        private filteredThreads;
        private isThreadError;
        private threadErrorMsg;
        private lastTopicFilter;
        private welcomeMessage;
        private usersAvaliables;
        private elementTaskDetails;
        private taskNotificationNavDirection;
        private toolbarView;
        group: 'CONNECT' | 'APPS' | 'DOCS' | 'CRM';
        userId: string | undefined;
        threadToOpen: string | undefined;
        taskToOpen: string | undefined;
        userDeviceId: string | undefined;
        activeScenerie: IScenery;
        actualThread: IThreadInfo | undefined;
        actualTask: msg.TaskData | undefined;
        actualMessage: IMessage | undefined;
        actualMessages: IMessage[];
        actualMessagesParsed: IMessageGrouped;
        isLoadingMessages: boolean;
        searchTerm: string;
        userThreads: IThread;
        allThreads: msg.Thread[];
        lastMessageReaded: string | undefined;
        unreadCountInSelectedThread: number;
        private forwardMessageSource?;
        private forwardDestinationQuery;
        private forwardDestinationThreadId;
        private forwardError;
        private isForwardingMessage;
        private highlightedMessageId;
        private toolbarHelpKind?;
        private toolbarNavigationKind?;
        private toolbarNavigationFailedKind?;
        private toolbarNavigationError;
        private cachedToolbarMessages;
        private isSystemChangeScroll;
        private savedScrollTop;
        private hasMoreMessagesLocalDB;
        private hasMoreMessagesBefore;
        private messagesLimit;
        private isLoadingMoreMessages;
        private isChangeTopics;
        private wasMessagesAtBottom;
        private ignoreToolbarScrollClearUntil;
        private isToolbarAutoScroll;
        private toolbarAutoScrollTimer?;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderHeader;
        private renderContent;
        private renderChatMessages;
        private renderTaskNotificationNav;
        private renderForwardMessage;
        private renderForwardDestination;
        private renderToolbarHelp;
        private getToolbarHelpContent;
        private closeToolbarHelp;
        private renderTaskNotificationNavIcon;
        private renderWelcomeMessage;
        private renderTopics;
        private renderThreadToolbar;
        private renderToolbarCounter;
        private navigateToolbarItem;
        private getToolbarTitle;
        private clearToolbarSelection;
        private getNextToolbarIndex;
        private getAttachmentMessages;
        private getAgentMessages;
        private getMessagesKnownToToolbar;
        private openToolbarHelp;
        private getFavoriteMessageIdsForThread;
        private getReadConfirmationMessageIdsForThread;
        private hasPendingReadConfirmationsForThread;
        private getLoadedMessageById;
        private getReadConfirmationMessageIdsFromLoadedMessages;
        private isReadConfirmationRelevantForCurrentUser;
        private isReadConfirmationPendingForCurrentUser;
        private isReadConfirmationRequestedByCurrentUser;
        private getReadConfirmationKind;
        private getFollowupReactionForUser;
        private getCurrentUser;
        private navigateToMessageId;
        private normalizeToolbarMessageId;
        private getLocalMessageById;
        private renderMessageWindowFromLocalCache;
        private renderMessageWindowFromServer;
        private buildMessageWindowFromTarget;
        private applyToolbarMessageWindow;
        private parseMessageId;
        private getMessageCacheKey;
        private isSameMessageId;
        private scrollToMessageId;
        private deferToolbarAutoScrollEnd;
        private isMessageHighlightedByToolbar;
        private onTopicClick;
        private removeAllModal;
        private renderPrompt;
        private getCurrentThreadUserAuth;
        private canWriteCurrentThread;
        private showReadOnlyThreadError;
        private renderListThreads;
        private getThreadAvatar;
        private getThreadName;
        private isDirectMessage;
        private renderThreadsByStatus2;
        private renderThreadItemLi;
        private renderTaskPendingsCount;
        private formatMessageDate;
        private renderArchivedThreads;
        private renderDeletingThreads;
        private renderDeletedThreads;
        private renderThreadSearch;
        private renderTaskDetails;
        private renderThreadDetails;
        private renderThreadAdd;
        private onSearchInput;
        private getScrollAnchor;
        private restoreScrollAnchor;
        private updateMessagesAfterScrollMore;
        private getBeforeMessagesInServer;
        private getBeforeMessagesInLocalDb;
        private onCopyChat;
        private onChatScroll;
        private getFirstPendingTaskNotificationInView;
        private getTaskNotificationElement;
        private updateTaskNotificationNavDirection;
        private scrollToTaskNotification;
        private groupThreadsByPrefix;
        private getOrdenedThreadsByStatus;
        private getFilteredThreads;
        private getMessagesAfter;
        private getMessagesBefore;
        private parseMessages;
        private groupMessages;
        private parseLocalDate;
        private mergeMessages;
        private onThreadClick;
        private updateThreadPendingsInBackground;
        private markActualThreadRead;
        private clearUnreadMarkerForActualThread;
        private getLastKnownMessageCreateAt;
        private openTask;
        private checkWelcomeMessage;
        private refreshCachedToolbarMessages;
        private checkNotificationsUnreadMessages;
        private alreadyCheckForRegisterToken;
        private checkForRegisterNotification;
        private loadAllMessages;
        private updateMessagesOnDb;
        private clearUnreadMessageFromThread;
        private shouldPreserveUnreadMarker;
        private getFirstUnreadMessageCreateAt;
        private getUnreadMessagesCount;
        private updateLastMessage;
        private onTitleClick;
        private onThreadDetailsClick;
        private onThreadAddClick;
        private handleSend;
        private handlePromptResize;
        private scrollMessagesToBottom;
        private addMessage;
        private addAttachmentMessage;
        private addMessageIA;
        private updateMessageAI;
        private createTempMessage;
        private updateMessage2;
        private onTaskClick;
        private openTaskDetailsPanel;
        private hasStudioTaskDetailHost;
        private createLocalTaskDetails;
        private onReplyPreviewClick;
        private onReplyMessageClick;
        private onPinMessageClick;
        private onFavoriteMessageClick;
        private onReadConfirmationMessageClick;
        private onMessageActionMessageClick;
        private onEditMessageClick;
        private applyMessageUpdateResponse;
        private onMarkUnreadMessageClick;
        private onForwardMessageClick;
        private onForwardDestinationInput;
        private selectForwardDestination;
        private cancelForwardMessage;
        private confirmForwardMessage;
        private getForwardDestinationSuggestions;
        private isForwardDestinationAllowed;
        private getForwardThreadSortTime;
        private isDirectMessageThread;
        private getForwardThreadName;
        private renderForwardDestinationAvatar;
        private createTaskTitleFromMessage;
        private createMessageLink;
        private onDeleteAttachmentMessage;
        private updateCurrentUser;
        private updateUsersInState;
        private replaceUser;
        private getTaskUpdate;
        private clearMissingTaskReference;
        private normalizeTaskMessageId;
        private normalizeMessageId;
        private getThreadInfo;
        private saveScrollPosition;
        private restoreScrollPosition;
        private onTaskChange;
        private openCreatedTaskDetails;
        private onThreadChange;
        private onMessageChange;
        private onMessageSend;
        private onVisibilityChange;
        private onDocumentClick;
        private scrollLock;
        private verifyChatScroll;
        private delay;
        private nextFrame;
        private waitingForRenderCodesWebComponents;
    }
    type IMessageGrouped = {
        [key: string]: IMessage[];
    };
    type IThread = {
        [key: string]: IThreadInfo[];
    };
    type IScenery = 'list' | 'details' | 'loading' | 'task' | 'threadDetails' | 'threadAdd' | 'forwardMessage' | 'toolbarHelp';
}
declare module "_102025_/l2/collabTasksSidebar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    type ScreenId = 'board' | 'mytasks' | 'workflows' | 'simulator' | 'approvals' | 'analytics' | 'settings';
    export class CollabTasksSidebar extends StateLitElement {
        activeScreen: ScreenId;
        private _emit;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksTheme" {
    /**
     * Shared theme utilities for the Tasks tab.
     * Board and My Tasks share the same localStorage key so theme changes
     * are reflected everywhere immediately.
     */
    import { TemplateResult } from 'lit';
    export type TasksTheme = 'clean' | 'amber' | 'forest' | 'trello' | 'clickup';
    export const TASKS_THEME_KEY = "collab-board-theme";
    export const TASKS_BG_KEY_PREFIX = "collab-tasks-bg-";
    export const TASKS_VALID_THEMES: TasksTheme[];
    export const THEME_BG_OPTIONS: Partial<Record<TasksTheme, {
        url: string;
        thumbUrl: string;
        label: string;
    }[]>>;
    export function loadTasksTheme(): TasksTheme;
    export function loadThemeBgUrl(theme: TasksTheme): string | null;
    export function saveThemeBgUrl(theme: TasksTheme, url: string): void;
    export function applyThemeToHost(theme: TasksTheme, host: HTMLElement): void;
    /**
     * Persist the theme, apply it to the given host, and broadcast the change
     * to any other open tasks screen so the picker / board / my-tasks stay in
     * sync without a reload. Listeners can re-apply the theme to their own host
     * with applyThemeToHost(theme, this).
     */
    export function saveTasksTheme(theme: TasksTheme, host: HTMLElement): void;
    export interface ThemeMeta {
        id: TasksTheme;
        labelPt: string;
        labelEn: string;
        descPt: string;
        descEn: string;
        hasImage: boolean;
    }
    export const THEME_LIST: ThemeMeta[];
    export function getThemeMeta(id: TasksTheme, lang: string): {
        label: string;
        desc: string;
    };
    export function themePreview(id: TasksTheme): TemplateResult;
    export function renderThemeCards(currentTheme: TasksTheme, lang: string, onSelect: (t: TasksTheme) => void): TemplateResult;
    export function renderImagePicker(theme: TasksTheme, currentUrl: string | null, lang: string, onSelect: (url: string) => void): TemplateResult;
}
declare module "_102025_/l2/collabTasksCard" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    export class CollabTasksCard extends StateLitElement {
        task: msg.TaskData | undefined;
        tagVocabulary: msg.TagVocabularyEntry[];
        boardStatus: string;
        connectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _applyStatusClass;
        render(): any;
        private _onClick;
        private _onKeyDown;
    }
}
declare module "_102025_/l2/collabTasksEmptyState" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksEmptyState extends StateLitElement {
        title: string;
        subtitle: string;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksDesignTokens" {
    /**
     * Tasks design tokens.
     *
     * This is a TypeScript barrel for the companion `collabTasksDesignTokens.less`
     * file, which exposes a shared set of CSS variables (`--ct-*`) consumed by all
     * tasks components: board, my-tasks, card, settings, theme picker, etc.
     *
     * The tokens are declared at `:root` so they cascade everywhere — making them
     * available to other mls-102025 components that wish to adopt them later
     * without forcing a refactor today.
     *
     * Import this module from any tasks component to ensure the stylesheet is
     * pulled in by the enhancement loader.
     */
    export const CT_STATUS_ACCENT: {
        readonly todo: "#185fa5";
        readonly 'in progress': "#854f0b";
        readonly paused: "#6b7280";
        readonly done: "#3b6d11";
        readonly failed: "#a32d2d";
    };
    export const CT_TAG_ACCENT: {
        readonly bug: "#a32d2d";
        readonly feature: "#185fa5";
        readonly business: "#854f0b";
        readonly process: "#085041";
        readonly neutral: "#5f5e5a";
    };
    export type CtStatusKey = keyof typeof CT_STATUS_ACCENT;
    export type CtTagKey = keyof typeof CT_TAG_ACCENT;
}
declare module "_102025_/l2/collabTasksThemePicker" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksThemePicker extends StateLitElement {
        /** Visual density. 'compact' for inline popovers, 'panel' for standalone screens. */
        variant: 'compact' | 'panel';
        /** Hide the section title when the host already provides one. */
        hideTitle: boolean;
        private _theme;
        private _bgUrl;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _onSelectTheme;
        private _onSelectBg;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksBoard" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksCard";
    import "_102025_/l2/collabTasksEmptyState";
    import "_102025_/l2/collabTasksThemePicker";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksBoard extends StateLitElement {
        reloadKey: number;
        userId: string;
        organizationId: string;
        initialPmaFilter: string;
        private activeTasks;
        private closedTasks;
        private tagVocabulary;
        private loadingActive;
        private loadingClosed;
        private error;
        private _theme;
        private _showSettings;
        private _filterTags;
        private _filterPmaIds;
        private _initialFetchDone;
        private _refetchTimer;
        private _onTaskChange;
        private _onThreadChange;
        private _onTaskMetaChanged;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        private _applyThemeClass;
        private _getFilterOptions;
        private _applyFilters;
        private _toggleTag;
        private _togglePmaId;
        private _clearFilters;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _fetchAll;
        private _fetchClosed;
        private _filterWorkflow;
        private _scheduleRefetch;
        private _handleTaskChange;
        private _handleThreadChange;
        private _handleTaskMetaChanged;
        private _bucket;
        render(): any;
        private _renderFilterBar;
        private _renderSettings;
        private _renderColumn;
        private _renderCard;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksMyTasks" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksThemePicker";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksMyTasks extends StateLitElement {
        userId: string;
        private activeTasks;
        private closedTasks;
        private loadingActive;
        private loadingClosed;
        private error;
        private showClosed;
        private _theme;
        private _showSettings;
        private _refetchTimer;
        private _onTaskChange;
        private _onTaskMetaChanged;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _applyThemeClass;
        private _fetchAll;
        private _fetchClosed;
        private _scheduleRefetch;
        private _handleTaskChange;
        private _handleTaskMetaChanged;
        private _openTask;
        render(): any;
        private _renderHeader;
        private _renderSettings;
        private _renderBody;
        private _renderTaskRow;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksWorkflows" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksWorkflows extends StateLitElement {
        userId: string;
        private groups;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        render(): any;
        private _openInBoard;
        private _renderGroup;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksApprovals" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksApprovals extends StateLitElement {
        userId: string;
        private pending;
        private paused;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        private _openTask;
        render(): any;
        private _renderRow;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksAnalytics" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksAnalytics extends StateLitElement {
        userId: string;
        private analytics;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        render(): any;
        private _renderDashboard;
        private _tile;
        private _renderLoadingTiles;
    }
}
declare module "_102025_/l2/collabTasksSettings" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksSettings extends StateLitElement {
        userId: string;
        organizationId: string;
        private tagVocabulary;
        private loadingTags;
        private errorTags;
        private _onThemeChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _loadTags;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTasks" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksSidebar";
    export class CollabMessagesTasks extends StateLitElement {
        private screen;
        private _onBoardFilter;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _openBoardWithFilter;
        render(): any;
        private _onScreenChange;
        private _openScreen;
    }
}
declare module "_102025_/l2/collabMessagesAppsMenu" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export interface IMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: IMenuItem[];
    }
    export interface IMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: IMenuItem[];
    }
    type IFilter = 'all' | 'favorites' | 'history';
    export class CollabMessagesAppsMenu extends StateLitElement {
        private msg;
        keyFavoritesLocalStorage: string;
        keyHistoryLocalStorage: string;
        identifier: string;
        menuTitle: string;
        menuModules: IMenu[];
        favorites: string[];
        history: string[];
        searchTerm: string;
        activeFilter: IFilter;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private getScope;
        private readStore;
        private loadFavorites;
        private loadHistory;
        private loadFilter;
        private setFilter;
        private getItemPath;
        private toggleFavorite;
        private isFavorite;
        private recordHistory;
        private handleMenuClick;
        private onSearch;
        private matchesSearch;
        private filterItems;
        private renderMenuItem;
        render(): any;
        private renderToolbar;
        private renderContent;
        private renderKeyList;
        private renderModules;
        private findItemByPath;
    }
}
declare module "_102025_/l2/collabMessagesApps" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { type CollabProgramMenu } from "_102036_/l2/environmentContract";
    import "_102025_/l2/collabMessagesAppsMenu";
    export class CollabMessagesApps extends CollabLitElement {
        menuModules: CollabProgramMenu[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private handleMenuClick;
    }
}
declare module "_102025_/l2/collabMessagesMoments" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesMoments102025 extends StateLitElement {
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesSettingsOpenClaw" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'main' | 'connectorDetails' | 'editAgent';
    interface IOpenClawConnectorLocal extends msg.OpenClawConnector {
        isNew?: boolean;
        gatewayTokenChanged?: boolean;
        inboundTokenChanged?: boolean;
    }
    export class CollabMessagesSettingsOpenClaw extends StateLitElement {
        private msg;
        userId: string;
        actualIntegration: msg.IOpenClawIntegration | undefined;
        integrations: msg.IOpenClawIntegration[];
        connectors: IOpenClawConnectorLocal[];
        viewMode: ViewMode;
        currentConnectorId: string;
        editingConnector: IOpenClawConnectorLocal | null;
        isTestingConnection: boolean;
        connectionTestResult: 'none' | 'success' | 'error' | 'warning';
        connectionTestMessage: string;
        connectionTestLatency: number;
        showGatewayToken: boolean;
        showInboundToken: boolean;
        copiedToken: 'gateway' | 'inbound' | null;
        showDeleteConfirmation: boolean;
        deleteConfirmationInput: string;
        newAgentName: string;
        newAgentAvatarUrl: string;
        editingAgent: msg.IOpenClawAgent | null;
        isNewAgent: boolean;
        newAgentWorkspace: string;
        newAgentEmoji: string;
        newAgentSoulMd: string;
        newAgentIdentityMd: string;
        showDeleteAgentConfirmation: boolean;
        agentToDelete: msg.IOpenClawAgent | null;
        deleteAgentFiles: boolean;
        isDeletingAgent: boolean;
        labelOkConnector: string;
        labelErrorConnector: string;
        labelOkAgent: string;
        labelErrorAgent: string;
        isSavingConnector: boolean;
        isSavingAgent: boolean;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderOpenClawConnectors;
        private renderConnectorCard;
        private renderToggleIcon;
        private renderConnectorDetailsView;
        private renderConfigurationSection;
        private renderTestConnectionSection;
        private renderAgentSection;
        private renderDeleteSection;
        private renderDeleteConfirmation;
        private renderAgentCard;
        private renderDeleteAgentModal;
        private renderAvatar;
        private isUrl;
        private renderEditAgentView;
        private navigateTo;
        private handleAddConnector;
        private clearErrors;
        private clearStates;
        private getIntegration;
        private handleOpenConnectorDetails;
        private handleBackToMain;
        private handleCancelConnector;
        private handleConnectorNameChange;
        private handleConnectorUrlChange;
        private handleGatewayTokenChange;
        private handleInboundTokenChange;
        private handleChangeToken;
        private handleTimeoutChange;
        private handleOutputModeChange;
        private handleConnectorEnabledToggle;
        private handleGenerateToken;
        private handleSaveConnector;
        private saveIntegration;
        private removeIntegration;
        private saveOrUpdateOpenClawConnector;
        private handleTestConnection;
        private checkDomainExists;
        private handleToggleDeleteConfirmation;
        private handleDeleteConfirmationInput;
        private handleCancelDelete;
        private handleConfirmDelete;
        private handleOpenAddAgent;
        private handleOpenEditAgent;
        private handleBackToConnectorDetails;
        private handleNewAgentNameInput;
        private handleNewAgentAvatarInput;
        private handleNewAgentWorkspaceInput;
        private handleNewAgentEmojiInput;
        private handleNewAgentSoulMdInput;
        private handleNewAgentIdentityMdInput;
        private handleGenerateAgentAvatar;
        private handleSaveAgent;
        private handleOpenDeleteAgentConfirmation;
        private handleCloseDeleteAgentConfirmation;
        private handleDeleteAgentFilesChange;
        private handleConfirmDeleteAgent;
        private handleDisableAgent;
        private handleToggleTokenVisibility;
        private handleCopyToken;
    }
}
declare module "_102025_/l2/collabMessagesSettingsChatPreferences" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsChatPreferences extends StateLitElement {
        private msg;
        private chatPreferences;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private handleTranslationModeChange;
        private handleLanguageInput;
        private handleSave;
    }
}
declare module "_102025_/l2/collabMessagesSettingsUser" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsUser extends StateLitElement {
        private msg;
        private userPerfil;
        private viewMode;
        private isSaving;
        private labelOk;
        private labelError;
        private tempAvatarUrl;
        private avatarUrlValid;
        private avatarLoading;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderUserSection;
        private renderEditAvatarView;
        private getUserPerfil;
        private handleNameInput;
        private handleSave;
        private handleOpenEditAvatar;
        private handleCancelEditAvatar;
        private handleAvatarUrlInput;
        private handleAvatarError;
        private handleSaveAvatar;
    }
}
declare module "_102025_/l2/collabMessagesSettingsNotificationPreferences" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsNotificationPreferences extends StateLitElement {
        private msg;
        private notificationPreferences;
        private audioEnabled;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderEnabled;
        private renderDisabled;
        private renderReadMore;
        private getNotificationStatus;
        private handleAudioToggle;
        private handleEnableNotifications;
    }
}
declare module "_102025_/l2/collabMessagesSettingsGeral" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesSettingsOpenClaw";
    import "_102025_/l2/collabMessagesSettingsChatPreferences";
    import "_102025_/l2/collabMessagesSettingsUser";
    import "_102025_/l2/collabMessagesSettingsNotificationPreferences";
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'all' | 'user' | 'chat' | 'notification' | 'openclaw';
    export class CollabMessagesSettingsGeral102025 extends StateLitElement {
        private msg;
        viewMode: ViewMode;
        userPerfil: msg.User | undefined;
        private scrollPositions;
        private show;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderUser;
        private renderChatPreferences;
        private renderPreferencesNotifications;
        private renderOpenClawConnectors;
        private onSettingsChange;
        private getUserPerfil;
        private saveScrollPosition;
        private restoreScrollPosition;
        private navigateTo;
    }
}
declare module "_102025_/l2/collabMessagesTabMenu" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export interface TabMenuItem {
        id: string;
        icon: TemplateResult;
        label: string;
        activeColor?: string;
        type: 'tab' | 'button';
    }
    export class CollabMessagesTabMenu extends StateLitElement {
        items: TabMenuItem[];
        activeId: string;
        private get _tabs();
        private get _buttons();
        private _handleItemClick;
        private _renderItem;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessages" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChat";
    import "_102025_/l2/collabMessagesTasks";
    import "_102025_/l2/collabMessagesApps";
    import "_102025_/l2/collabMessagesMoments";
    import "_102025_/l2/collabMessagesSettingsGeral";
    import "_102025_/l2/collabMessagesTabMenu";
    export class CollabMessages extends CollabLitElement {
        private msg;
        dataLocal: IDataLocal;
        activeTab: ITabType;
        activeScenerie: IScenery;
        isLoadingThread: boolean;
        userPerfil: msg.User | undefined;
        userThreads: IThreadData;
        showNotificationAlert: boolean;
        threadToOpen: string;
        taskToOpen: string;
        lastLevel: number;
        modeMenu: string;
        private groupSelected;
        private menuItems;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private checkNotificationPermission;
        private startPendentsPoolingsIfNeeded;
        private onThreadChange;
        private onThreadOpen;
        private setEvents;
        private removeEvents;
        renderHeader(): any;
        renderTabs(): any;
        renderAlert(): any;
        private onAlertClose;
        renderCRM(): any;
        renderTasks(): any;
        renderMoments(): any;
        renderApps(): any;
        renderSettings(): any;
        renderConnect(): any;
        private getUser;
        private updateThreads;
        private searchForDeletedThreadsPending;
        private updateUsersThread;
        private getThreadFromLocalDB;
        private getThreadInfo;
        private onThreadCreate;
        private checkNotificationPending;
        private onTabChange;
        private onButtonClick;
    }
    interface IDataLocal {
        lastTab: ITabType;
    }
    type IThreadData = {
        [key: string]: IThreadInfo;
    };
    interface IThreadInfo {
        thread: msg.Thread;
        users: msg.User[];
    }
    type ITabType = 'CRM' | 'TASK' | 'MOMENTS' | 'CONNECT' | 'APPS' | 'SETTINGS' | 'Add' | 'Loading';
    type IScenery = 'tabs' | 'settings' | 'findTask';
}
declare module "_102033_/l2/cbe/serviceRuntimeMessages" {
    import { ServiceBase, type IService, type IServiceMenu, type IToolbarContent } from "_102027_/l2/serviceBase";
    export class ServiceRuntimeMessages extends ServiceBase {
        details: IService;
        private readonly tabNames;
        private static readonly TAB_STORAGE_KEY;
        private loadStorageRecord;
        private saveLastTab;
        private initialTabIndex;
        menu: IServiceMenu;
        private setMessagesTab;
        onServiceClick(_visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        createRenderRoot(): this;
        connectedCallback(): void;
        private adoptMessagesElement;
        private ensuring;
        private ensureMessages;
        attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
        private applyInnerHeight;
        render(): any;
    }
}
declare module "_102033_/l2/shared/languageRuntime" {
    type RuntimeLanguageDocument = {
        documentElement: {
            lang: string;
        };
        querySelectorAll: (selector: string) => ArrayLike<unknown> | Iterable<unknown>;
    };
    export function listRuntimeLanguages(languages: readonly string[] | undefined): string[];
    export function resolveRuntimeLanguage(languages: readonly string[], requestedLanguage: string): string | undefined;
    export function getRuntimeLanguage(languages: readonly string[], documentLanguage: string): string | undefined;
    export function getNextRuntimeLanguage(languages: readonly string[], documentLanguage: string): string | undefined;
    export function setRuntimeLanguage(requestedLanguage: string, languages: readonly string[], runtimeDocument?: RuntimeLanguageDocument): void;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        /**
         * The environment mode the SERVER resolved for this project (`production | homologation | development |
         * presentation`). The client only displays it; it never decides it. Absent on a runtime older than the
         * modes.
         */
        appEnv?: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        languages?: string[];
        designSystem?: string;
        designSystems?: string[];
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
            /** Unified nav3 (runtime): content-region tabs hosting arbitrary elements. */
            collabRuntimeNav3?: {
                openTab: (tab: {
                    id: string;
                    title: string;
                    element: unknown;
                    closable?: boolean;
                }) => void;
                closeTab: (id: string) => void;
                activateTab: (id: string) => void;
                listTabs: () => string[];
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102033_/l2/cbe/studioHeader" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    import { STUDIO_BASE_PROJECT, ANONYMOUS_SERVICES, SERVICE_MESSAGES, SERVICE_APP, RUNTIME_STUDIO_SERVICES, withRuntimeServices, buildStudioServices } from "_102033_/l2/cbe/studioServices";
    export { STUDIO_BASE_PROJECT, ANONYMOUS_SERVICES, SERVICE_MESSAGES, SERVICE_APP, RUNTIME_STUDIO_SERVICES, withRuntimeServices, buildStudioServices, };
    export const STUDIO_PROJECT = 102041;
    export function ensureStudioPageAssets(): void;
    export class CbeStudioHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            navsReady: {
                state: boolean;
            };
            navsError: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        navsReady: boolean;
        navsError: string;
        constructor();
        createRenderRoot(): this;
        connectedCallback(): void;
        private loadNavModules;
        private applyStudioServices;
        render(): any;
    }
}
declare module "_102033_/l2/cbe/studioTailwind" {
    /**
     * Pinned so the studio renders what the BUILD will generate.
     *
     * The preview's CDN entry is a floating major (`@tailwindcss/browser@4`, in
     * mls-102020/l2/enhancementAura.ts:118); here that drift would silently defeat the whole point of the
     * JIT. `studioTailwind.test.ts` fails when this stops matching the `tailwindcss` / `@tailwindcss/cli`
     * versions the build actually resolves.
     */
    export const TAILWIND_JIT_VERSION = "4.3.0";
    export const TAILWIND_JIT_URL = "https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4.3.0";
    /**
     * The `@theme` block of mls-102033/l2/shared/tailwind.css, verbatim.
     *
     * A literal copy because the SERVED file is the compiled one (the build overwrites it), where `@theme`
     * is already lowered to `:root { --color-... }` and cannot be handed back to the JIT. The test asserts
     * this copy still matches the source file, so drift is caught by the suite and not on screen.
     */
    export const STUDIO_TAILWIND_THEME = "@theme {\n  --color-aura-ink: #102a43;\n  --color-aura-navy: #17324d;\n  --color-aura-blue: #22496e;\n  --color-aura-sand: #fffdfa;\n  --color-aura-mist: #f7f4ea;\n}";
    /**
     * The stylesheet handed to the JIT (`<style type="text/tailwindcss">`).
     *
     * - `@import "tailwindcss"`: the browser build prepends it only when no `@import` appears at all;
     *   being explicit keeps our block self-contained whatever else gets injected later.
     * - `@custom-variant dark`: without it `dark:` follows `prefers-color-scheme` instead of the `.dark`
     *   class the app puts on `<html>` (mls-102033/l2/shared/bootstrap.ts:69) — and `dark:` utilities are
     *   the single largest slice of 102020's dead classes. Same injection the Aura preview does
     *   (mls-102020/l2/aura/services/preview/previewModeAura.ts:451).
     * - `@theme`: the JIT cannot generate theme-dependent utilities (`text-aura-ink`, ...) without it.
     */
    export const STUDIO_TAILWIND_CSS = "@import \"tailwindcss\";\n@custom-variant dark (&:where(.dark, .dark *));\n@theme {\n  --color-aura-ink: #102a43;\n  --color-aura-navy: #17324d;\n  --color-aura-blue: #22496e;\n  --color-aura-sand: #fffdfa;\n  --color-aura-mist: #f7f4ea;\n}\n";
    /**
     * `media` value that makes the JIT sheet inert.
     *
     * Leaving studio mode has to give the CLIENT'S css back: with both sheets live, a page edited in the
     * studio keeps looking right in client mode, which is precisely the masking this module is supposed to
     * expose. The script itself cannot be unloaded (the browser build is an IIFE with no exit door and its
     * own DOM observer), so the sheet is neutralised instead — and re-enabled instantly on the way back in,
     * with no second download.
     *
     * `media` on the ELEMENT rather than `sheet.disabled`: the JIT rewrites the style's `textContent` on
     * every rebuild, which re-parses the sheet and would drop `disabled`; the attribute survives.
     */
    export const JIT_SUSPENDED_MEDIA = "not all";
    /** Only what applyJitSuspension touches, so it can be exercised without a DOM. */
    export interface JitStyleTarget {
        setAttribute(name: string, value: string): void;
        removeAttribute(name: string): void;
    }
    export function applyJitSuspension(style: JitStyleTarget, isSuspended: boolean): void;
    /**
     * Follows the studio mode both ways: `true` loads the JIT (once) and makes its sheet live, `false`
     * makes it inert so the app renders with exactly the css the client is served.
     */
    export function setStudioTailwind(active: boolean): void;
    /**
     * Loads the Tailwind browser JIT into the app document. Idempotent: repeated studio-mode toggles reuse
     * the injected script, so the CDN bundle is downloaded once per session.
     */
    export function ensureStudioTailwind(): void;
    /**
     * Class names a list of selectors targets.
     *
     * Tailwind escapes utilities heavily (`.dark\:text-gray-300`, `.w-\[10px\]`, `.p-1\.5`), so escapes
     * are undone before comparing. Pure on purpose — the DOM side only feeds it selectorTexts.
     */
    export function classNamesFromSelectors(selectors: Iterable<string>): Set<string>;
    /**
     * Classes the studio renders correctly ONLY because the JIT is here — in use, known to Tailwind, and
     * absent from the built sheet the client app is served.
     *
     * Without this signal the JIT would MASK the build's `@source` scope problem: the premise of the
     * parent task is "the app IS the faithful preview", which stops holding the moment studio-only CSS
     * makes a page look finished.
     */
    export function missingFromBuiltCss(used: Iterable<string>, jitClasses: Set<string>, builtClasses: Set<string>): string[];
    /**
     * Classes that have a rule in the BUILT sheet — i.e. what the client app will actually render.
     *
     * The class picker (studioClassEdit) asks this before offering a utility: with the JIT on, a class
     * absent from here still works on screen but would come out unstyled for the client until the next
     * publish, and the picker has to say so instead of quietly promising it.
     */
    export function builtCssClassNames(): Set<string>;
    /** True when the JIT is loaded AND its sheet is live (not suspended by leaving studio mode). */
    export function isStudioTailwindLive(): boolean;
    /**
     * One-shot report, run once the JIT has produced its first sheet. Cheap (three set walks) and silent
     * when there is nothing to report.
     */
    export function auditBuiltTailwindCoverage(): string[];
}
declare module "_102033_/l2/cbe/studioStructure" {
    import "_102033_/l2/cbe/serviceClientApp";
    import "_102033_/l2/cbe/serviceRuntimeMessages";
    export const NAV1_HEIGHT_PX = 30;
    export const NAV2_HEIGHT_PX = 36;
    /**
     * Puts the runtime pair back on the nav3s — messages left, app right.
     *
     * What CLIENT mode shows. Leaving studio mode has to force these back: the toolbars remember the
     * last service opened, which by then is whatever the user was doing in the studio.
     */
    export function showRuntimeServices(host: ParentNode): void;
    /**
     * Builds the studio structure and appends it to `container`. Returns the
     * collab-page element, or throws when the studio environment is unavailable.
     * The caller decides when to reveal it / hide the classic layout.
     */
    export function upgradeToStudioStructure(container: HTMLElement, siteProject: number): Promise<HTMLElement>;
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    /** The event the shell listens for to send the user back to the collab-auth login. */
    export const BFF_UNAUTHENTICATED_EVENT = "collab-bff-unauthenticated";
    /** Explicit override (email). Empty string clears it and the session cookie takes over again. */
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102033_/l2/core/bff-client" {
    export * from "_102029_/l2/bffClient";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102033_/l2/shellEvents";
}
declare module "_102033_/l2/shared/navigationVisibility" {
    /**
     * The items this user may see: `item.actors` ∩ the user's authorities of THIS module.
     *
     * Pure and conservative. With no authorities known — which is every session until the token issuer starts
     * emitting them — NOTHING is filtered: a menu that empties itself the moment a lookup fails would be a
     * worse failure than an unfiltered one. An item that declares no `actors` is for everybody either way.
     */
    export function visibleNavigation<T>(navigation: readonly T[], authorities: readonly string[], moduleId: string): T[];
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
            authorities: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        /** The user's authorities, asked of the server once (the token is httpOnly; JS cannot read claims). */
        authorities: string[];
        createRenderRoot(): this;
        connectedCallback(): void;
        /**
         * The claims live in an httpOnly cookie, so the client cannot read them — it ASKS. Best-effort: a
         * failure leaves the list empty, which means "filter nothing" and the menu behaves as it always did.
         */
        private loadAuthorities;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/auraNavigate" {
    /** True when `href` is a route of the module currently booted (SPA navigation applies). */
    export function isInternalModuleHref(href: string, basePath: string): boolean;
    /**
     * Active state of a region's navigation entry. The module root answers to its aliases
     * (`/index.html`, `/overview`) — the rule the aside has always applied, now shared with the header.
     */
    export function isRegionLinkActive(href: string, currentPath: string, basePath?: string): boolean;
    export interface AuraNavigateOptions {
        /** Module base path from the boot config; routes outside it are a full page load. */
        basePath?: string;
        /** Ran right after an in-module navigation starts (the aside closes its drawer here). */
        afterNavigate?: () => void;
        busyLabel?: string;
        errorTitle?: string;
    }
    /**
     * Navigates to `href`: SPA push inside the current module (guarded by the blocking UI), full page
     * load anywhere else. Returns false when the href is not navigable (empty, or not absolute).
     */
    export function auraNavigate(href: string, options?: AuraNavigateOptions): boolean;
    /** Click handler for an in-app anchor: same protocol, taking the href from the event target. */
    export function auraNavigateFromEvent(event: Event, options?: AuraNavigateOptions): void;
}
declare module "_102033_/l2/shared/layout/auraHeaderCore" {
    import type { AppHeaderAction, AppHeaderBrand } from "_102029_/l2/runtimeConfigTypes";
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    /**
     * Fixed header band, in px.
     *
     * Every header profile in `clientShell.regions.header.profiles` MUST declare this as its
     * `heightPx`: the shell turns the active profile's `heightPx` into `--aura-header-height`, so
     * profiles with different values shift the whole page when switched (Ctrl+Alt+S / mls.sites.setHeader).
     */
    export const AURA_HEADER_HEIGHT_PX = 66;
    /**
     * Height of the brand mark inside the band. The mark is sized by HEIGHT with `width: auto`, so a
     * wide wordmark and a square glyph both keep their proportions — exported so a preview elsewhere
     * can show it at the size it will really have.
     */
    export const AURA_HEADER_LOGO_PX = 28;
    /** Mobile breakpoint of the header band (the shell keeps its own for the region layout). */
    export const AURA_MOBILE_BREAKPOINT_PX = 768;
    export type AuraHeaderBrand = AppHeaderBrand;
    export type AuraHeaderAction = AppHeaderAction;
    /** Hard cap for an inlined mark. Generous on purpose: a real mark may carry defs and many paths. */
    export const MAX_LOGO_SVG_BYTES = 12000;
    /**
     * Whether an SVG markup is safe AND suitable to be inlined in the header band.
     *
     * The markup is inlined, so it is executable surface: anything that can script, fetch or embed is
     * refused. It must also be a single `<svg>` root with a `viewBox` and no intrinsic size, or it cannot
     * scale into the band. Everything else — how many shapes, which colors, how it looks — is the
     * designer's call, not this function's.
     *
     * `monochrome: true` additionally requires currentColor-only paint (what makes a mark follow the
     * design system in both themes); it is OPT-IN, because a real brand mark may well be colored.
     *
     * Shared by the runtime and by the generator's validation, so both judge by the same rule.
     */
    export function isSafeLogoSvg(markup: string, options?: {
        monochrome?: boolean;
    }): boolean;
    /**
     * Only `.svg` logos are supported: it is the asset kind that survives into dist (raster brand
     * assets are not published), so anything else would 404 in production.
     */
    export function isSupportedLogoUrl(url: string): boolean;
    /**
     * Brand shown by a header profile. The identity comes from the CONFIG (`profiles[x].brand`, which
     * the shell hands over as `regionProps.brand`) — never hardcoded in a generated subclass, so
     * regenerating the header cannot lose it.
     */
    export function resolveHeaderBrand(bootConfig?: MasterFrontendBootConfig, regionProps?: Record<string, unknown>, fallbackTitle?: string): AuraHeaderBrand;
    /** Optional actions the profile turned on (`profiles[x].props.actions`); unknown names are dropped. */
    export function resolveHeaderActions(regionProps?: Record<string, unknown>): AuraHeaderAction[];
    /**
     * Locales this header offers, from `props.locales`, intersected with what the app actually runs.
     *
     * The profile is a FILTER, never a source: a locale the app does not ship has no messages, so it
     * would switch the page into a language nothing is translated to. Absent/empty = every runtime
     * language, which is the behaviour every header had before the field existed.
     */
    export function resolveHeaderLocales(regionProps: Record<string, unknown> | undefined, runtimeLanguages: readonly string[]): string[];
    /**
     * The entries a header links: the selected hrefs, resolved against everything the runtime offers.
     *
     * Both lists are searched — the current module's `navigation` AND the cross-module `moduleLinks` —
     * because a selection is made in the studio over the whole project, and filtering only the current
     * module would make a legitimate cross-module link silently disappear.
     *
     * Order comes from the runtime lists, not from the selection: the header must not reorder the
     * project's own navigation. No selection = every entry of `navigation` (what headers did before the
     * field existed).
     */
    export function selectNavEntries<T extends {
        href: string;
    }>(navigation: readonly T[], moduleLinks: readonly T[], wanted: readonly string[]): T[];
    /**
     * Routes this header links, from `props.navLinks`: the hrefs picked for the band.
     *
     * Absent/empty means "no selection recorded", NOT "no links": the caller keeps every route the
     * module declares, which is what headers generated before this field did.
     */
    export function resolveHeaderNavHrefs(regionProps?: Record<string, unknown>): string[];
    /**
     * Band height for this profile. Defaults to the shared constant: the shell writes the ACTIVE
     * profile's height into `--aura-header-height`, so a profile that disagrees shifts the page on
     * every switch.
     */
    export function resolveBandHeightPx(regionProps?: Record<string, unknown>): number;
    /**
     * The mobile aside toggle is the ONLY way to reach the menu when the aside is not inline, so it
     * shows exactly when the mobile aside mode is a drawer/fullscreen.
     */
    export function shouldShowMobileAsideToggle(bootConfig?: MasterFrontendBootConfig): boolean;
    /**
     * CSS of the user menu — NOT scoped by the header tag, on purpose.
     *
     * Painted with the SAME nav palette as the band (it reads as an extension of the header, not as a
     * card of the page), and attached to `document.body`, not to the band: the band carries `backdrop-filter`,
     * which establishes a containing block for fixed descendants, so a panel inside it would be trapped
     * and then clipped by the header region's `overflow: hidden`. Living in the body is what lets it
     * open below the header at all. Injected once per page.
     */
    export function buildUserMenuCss(): string;
    /**
     * Band CSS for one header tag.
     *
     * Scoped by the ELEMENT'S OWN tag (`this.localName`), never by a hardcoded tag: every subclass —
     * including the per-project generated ones — gets the same band without colliding with a sibling
     * header profile that may still be in the DOM.
     *
     * Colors come from DS role tokens with a hex fallback, because `<style id="ds-tokens">` is injected
     * at runtime and may not be there on the first paint.
     */
    export function buildHeaderBandCss(tagName: string): string;
}
declare module "_102033_/l2/shared/sessionUser" {
    export interface SessionUser {
        authenticated: boolean;
        name?: string;
        email?: string;
        /** Avatar URL from the IdP (OIDC `picture`); absent when it does not send one. */
        picture?: string;
    }
    export function parseSessionUser(payload: unknown): SessionUser;
    /** The logged user, fetched once per page. Never rejects. */
    export function getSessionUser(): Promise<SessionUser>;
    /** Test/diagnostic hook: drops the cached probe so the next call asks again. */
    export function resetSessionUserCache(): void;
    /**
     * Initials for the avatar fallback: two from a name ("Guilherme Pereira" -> GP), one from an email
     * ("guilherme@x.dev" -> G), and a neutral dot when there is neither.
     */
    export function userInitials(user: SessionUser): string;
    /** What the avatar announces to a screen reader and shows on hover. */
    export function userLabel(user: SessionUser, anonymousLabel?: string): string;
}
declare module "_102033_/l2/shared/designSystemRuntime" {
    type RuntimeDesignSystemStyle = {
        id: string;
        textContent: string | null;
        dataset: Record<string, string | undefined>;
    };
    type RuntimeDesignSystemDocument = {
        getElementById: (id: string) => RuntimeDesignSystemStyle | null;
        createElement: (tagName: string) => RuntimeDesignSystemStyle;
        head: {
            appendChild: (element: RuntimeDesignSystemStyle) => unknown;
        };
    };
    type DesignSystemCssLoader = (name: string, path: string) => Promise<string>;
    export function listRuntimeDesignSystems(designSystems: readonly string[] | undefined): string[];
    export function resolveRuntimeDesignSystem(designSystems: readonly string[], requestedDesignSystem: string): string | undefined;
    export function getRuntimeDesignSystem(designSystems: readonly string[], runtimeDocument?: RuntimeDesignSystemDocument): string | undefined;
    export function getNextRuntimeDesignSystem(designSystems: readonly string[], currentDesignSystem: string | undefined): string | undefined;
    export function setRuntimeDesignSystem(requestedDesignSystem: string, designSystems: readonly string[], projectId: string, runtimeDocument?: RuntimeDesignSystemDocument, loadCss?: DesignSystemCssLoader): Promise<void>;
}
declare module "_102033_/l2/shared/layout/aura-header-base" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    import { type AuraHeaderAction, type AuraHeaderBrand } from "_102033_/l2/shared/layout/auraHeaderCore";
    import { type SessionUser } from "_102033_/l2/shared/sessionUser";
    export type { AuraHeaderAction, AuraHeaderBrand };
    export { AURA_HEADER_HEIGHT_PX } from "_102033_/l2/shared/layout/auraHeaderCore";
    /** Event a header fires for an action with no route (see `emitHeaderAction`). */
    export const AURA_HEADER_ACTION_EVENT = "collab-aura:header-action";
    export abstract class AuraHeaderBase extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            regionProps: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
            sessionUser: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        /** Profile props handed over by the shell (`brand`, `heightPx`, `props.actions`, `profileName`). */
        regionProps?: Record<string, unknown>;
        currentPath: string;
        /** Who is logged in (for the avatar); undefined until the one-per-page probe answers. */
        sessionUser?: SessionUser;
        /** Guards the probe (once per element) and the broken-photo fallback. */
        private sessionRequested;
        private pictureBroken;
        private userMenu?;
        /** Light DOM — the shell's region CSS and the :root DS tokens depend on it. Do NOT override. */
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        /** Fires the one-per-page session probe, at most once per element. */
        private ensureSessionUser;
        /**
         * The logged user's display name (name, else email, else empty) — for a welcome message. Reading it
         * starts the session probe, so a header that greets the user does not have to ask for the avatar.
         */
        protected get userName(): string;
        /** First name only, which is what a greeting usually wants. */
        protected get userFirstName(): string;
        protected get userEmail(): string;
        private ensureBandStyles;
        /** Title used when the profile carries no brand (the master header names itself). */
        protected get fallbackBrandTitle(): string;
        protected get brand(): AuraHeaderBrand;
        protected get actions(): AuraHeaderAction[];
        protected hasAction(action: AuraHeaderAction): boolean;
        protected get bandHeightPx(): number;
        protected get basePath(): string;
        protected showMobileAsideToggle(): boolean;
        /**
         * Message set for the document language, for the `collab_i18n_start/end` block a header carries
         * when it has fixed copy. Resolution is the runtime's own (exact locale, then primary subtag,
         * then the first declared one), so Ctrl+Alt+L switches the header copy along with the pages.
         */
        protected localized<T>(messages: Record<string, T>): T;
        /** SPA navigation inside the module, full load elsewhere. Use this, never a bare href. */
        protected navigateTo(href: string): void;
        protected readonly handleNavigate: (event: Event) => void;
        /**
         * Announces a header action that has no route behind it (`user`, `search`, anything app-specific).
         *
         * A header must never invent a route: an action with no destination dispatches this event and the
         * app decides what to do (open a menu, a dialog, nothing at all). The event bubbles, so a listener
         * on window/document sees it.
         */
        protected emitHeaderAction(action: string, detail?: Record<string, unknown>): void;
        protected renderAsideToggle(): any;
        /**
         * The mark: inlined markup when the brand carries one (it inherits `currentColor`, so it follows
         * the design system in light and dark), otherwise the `<img>` for a URL. `resolveHeaderBrand`
         * already refused anything unsafe — see `isSafeLogoSvg` — so only a sanitized single `<svg>` root
         * reaches unsafeHTML here. Same shape the 102025 avatar uses.
         */
        protected renderLogo(): any;
        protected renderBrand(): any;
        /**
         * The navigation entries this header links: the project's, filtered by the hrefs the profile
         * selected (`props.navLinks`).
         *
         * With NO selection recorded the whole list survives — a band only calls renderNavLinks() when it
         * was asked for links, and headers generated before the field existed have no list to read.
         */
        protected get navEntries(): ProjectNavigationEntry[];
        protected renderNavLinks(entries?: ProjectNavigationEntry[]): any;
        protected renderModuleLinks(): any;
        protected renderLanguageSwitcher(): any;
        protected renderDesignSystemSwitcher(): any;
        /**
         * The logged user as an avatar: the IdP photo when there is one, otherwise the initials, otherwise
         * a neutral silhouette. It is a BUTTON — clicking announces the `user` action through
         * `emitHeaderAction`, and the app decides what opens (menu, profile, sign-out).
         *
         * Available to a generated header as `this.renderUserAvatar()`; the profile turns it on by listing
         * the `user` action.
         */
        /** Neutral silhouette for a user with no photo and no initials (anonymous, or an IdP that tells us nothing). */
        private renderAvatarFallbackIcon;
        protected renderUserAvatar(): any;
        /** Copy of the user menu. A subclass with an i18n block overrides this. */
        protected get userMenuLabels(): {
            signOut: string;
            anonymous: string;
        };
        private handleAvatarClick;
        /**
         * Opens the identity panel under the avatar.
         *
         * Attached to `document.body`, NOT inside the band: the band carries `backdrop-filter`, which makes
         * it a containing block for fixed descendants, and the shell clips the header region with
         * `overflow: hidden` — a panel rendered in place would be cut off instead of shown.
         */
        private toggleUserMenu;
        private readonly closeUserMenu;
        private readonly handleUserMenuKeydown;
        private readonly handleOutsidePointer;
        /**
         * Ends the session. Uses the runtime hook when the page has it (window.collabRuntimeAuth), and
         * falls back to importing the auth helper on demand — the header never pays for it until a click.
         */
        protected signOut(): Promise<void>;
        /**
         * The optional actions the profile enabled, in a stable order. `search` has no shell runtime behind
         * it: a subclass that declares it renders it itself (see `hasAction`). `user` is the avatar, which
         * the base draws — a subclass may still place it by hand with `renderUserAvatar()`.
         */
        protected renderActions(): any;
        /** Extra CSS for this subclass, injected once per tag. Scope every rule with its own tag. */
        protected bandCss(): string;
        /** The band's content. Everything around it (band, height, styles) belongs to the base. */
        protected abstract renderBand(): unknown;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { AuraHeaderBase } from "_102033_/l2/shared/layout/aura-header-base";
    export class AuraHeader extends AuraHeaderBase {
        protected get fallbackBrandTitle(): string;
        private renderTrace;
        protected renderBand(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: MasterFrontendRouteDefinition[], pathname: string): MasterFrontendRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/contentPageGenome" {
    export interface ContentPageRenderer {
        tag: string;
        entrypoint: string;
    }
    export interface ContentPageGenomeChange {
        ok: boolean;
        nextTag: string;
        nextEntrypoint: string;
        /** Empty when the swap is structurally possible; otherwise why setPage will stay on the current variant. */
        reason: string;
    }
    export function describeContentPageGenomeChange(current: ContentPageRenderer | undefined, genome: number): ContentPageGenomeChange;
}
declare module "_102033_/l2/shared/contentPageGenomePreserve" {
    export function contentPageGenomeToPreserve(currentGenome: number | undefined, nextGenome: number | undefined): number | undefined;
}
declare module "_102033_/l2/shared/shell" {
    import type { MasterFrontendBootConfig, MasterFrontendDeviceKind, MasterFrontendInteractionState, MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
            contentTabs: {
                state: boolean;
            };
            activeContentTabId: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: MasterFrontendInteractionState;
        resolvedDevice: MasterFrontendDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: MasterFrontendRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        private dynamicRegionRenderers;
        private dynamicRegionProps;
        private activeAsideWidthPx?;
        private activeHeaderHeightPx?;
        contentTabs: Array<{
            id: string;
            title: string;
            element: HTMLElement;
            closable: boolean;
        }>;
        activeContentTabId: string;
        private structureUpgraded;
        private structureUpgradeFailed;
        private studioModeOn;
        private structureUpgradeAttempted;
        private structureRetriesLeft;
        private regionsMounted;
        private readonly isEmbedded;
        private contentVariantRenderer?;
        private sitesRetryTimer?;
        private sitesRetriesLeft;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly setHeaderRenderer;
        private readonly setAsideRenderer;
        private readonly setShellProfile;
        private setRegionProfile;
        /**
         * Loads Monaco (if not already loaded) and registers the TypeScript definition models of the
         * project chain, so Monaco resolves the cross-project imports through them.
         *
         * Both deferred to the studio switch on purpose: an app user never opens an editor, so neither
         * cost has a reason to be paid at login. Monaco used to download unconditionally for every
         * visitor from cbeMiniCfe.ts — it's claimed here instead now (idempotent either way, so a
         * concurrent load kicked off elsewhere, e.g. a message preview, is just awaited, not repeated).
         */
        private loadStudioDefinitions;
        /**
         * Puts the client's own services (messages + app) back on the structure's nav3 pair.
         *
         * Called whenever the shell leaves studio mode, by either door: the Ctrl+Alt+S toggle or a
         * header profile switch. No-op while the structure is not up.
         */
        private showRuntimeServices;
        private setRegionRenderer;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private initializeDynamicRegions;
        private getRegionProfile;
        private getRegionPropsFromProfile;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getAsideWidthPx;
        private getAsideDrawerWidthPx;
        private getRegionProps;
        private getActiveContentRenderer;
        private reportContentPageMiss;
        private applyContentPageGenome;
        private getAvailableUxLayouts;
        private listLanguages;
        private getLanguage;
        private setLanguage;
        private rotateLanguage;
        private listDS;
        private getDS;
        private setDS;
        private rotateDesignSystem;
        private rotateContentVariant;
        private readonly registerSitesControls;
        private getRegionProfileNames;
        private getRegionIndex;
        private readonly openContentTab;
        private readonly closeContentTab;
        private readonly activateContentTab;
        private readonly handleContentTabsResize;
        private updateContentTabsMsize;
        private syncContentTabPanels;
        private structureRetryPending;
        private maybeUpgradeStructure;
        private static readonly STRUCTURE_UPGRADE_MAX_ATTEMPTS;
        private attemptStructureUpgrade;
        private verifyStudioStructureRendered;
        private wantsStudioStructure;
        private get structureState();
        private rotateHeaderProfile;
        private setRegionByIndex;
        private getContentPageGenome;
        private setContentPage;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102033_/l2/shared/chartRuntime" {
    import * as echarts from 'echarts/core';
    export { echarts };
    export type { ECharts, EChartsCoreOption } from 'echarts/core';
    /**
     * Handlers for ECharts events, by event name (`click`, `legendselectchanged`, `datazoom`, …).
     *
     * ECharts events do NOT reach the DOM: they are emitted on the instance via `chart.on(...)`, so
     * `@chartclick=${…}` in a Lit template is a listener that never fires — and it COMPILES, because any
     * `@name` is a valid Lit binding. A generated page wrote exactly that, which is why the handlers must
     * come through the directive instead.
     */
    export type ChartEvents = Record<string, (params: never) => void>;
    /**
     * Bind an ECharts option to the element this directive sits on.
     *
     * @param option a full EChartsCoreOption. Every chart type and component this runtime registers above is
     *        available — no `echarts.use()` needed at the call site, which is the whole point of the module:
     *        an unregistered piece renders BLANK with no error.
     * @param events optional handlers, e.g. `{ click: (p) => this.selectCategory(p.name) }`. Rebound on every
     *        update, so a closure over fresh state is always the one that runs.
     *
     * The element must have a height (ECharts measures its container; a container of height 0 draws nothing).
     */
    export const chart: any;
}
declare module "_102033_/l2/shared/shell.defs" {
    export const skill: {
        readonly componentId: "collab-aura-shell";
        readonly purpose: "Render the frontend shell, expose header/aside/content regions, and mount module-owned region renderers.";
        readonly responsibilities: readonly ["Read the boot config injected by the server runtime.", "Resolve the active device from the viewport and module preferences.", "Render the shell layout and region visibility state.", "Control the aside mode as inline, drawer, or fullscreen.", "Load the module renderers for header, aside, and content.", "Apply Aura fallback renderers when a module does not define header or aside.", "Mount the active renderer into each region host."];
        readonly regions: readonly ["header", "aside", "content"];
        readonly supportedDevices: readonly ["desktop", "mobile"];
        readonly supportedShellModes: readonly ["spa", "pwa"];
    };
}
declare module "_102033_/l2/shared/layout/aura-contents" {
    import { LitElement } from 'lit';
    export class AuraContents extends LitElement {
        createRenderRoot(): this;
        render(): any;
    }
}
declare module "_102033_/l2/shared/molecules/cn" {
    export function cn(...inputs: (string | undefined | null | false)[]): string;
}
declare module "_102033_/l2/shared/molecules/tableSort" {
    /**
     * The value the cell wants to be sorted by.
     *
     * Sorting by TEXT is misleading in every column whose text does not sort like the data: masked
     * currency, `dd/mm/yyyy` dates, status labels. That is why a cell may declare its real value:
     *
     *     <TableCell sort-value="987">R$ 987,00</TableCell>
     *     <TableCell sort-value="2026-01-02">2 de janeiro</TableCell>
     *
     * `liveText` is for molecules with live slots, which must read from the projected nodes instead of
     * the source `textContent` — the source is empty once projected.
     */
    export function cellSortKey(cell: Element | null | undefined, liveText?: string): string;
    /** Number out of formatted text. `null` when there is no recognizable number. */
    export function parseFormattedNumber(text: string): number | null;
    /**
     * Compares two keys: numeric when both are numbers, otherwise text with natural collation.
     * Always returns the ASCENDING order — direction is up to the caller.
     */
    export function compareSortKeys(a: string, b: string): number;
}
