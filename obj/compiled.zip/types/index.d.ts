declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102033_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102033_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
    }
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102033_/l2/core/bff-client" {
    export * from "_102029_/l2/bffClient";
}
declare module "_102033_/l2/core/bff-client.test" { }
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102029_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: AuraRouteDefinition[], pathname: string): AuraRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { AuraBootConfig, AuraDeviceKind, AuraInteractionState, AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: AuraInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: AuraRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102033_/l2/shared/interactionRuntime.test" { }
declare module "_102033_/l2/shared/routeRuntime.test" { }
declare module "_102033_/l2/shared/shell.defs" {
    export const skill: {
        readonly componentId: "collab-aura-shell";
        readonly purpose: "Render the frontend shell, expose header/aside/content regions, and mount module-owned region renderers.";
        readonly responsibilities: readonly ["Read the boot config injected by the server runtime.", "Resolve the active device from the viewport and module preferences.", "Render the shell layout and region visibility state.", "Control the aside mode as inline, drawer, or fullscreen.", "Load the module renderers for header, aside, and content.", "Apply Aura fallback renderers when a module does not define header or aside.", "Mount the active renderer into each region host."];
        readonly regions: readonly ["header", "aside", "content"];
        readonly supportedDevices: readonly ["desktop", "mobile"];
        readonly supportedShellModes: readonly ["spa", "pwa"];
    };
}
declare module "_102033_/l2/shared/layout/aura-contents" {
    import { LitElement } from 'lit';
    export class AuraContents extends LitElement {
        createRenderRoot(): this;
        render(): any;
    }
}
