declare module "_102033_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102033_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102033_/l2/core/bff-client.test" { }
declare module "_102033_/l2/core/bff-client" {
    export * from '_102029_/l2/bffClient';
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102033_/l2/shared/bootstrap" {
    import '/_102033_/l2/shared/shell.js';
}
declare module "_102033_/l2/shared/interactionRuntime.test" { }
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from '_102029_/l2/interactionRuntime';
}
declare module "_102033_/l2/shared/routeRuntime.test" { }
declare module "_102033_/l2/shared/routeRuntime" {
    import type { AuraRouteDefinition } from '_102033_/l2/shared/contracts/bootstrap';
    export function matchAuraRoute(routes: AuraRouteDefinition[], pathname: string): AuraRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): any;
    export function getCollabRouteChunkPromises(): any;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell.defs" {
    export const skill: {
        readonly componentId: "collab-aura-shell";
        readonly purpose: "Render the frontend shell, expose header/aside/content regions, and mount module-owned region renderers.";
        readonly responsibilities: readonly ["Read the boot config injected by the server runtime.", "Resolve the active device from the viewport and module preferences.", "Render the shell layout and region visibility state.", "Control the aside mode as inline, drawer, or fullscreen.", "Load the module renderers for header, aside, and content.", "Apply Aura fallback renderers when a module does not define header or aside.", "Mount the active renderer into each region host."];
        readonly regions: readonly ["header", "aside", "content"];
        readonly supportedDevices: readonly ["desktop", "mobile"];
        readonly supportedShellModes: readonly ["spa", "pwa"];
    };
}
declare module "_102033_/l2/shared/shell" {
    import type { AuraBootConfig, AuraDeviceKind, AuraInteractionState, AuraRouteDefinition } from '_102033_/l2/shared/contracts/bootstrap';
    import '/_102033_/l2/shared/layout/aura-aside.js';
    import '/_102033_/l2/shared/layout/aura-header.js';
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: AuraInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: AuraRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from '_102029_/l2/contracts/bootstrap';
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from '_102033_/l2/shared/contracts/bootstrap';
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-contents" {
    import { LitElement } from 'lit';
    export class AuraContents extends LitElement {
        createRenderRoot(): this;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from '_102033_/l2/shared/contracts/bootstrap';
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from '_102029_/l2/shellEvents';
}
