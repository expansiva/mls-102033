declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102033_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
     * mls.actualProject is the fallback when the boot payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102029_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102033_/l2/utils" {
    export interface IFileInfoBase {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    export interface IResolvedFile {
        project: number;
        shortName: string;
        folder: string;
    }
    export function resolveTagToFile(tag: string): IResolvedFile | undefined;
    export function convertFileToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function isPageFile(folder: string): boolean;
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102029_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102029_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102033_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { TemplateResult, PropertyValues } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class MoleculeAuraElement extends StateLitElement {
        cssClass: string;
        protected slotTags: string[];
        /**
         * Opt in to LIVE slots: the consumer's slot content is MOVED into place as real
         * DOM nodes, instead of being read as a string and re-emitted with unsafeHTML.
         *
         * Why this exists: the snapshot path serializes slot children via `outerHTML` and
         * re-parses them. Serializing destroys event bindings and component identity, so
         * anything interactive the consumer puts in a slot is dead on arrival — and nested
         * molecules had to be made inert to keep the parent's snapshot readable. That makes
         * slots content-only, which defeats composition.
         *
         * With live slots the nodes are never serialized: they are moved, and moving preserves
         * listeners, Lit part references and nested custom elements. A molecule that opts in
         * also stops forcing its slotted descendants to be inert — they render normally.
         *
         * Opt-in per molecule so the two mechanisms coexist. Keep the snapshot path where the
         * slot carries DATA to be parsed (`TableHead key=…`, `Item value=…`); use live slots
         * where it carries CONTENT or CONTROLS (`Action`, `Label`, `Icon`, `Trigger`).
         */
        protected usesLiveSlots: boolean;
        /**
         * The consumer's live nodes, per slot tag, held by reference.
         *
         * Holding them is what makes the mechanism survive the anchor coming and going. When a
         * template branch leaves the render (a hidden modal, a collapsed region), Lit removes
         * the anchor and everything under it — including these nodes. Removing a node from the
         * DOM does not destroy it while something still references it, and its listeners stay
         * attached, so the next projection can simply put it back.
         */
        private _liveNodes;
        /** Last anchor that held each key — see `_currentNodes`. */
        private _liveHosts;
        /** Detached holder per key, so eviction does not lose content. */
        private _liveHolders;
        /**
         * Per-element anchors, for molecules that don't pass a slot through but TRANSFORM it.
         *
         * A table is the motivating case: it reads `TableBody > TableRow > TableCell`, sorts and
         * paginates, then re-emits real `<tr>`/`<td>`. The source of a cell's content is a nested
         * element, not a direct child, and there are N×M of them — so an anchor keyed by tag name
         * can't address it. These map an id to the source element instead.
         *
         * The id lives in a WeakMap so the SAME element always gets the SAME id across renders,
         * which is what lets `_liveNodes` survive a row leaving the page and coming back.
         */
        private _liveRefSeq;
        private _liveRefIds;
        private _liveRefs;
        /**
         * Renders the placeholder where a live slot's content lands.
         *
         * The anchor must stay free of Lit bindings: Lit does not manage children it did not
         * create, so nodes appended here survive every re-render. Put bindings around the
         * anchor, never inside it.
         */
        protected renderLiveSlot(tag: string, cls?: string): TemplateResult;
        /**
         * Same as `renderLiveSlot`, but bound to a specific source ELEMENT instead of a tag.
         *
         * Use it when the molecule transforms the slot structure and one tag maps to many
         * destinations — a table cell, a list item. Pass the LIVE element (from `getLiveSlot`),
         * never a snapshot clone: a clone's children are copies, and moving copies projects
         * dead nodes.
         */
        protected renderLiveSlotFrom(source: Element | null | undefined, cls?: string): TemplateResult;
        /**
         * Text currently rendered for a source element, projected or not.
         *
         * A transforming molecule that sorts or filters by cell text cannot read the source
         * element after projection — its children were moved out, so `textContent` is empty.
         * This reads the projected nodes instead, which keeps the value CURRENT: caching the
         * text at capture time would go stale the moment the consumer changed it.
         */
        protected getLiveText(source: Element | null | undefined): string;
        /**
         * The LIVE slot element for `tag` — not the snapshot clone.
         *
         * Structure reads (how many rows, which attributes) should come from here in a molecule
         * that projects, because the snapshot goes stale between mutations and, worse, a
         * re-snapshot after projection reads the emptied sources.
         */
        protected getLiveSlot(tag: string): Element | null;
        /**
         * Moves each live slot's children into its anchor.
         *
         * Runs from `update()` — right after Lit commits the DOM, so the anchors exist. It is
         * deliberately NOT in `updated()`: most molecules override that without calling super,
         * which would silently skip projection.
         */
        private _projectLiveSlots;
        /** Capture-once + reattach-when-empty, shared by both anchor kinds. */
        private _fillAnchor;
        /**
         * Holder per key: a detached element where the nodes wait while they have no anchor.
         * It exists so eviction does not lose content.
         */
        private _holderFor;
        /**
         * The CURRENT nodes for a key, which are not always the captured ones.
         *
         * `_liveNodes` is the list taken at capture time. It goes stale when the consumer REPLACES the
         * slot's content instead of just updating values — `${loading ? spinner : table}`, for example:
         * Lit removes the old nodes and inserts different ones between the same markers, which are
         * still in the anchor. Reattaching the capture list would hand back only the already-discarded
         * nodes, and the region would come back EMPTY when reopened. Measured on 2026-08-04 with
         * demotable--pedidosdetalhe: opening, closing and opening again showed a blank row.
         *
         * Hence the order of preference: the last anchor that held the key (Lit removes the anchor from
         * the DOM, but its children stay INSIDE it), then the holder, and only then the capture.
         */
        private _currentNodes;
        /** The consumer's slot element for `tag`, among this element's own children. */
        private _findSlotChild;
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        _mutationLock: boolean;
        connectedCallback(): void;
        /**
         * Projection hook.
         *
         * `update()` is where Lit commits the template to the DOM, so the anchors exist right
         * after `super.update()`. Chosen over `updated()` on purpose: most molecules override
         * `updated()` without calling super, and projection would silently never run. No
         * molecule overrides `update()`.
         */
        protected update(changed: PropertyValues): void;
        disconnectedCallback(): void;
        private _stopNativeFormEvent;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
        protected getSlotClass(tag: string): string;
    }
}
declare module "_102033_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102033_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/cbe/cbeAuth" {
    export type CollabAuthProvider = 'google';
    /** The logged user from the JS-readable `loginUser` cookie ('' when anonymous). */
    export function getLoginUser(): string;
    export function isLoggedIn(): boolean;
    /** Redirects to collab-auth; it returns to this origin with tokens in the fragment. */
    export function startCollabLogin(provider?: CollabAuthProvider): void;
    /** Clears the VM session cookies (cauth/crefresh/loginUser) and reloads. */
    export function logoutCollab(): Promise<void>;
    /**
     * Shows the sign-in page when this host requires a session and there is none.
     * Called by cbeMiniCfe after the login round-trip (the loginUser cookie is the
     * session signal). No-op on localhost and when already signed in.
     */
    export function showLoginGateIfNeeded(): void;
    global {
        interface Window {
            collabRuntimeAuth?: {
                login: (provider?: CollabAuthProvider) => void;
                logout: () => Promise<void>;
                user: () => string;
            };
        }
    }
}
declare module "_102033_/l2/cbe/global" {
    global {
        export interface Window {
            mls?: {
                api: {
                    cbeLogin: () => Promise<{
                        statusCode: number;
                    } | undefined>;
                };
                actualProject?: number;
                setActualProject?: (project?: number) => void;
                baseMonaco?: string;
                editor: {
                    InitMonaco: () => Promise<void>;
                };
                stor: {
                    orgs: Record<string, unknown>;
                    files: Record<string, unknown>;
                    localDB: {
                        getAllKeys: () => Promise<string[]>;
                    };
                    cache: {
                        installIfNeeded: () => Promise<unknown>;
                    };
                    server: {
                        loadProjectInfoIfNeeded: (project: number, forceUpdate?: boolean) => Promise<boolean>;
                    };
                    loadProjectdependenciesInfoIfNeed: (project: number, forceUpdate?: boolean) => Promise<number[]>;
                };
            };
            latest?: {
                www?: string;
                libs?: string;
                monaco?: string;
                indexHTML?: string;
                l7?: string;
            };
            monacoReady?: Promise<void>;
        }
    }
    export interface StudioMls {
        baseMonaco?: string;
        editor: {
            InitMonaco: () => Promise<void>;
        };
    }
}
declare module "_102033_/l2/cbe/driverVm" {
    /**
     * Repository path of a file: `l<level>/<folder>/<shortName><extension>`.
     * Same construction the GitHub driver uses, so both drivers address a file
     * identically (level 0 has no prefix; the extension may come without the dot).
     */
    export function toShortPath(fileInfo: mls.stor.IFileInfoBase): string;
    export class DriverVm extends mls.stor.others.DriverIOBase {
        /** The slot this driver occupies — see the header note. */
        shortName: mls.cbe.Provider;
        /** Not bound to a single project: it serves every project the VM hosts. */
        project: number;
        driverVersion: string;
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], _comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        /**
         * Content to persist, read the same way the GitHub driver does: force
         * inLocalStorage so getContent serves the LOCAL edit — otherwise a cache miss
         * would call this very driver back — and restore the flag afterwards.
         */
        private readFilePayload;
        getHistory(_fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(_fileInfo: mls.stor.IFileInfo, _ref: string): Promise<string | null>;
        getUrl(_file: mls.stor.IFileInfo): string;
        getVersionFromFiles(): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(): Promise<boolean>;
        reviewPullRequest(): Promise<boolean>;
        listPullRequests(): Promise<mls.stor.others.IPullRequest[]>;
        listForks(): Promise<mls.stor.others.IFork[]>;
        listBranches(): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(): Promise<mls.stor.others.IOrg[]>;
        createRepository(): Promise<boolean>;
        deleteRepository(): Promise<boolean>;
        createFork(): Promise<boolean>;
        renameRepository(): Promise<boolean>;
        createFileInRepo(): Promise<boolean>;
        changeVisibility(): Promise<boolean>;
        verifyRepositoryNew(): Promise<'free' | 'reuse' | 'wait' | 'error'>;
        verifyPermission(): Promise<mls.stor.others.IPermission>;
        addVariable(): Promise<boolean>;
        updateVariable(): Promise<boolean>;
        listVariables(): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(): Promise<boolean>;
        checkFork(): Promise<boolean>;
        checkForkIO(): Promise<boolean>;
        syncFork(): Promise<boolean>;
        createNewBranch(): Promise<boolean>;
        createPullRequest(): Promise<boolean>;
    }
}
declare module "_102033_/l2/cbe/initStudio" {
    import type { StudioMls } from "_102033_/l2/cbe/global";
    /** Loads Monaco and initializes it. Idempotent — safe to call more than once. */
    export function initStudio(mls: StudioMls): Promise<void>;
    /**
     * Sets mls.l5.actualOrg for `project` — port of collabInit.setOrgActual
     * (mls-100554), which never runs on the VM runtime. Without this, actualOrg
     * stays undefined forever here, and any save through serviceSave.ts throws
     * "No organization selected", even for a project whose org index is
     * perfectly resolvable (project 0 in the org list is a valid index, not "no
     * org" — serviceSave.ts's own check must compare against undefined, not use
     * a falsy check, for this to actually take effect).
     */
    export function setOrgActual(project: number): void;
    /**
     * Registers the VM storage driver in the 'github' slot — the slot the cbe login marker points at
     * (see driverVm.ts for why it is that slot). Without it every source read resolves the GitHub
     * driver and fails with `Driver _<project>_GitHub not found`, since no driver is registered at all
     * on the VM.
     *
     * Lives here, not in the studio header: that header only mounts through the `setHeader(2)` path,
     * while Ctrl+Alt+S never creates it — and both need the driver. Dynamic import on purpose
     * (DriverVm extends a class that only exists once the lib is loaded). Idempotent and never fatal.
     */
    export function registerVmDriver(): Promise<void>;
    /**
     * Registers the TypeScript definition model of a project and of every project it depends on, so
     * Monaco resolves imports across the workspace (`/_102027_/l2/...` and friends) instead of
     * flagging them as missing modules.
     *
     * Port of collabInit.initCompileMonaco (mls-100554), which never runs on the VM. Requires BOTH
     * Monaco initialized and the cbe login done — the index of each project comes from the IndexedDB
     * the login fills (`readPrjInfo().indexModules`, fed by the compiled.zip's types/index.d.ts).
     *
     * Runs once per page. A project that fails is logged and skipped: a missing definition degrades
     * the editing experience, it must never break the studio bootstrap.
     */
    export function loadProjectDefinitions(project: number): Promise<void>;
}
declare module "_102033_/l2/cbe/cbeMiniCfe" {
    export function initCbeMiniCfe(): Promise<void>;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "custom" | "default";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102033_/l2/cbe/runtimeMessagesEnvironment" {
    import { type CollabProgramMenu } from "_102036_/l2/environmentContract";
    export function buildProgramMenu(): Promise<CollabProgramMenu[]>;
    /**
     * Program navigation for the unified shell:
     * - Pages of the CURRENT app: SPA navigation (pushState + popstate), no reload.
     * - Other apps (monitor, audit, another module): a nav3 content TAB hosting an
     *   iframe — no full-page flicker, each app keeps its own design system in its
     *   own context, and the "several screens as tabs" workflow falls out for free.
     * - Fallback (no nav3 yet): plain navigation.
     */
    export function openProgramUnified(item: {
        url?: string;
        pageName?: string;
    }): Promise<void>;
    /** Applies the generic runtime environment (call only when self-hosting —
     * a project-provided messages aside brings its own environment). */
    export function applyRuntimeMessagesEnvironment(): void;
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102033_/l2/studio/studioTextEdit" {
    export type TextOrigin = IStaticOrigin | II18nOrigin | IDynamicOrigin;
    export interface IStaticOrigin {
        type: 'static';
        /** Offset in the source where the text starts */
        startOffset: number;
        /** Offset in the source where the text ends */
        endOffset: number;
        /** Original text found in the source */
        originalText: string;
    }
    export interface II18nOrigin {
        type: 'i18n';
        /** Key in the messages object (e.g. 'login') */
        key: string;
        /** Expression in the template (e.g. 'this.msg.login') */
        templateExpression: string;
        /** Every occurrence across the message objects, by language */
        languages: II18nEntry[];
    }
    export interface II18nEntry {
        /** Object name (e.g. 'message_en') */
        objectName: string;
        /** Language (e.g. 'en') */
        lang: string;
        /** Current value */
        value: string;
        /** Offset where the string literal starts (quote included) */
        startOffset: number;
        /** Offset where the string literal ends (quote included) */
        endOffset: number;
    }
    export interface IDynamicOrigin {
        type: 'dynamic';
        /** Why it is not editable */
        reason: string;
    }
    export interface IEditResult {
        success: boolean;
        newSource?: string;
        error?: string;
    }
    /**
     * Identifies where a visible text comes from.
     *
     * @param text - Visible text (e.g. "Login")
     * @param source - Full .ts file content
     */
    export function findTextOrigin(text: string, source: string): TextOrigin;
    /**
     * Applies a text edit to the source.
     *
     * @param origin - Origin returned by one of the find* functions
     * @param newText - New text
     * @param source - Full .ts file content
     * @param lang - Current language (for i18n, edits only that language; all of them when undefined)
     */
    export function applyTextEdit(origin: TextOrigin, newText: string, source: string, lang?: string): IEditResult;
    /** A ${...} expression in the template, in the order it appears. */
    export interface ITemplateExpression {
        /** Sequential index in the template (0, 1, 2, ...) */
        index: number;
        /** Full expression (e.g. 'this.msg.login') */
        expression: string;
        /** The i18n key when it is an i18n pattern, null otherwise */
        i18nKey: string | null;
        type: 'i18n' | 'dynamic';
        /** Offset where the expression starts (past the ${) */
        startOffset: number;
        /** Offset where the expression ends (before the }) */
        endOffset: number;
    }
    /**
     * Ordered map of every ${...} expression in the html`...` template of render().
     * The order matches the order of the text nodes in the rendered DOM.
     */
    export function buildTemplateMap(source: string): ITemplateExpression[];
    /**
     * Resolves the i18n origin DIRECTLY by key, with no ambiguity.
     *
     * This is the correct path: used when the DOM carries the key via data-i18n-key (emitted by the
     * t() helper). It does not depend on occurrence counting, DOM order, or the text matching some
     * literal — so it resolves distinct keys that share the SAME value.
     *
     * @param key - i18n key (e.g. 'colFormaPagamento')
     * @param source - Full .ts file content
     * @param _lang - Current language (unused here; per-language editing happens in applyTextEdit).
     *                Kept for signature symmetry.
     */
    export function findTextOriginByKey(key: string, source: string, _lang?: string): TextOrigin;
    /** Every i18n key whose value matches the given text, in declaration order. */
    export function findAllI18nMatches(text: string, source: string, lang?: string): {
        key: string;
        origin: II18nOrigin;
    }[];
    /**
     * Resolves the text origin using the DOM occurrence index to disambiguate when several i18n keys
     * share the same value.
     *
     * NOTE: this is the FALLBACK path, for text that was not tagged with data-i18n-key. Prefer
     * findTextOriginByKey for deterministic resolution.
     *
     * @param text - Visible text
     * @param source - Source holding the i18n block (the shared base class, on generated pages)
     * @param occurrenceIndex - Which occurrence of this text in the DOM (0-based)
     * @param lang - Current language
     * @param templateSource - Source holding the render() template, when it is a DIFFERENT file.
     *        Generated pages split the two: messages live in `web/shared/<name>.ts` (the base class) and
     *        the template in `web/desktop/page<N>/<name>.ts`. Ordering the matches needs the TEMPLATE,
     *        so passing only the shared source would silently degrade to declaration order.
     */
    export function findTextOriginByOccurrence(text: string, source: string, occurrenceIndex: number, lang?: string, templateSource?: string): TextOrigin;
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102033_/l2/studio/studioEditTarget" {
    /** A page source resolved from the DOM, ready to edit. */
    export interface IStudioEditTarget {
        project: number;
        shortName: string;
        folder: string;
        /** `_<project>_<folder>/<shortName>` — for display. */
        page: string;
        storFile: mls.stor.IFileInfo;
        model: mls.editor.IModelBase;
    }
    export type StudioEditTargetResult = {
        ok: true;
        target: IStudioEditTarget;
    } | {
        ok: false;
        reason: string;
    };
    interface IResolvedFile {
        project: number;
        shortName: string;
        folder: string;
    }
    /**
     * Tag of a page component -> source file coordinates.
     *
     * PORT of `convertTagToFileName` (`_102020_/l2/utils.ts`), legacy branch only: a page tag always
     * ends with `-<project>`, so the new-format branch (`resolveNewTag`, which needs
     * `mls.actualProject`) can never apply here.
     *
     *   cafe-flow--web--desktop--page11--pos-workspace-102051
     *     -> { project: 102051, shortName: 'posWorkspace', folder: 'cafeFlow/web/desktop/page11' }
     */
    export function tagToFileInfo(tag: string): IResolvedFile | undefined;
    /** The mounted page element inside a region host, skipping our own overlay chrome. */
    export function findPageElement(host: HTMLElement): HTMLElement | null;
    /** Current app language, reduced to the primary subtag: `message_pt`, never `message_pt-br`. */
    export function currentLanguage(): string;
    /**
     * Resolves the page source for the element mounted in `host`.
     *
     * Never guesses: an unresolvable tag or a missing stor entry comes back as `{ ok: false }` with a
     * reason to show, because editing the wrong file is far worse than not editing.
     */
    export function resolveEditTarget(host: HTMLElement): Promise<StudioEditTargetResult>;
    /**
     * Folder of the SHARED base class of a page, derived structurally.
     *
     *   <module>/<device>/.../page<N>  ->  <module>/<device>/shared
     *   cafeFlow/web/desktop/page11    ->  cafeFlow/web/shared
     *
     * Generated pages split the component in two: the shared file is the base class and owns the i18n
     * catalog, while the page file owns render(). Editing an i18n text therefore writes to the SHARED
     * file, not to the page.
     *
     * Structural first, `module.js` second (resolveSharedTarget): the convention holds in every project
     * checked (102051, 102043) and costs no request, while 102051 has no `module.ts` at all — so the
     * original preview path (import module.js, read shared[device].sharedPath) would resolve nothing
     * there.
     */
    export function deriveSharedFolder(folder: string): string | null;
    /**
     * The shared base class of a page target, or null when there is none.
     *
     * Same shortName, different folder. Returns null quietly: a page without a shared base is normal.
     */
    export function resolveSharedTarget(target: IStudioEditTarget): Promise<IStudioEditTarget | null>;
    /**
     * Writes the edited source into the LOCAL store (IndexedDB), immediately.
     *
     * WHY THIS IS NOT REDUNDANT WITH EDITING THE MODEL
     * libModel wires a listener on model changes (via the MonacoModelCreated event) that ends up calling
     * `localStor.setContent` — but it is DEBOUNCED BY 400ms
     * ([libModel.ts:462](mls-102027/l2/libModel.ts#L462) -> `_checkSameContent`). Saving right after the
     * edit therefore raced it: `DriverVm.readFilePayload` forces `inLocalStorage = true` and calls
     * `getValueInfo()`, which in that state reads `localDB.readFile` — and with no record yet the save
     * died with `Object not found in IndexedDB, key: File_..._.ts`.
     *
     * Doing it eagerly is not a workaround for the debounce: it is the same write, sooner. The late
     * listener recomputes and converges (and `saveTarget` resets the CRC so it converges to CLEAN).
     * `localStor.setContent` sets `inLocalStorage` by itself — hence no manual flag here.
     */
    export function persistLocalEdit(target: IStudioEditTarget, newSource: string): Promise<void>;
    /**
     * Recompiles after an edit so the fresh JS lands in the service worker cache.
     *
     * In the studio the editor drives this on every keystroke; here nothing does, and the SW cache is
     * what serves the page module (the premise of this task) — without this, a reload would still get
     * the previous build. Never fatal: the DOM already shows the text edit.
     */
    export function compileAfterEdit(target: IStudioEditTarget): Promise<void>;
    /** True when the file carries unsaved local edits. */
    export function isDirty(target: IStudioEditTarget): boolean;
    /**
     * Persists the source through the VM driver (DriverVm.setContents -> /exec -> VM file tree).
     *
     * `inLocalStorage` is deliberately LEFT ALONE (an earlier version cleared it, mirroring serviceSave,
     * which was wrong here): the lib's own `setContents` clears the local copy and lowers the flag itself
     * after a successful write, but ONLY for files still marked as local
     * ([mls.js:8113](static/libs/mls.js#L8113)). Clearing it beforehand skipped that cleanup and left a
     * stale local copy behind.
     *
     * Throws when the write fails, leaving the local edit in place so it can be retried — a failed save
     * must never look like a successful one.
     */
    export function saveTarget(target: IStudioEditTarget, comment: string): Promise<void>;
}
declare module "_102033_/l2/studio/studioLiveUpdateHotSwap" {
    import type { ILiveUpdateMode } from "_102033_/l2/studio/studioLiveUpdate";
    export const hotSwapMode: ILiveUpdateMode;
}
declare module "_102033_/l2/studio/studioLiveUpdateReload" {
    import type { ILiveUpdateMode } from "_102033_/l2/studio/studioLiveUpdate";
    export const reloadMode: ILiveUpdateMode;
}
declare module "_102033_/l2/studio/studioLiveUpdate" {
    import type { IStudioEditTarget } from "_102033_/l2/studio/studioEditTarget";
    export interface ILiveUpdateContext {
        /** File that was edited — often the SHARED base class, not the page. */
        edited: IStudioEditTarget;
        /** The mounted page, whose tag is the one registered in the custom element registry. */
        page: IStudioEditTarget;
        /** Tag currently mounted in the region host. */
        pageTag: string;
    }
    export interface ILiveUpdateResult {
        ok: boolean;
        /** Short sentence for the editor status strip. */
        message: string;
    }
    export interface ILiveUpdateMode {
        readonly name: LiveUpdateModeName;
        /** One-line description, shown by studioLiveUpdate.list(). */
        readonly description: string;
        apply(ctx: ILiveUpdateContext): Promise<ILiveUpdateResult>;
    }
    export type LiveUpdateModeName = 'hotSwap' | 'reload' | 'off';
    export function listLiveUpdateModes(): LiveUpdateModeName[];
    export function isLiveUpdateMode(name: string): name is LiveUpdateModeName;
    export function getLiveUpdateMode(): LiveUpdateModeName;
    export function setLiveUpdateMode(name: string): LiveUpdateModeName;
    /**
     * Applies an already-persisted edit to the running app, using the active mode.
     *
     * Never throws: a failure here means the edit is in the source but the screen may show the old text
     * on a remount — worth reporting, never worth breaking the edit flow over.
     */
    export function applyLiveUpdate(ctx: ILiveUpdateContext): Promise<ILiveUpdateResult>;
}
declare module "_102033_/l2/studio/studioEditor" {
    import { type IStudioEditTarget } from "_102033_/l2/studio/studioEditTarget";
    export type StudioEditMode = 'off' | 'select' | 'text' | 'inspect';
    export interface StudioEditorEvents {
        /** Target resolution changed (armed, page navigated, unresolvable). */
        onTarget?: (target: IStudioEditTarget | null, reason: string) => void;
        /** A file was written to the VM. There is no save step — every edit persists immediately. */
        onSaved?: (target: IStudioEditTarget) => void;
    }
    export class StudioEditor {
        private host;
        private mode;
        private overlayEl;
        private selectedEl;
        private lastHoveredEl;
        private target;
        /** Shared base class of the current page, resolved lazily — it owns the i18n catalog. */
        private sharedTarget;
        private sharedResolved;
        private statusText;
        private events;
        private editSpan;
        private moleculeUnlockTimer;
        private hostObserver;
        private hostResizeObserver;
        private overlayHidden;
        private lastPageTag;
        /** Where the editor's own chrome (the status toast) lives — the SERVICE element, not the body. */
        private chromeHost;
        private statusEl;
        private chromePositionPatched;
        constructor(events?: StudioEditorEvents);
        /**
         * Binds to a region host. Idempotent; rebinding to a new host detaches from the old one.
         *
         * @param host - the region host the editor watches and captures events on.
         * @param chromeHost - where the editor's own UI (the status toast) is mounted. Pass the SERVICE
         *        element: a toast on the body reads as an app-wide notification and escapes the panel. It
         *        must NOT be the region host — nothing may sit between it and the page element.
         */
        attach(host: HTMLElement, chromeHost?: HTMLElement): void;
        /**
         * Re-resolves the target when the mounted page changes.
         *
         * Without this, navigating with the editor armed would write into the PREVIOUS page's source —
         * the one thing this flow must never do. The shell swaps the host's child on navigation and on a
         * variation swap, so watching childList covers both.
         */
        private watchHost;
        private isHostVisible;
        /**
         * Shows/hides the overlay without changing the armed state.
         *
         * Hiding CLEARS the selection: coming back to a panel whose page may have been replaced, a kept
         * selection would point at a stale element — and a marking that survives what it marks is exactly
         * the bug this guards against.
         */
        setOverlayVisible(visible: boolean): void;
        /** Unbinds completely: listeners, overlay and injected CSS all go. */
        detach(): void;
        getMode(): StudioEditMode;
        getTarget(): IStudioEditTarget | null;
        /** Shows a message on the editor's own status strip. */
        showStatus(text: string): void;
        /**
         * Arms or disarms the editor.
         *
         * `off` REMOVES the listeners — while armed the page cannot be used normally (every pointer event
         * is captured), so this is the switch between "navigating" and "editing".
         */
        setMode(mode: StudioEditMode): void;
        /** Re-resolves the page source — call after the app navigates or swaps variation. */
        refreshTarget(): Promise<void>;
        private addListeners;
        private removeListeners;
        /**
         * The mode, self-healed.
         *
         * `text` is only real while the edit span is alive. It can die without a blur — a Lit re-render of
         * the page drops the span, and element removal does not reliably fire blur — and every handler
         * short-circuits in `text` mode, so a stale `text` froze the editor: no hover, no selection, and
         * no way back short of disarming. Recovering here keeps that unreachable.
         */
        private currentMode;
        private onHostPointerDown;
        private onHostClick;
        private onHostMouseMove;
        private onHostMouseLeave;
        private onScrollResize;
        private isControl;
        /**
         * Walks up to the nearest custom element that is NOT the page component itself, so selecting
         * inside a molecule selects the molecule and not its internal markup.
         */
        private resolveSelectableElement;
        private pageTag;
        private findClickedTextNode;
        /** The i18n key of the nearest ancestor carrying data-i18n-key (emitted by the t() helper). */
        private resolveI18nKey;
        /**
         * Index of this text node among the nodes with the same value, in document order.
         *
         * When at least one match is Lit-bound, the universe narrows to the bound ones so incidental
         * static text does not inflate the index — but the target itself always enters, by identity.
         */
        private getTextOccurrenceIndex;
        private isLitBoundTextNode;
        /**
         * Isolates the clicked text node in a temporary contenteditable span.
         *
         * The span (rather than making the parent editable) is what stops a native button from treating
         * Space as a click: focus goes to the span, not the button.
         *
         * @returns true when the span was created — the caller only switches to `text` mode then.
         */
        private enableTextEdit;
        /** Nearest ancestor that is a molecule (they expose `_mutationLock`), or null. */
        private findMoleculeHost;
        /**
         * Writes the edit into the page source.
         *
         * With a data-i18n-key present the origin is resolved deterministically by key; otherwise by
         * occurrence. A `dynamic` origin means the text is DATA, not code — very common in the app (the
         * preview runs with empty data, the app with real data), so it is reported as information, not as
         * a failure.
         */
        private applyTextEditToSource;
        /** The shared base class of the current page, resolved once per page. */
        private getSharedTarget;
        private injectStyles;
        private createOverlay;
        private clearOverlay;
        /**
         * Creates the status toast INSIDE the service element.
         *
         * Deliberately not part of the fixed overlay on the body: there it rendered as a viewport-level
         * notification, outside the panel it belongs to. Absolute inside the service keeps it scoped —
         * which also means it needs the service to be a positioned ancestor.
         */
        private createStatusEl;
        private setStatus;
        private renderStatus;
        private drawStatusOnly;
        private drawHover;
        private drawSelection;
        private selectionHtml;
        private drawBoxModel;
        private flashError;
        private applyCursor;
    }
}
declare module "_102033_/l2/cbe/serviceClientApp" {
    import { ServiceBase, type IService, type IServiceMenu, type IToolbarContent } from "_102027_/l2/serviceBase";
    export class ServiceClientApp extends ServiceBase {
        details: IService;
        private editor?;
        private editArmed;
        private editArming;
        private studioModeObserver?;
        /** Stable reference: mls.events removes a subscriber by identity. */
        private readonly onToolBarSelected;
        private levelSubscribed;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        /**
         * Follows the shell's `data-studio-mode` so the edit tools appear/disappear with Ctrl+Alt+S.
         *
         * Without this the toolbar would only pick the change up on the next onServiceClick, so entering
         * studio mode would show no edit affordance until the user reclicked the service icon.
         *
         * It also DISARMS on the way out: leaving the editor armed in client mode would swallow every
         * pointer event and make the app unusable.
         */
        private watchStudioMode;
        /**
         * Follows the level through `ToolBarSelected`, the lib's own channel.
         *
         * There is no level event in `mls.events` (`TypeEvent` is a closed union); `ToolBarSelected` is a
         * SERVICE SELECTION event that carries the level, and a level switch ends in one: nav1 writes the
         * level, nav2 flags the change and restores the level's last service
         * ([collab-nav-2.ts:371](mls-102041/l2/collab-nav-2.ts#L371)), which fires it
         * ([collab-nav-2.ts:254](mls-102041/l2/collab-nav-2.ts#L254)). Same channel serviceHistories and
         * serviceCollabFileSystem already use.
         *
         * ALL levels, not just the edit one: the event is fired at the level being entered, so subscribing
         * only to 3 would arm the editor and never disarm it.
         *
         * Two consequences of using a selection event as a level signal, both acceptable because
         * `syncEditMode` is idempotent: it also fires when the user picks another service in the same level
         * (a free re-sync), and `fire` debounces 200ms by default, so arming lags the switch slightly. What
         * it does NOT cover: a level whose restore finds nothing to select emits no event at all — hence the
         * re-check in adoptAppHost, and `onServiceClick` calling the same sync.
         */
        private watchLevel;
        /** True only in studio mode: the shell publishes it, so no shell change is needed. */
        private isStudioMode;
        /**
         * The region host the editor binds to.
         *
         * NOT the page element and NOT a wrapper around it: `mountRegion` reuses the mounted element by
         * comparing `host.firstElementChild.tagName` with the route tag, so anything inserted in between
         * makes the shell remount the screen on its next render.
         */
        private regionHost;
        /**
         * Arms the editor while on the edit level, disarms otherwise. The single decision point.
         *
         * Studio mode is required on top of the level: leaving studio mode (Ctrl+Alt+S) does NOT reset the
         * nav3 level, so without that condition the editor would stay armed in a client session — capturing
         * every pointer event and making the app unusable.
         */
        private syncEditMode;
        private adoptRetriesLeft;
        private adoptAppHost;
        attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
        private applyRegionHeight;
        render(): any;
    }
}
declare module "_102033_/l2/cbe/serviceRuntimeMessages" {
    import { ServiceBase, type IService, type IServiceMenu, type IToolbarContent } from "_102027_/l2/serviceBase";
    export class ServiceRuntimeMessages extends ServiceBase {
        details: IService;
        private readonly tabNames;
        private static readonly TAB_STORAGE_KEY;
        private loadStorageRecord;
        private saveLastTab;
        private initialTabIndex;
        menu: IServiceMenu;
        private setMessagesTab;
        onServiceClick(_visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        createRenderRoot(): this;
        connectedCallback(): void;
        private adoptMessagesElement;
        private ensuring;
        private ensureMessages;
        attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
        private applyInnerHeight;
        render(): any;
    }
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        /**
         * The environment mode the SERVER resolved for this project (`production | homologation | development |
         * presentation`). The client only displays it; it never decides it. Absent on a runtime older than the
         * modes.
         */
        appEnv?: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        languages?: string[];
        designSystem?: string;
        designSystems?: string[];
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
            /** Unified nav3 (runtime): content-region tabs hosting arbitrary elements. */
            collabRuntimeNav3?: {
                openTab: (tab: {
                    id: string;
                    title: string;
                    element: unknown;
                    closable?: boolean;
                }) => void;
                closeTab: (id: string) => void;
                activateTab: (id: string) => void;
                listTabs: () => string[];
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102033_/l2/cbe/studioHeader" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export const STUDIO_PROJECT = 102041;
    export const STUDIO_BASE_PROJECT = 100554;
    export const ANONYMOUS_SERVICES: string[];
    export const SERVICE_MESSAGES = "_102033_/l2/cbe/serviceRuntimeMessages";
    export const SERVICE_APP = "_102033_/l2/cbe/serviceClientApp";
    /**
     * Adds the runtime service pair to a scanned service list, per level.
     *
     * BOTH toolbars need it — the content structure's nav2s and the studio header's — because they
     * drive the SAME nav3s. A toolbar without these entries strands the user: switching header
     * profile would leave no way back to the app or the messages.
     *
     * Also drops the studio's own serviceCollabMessages (on the VM it points at the
     * msg.collab.codes endpoints and blanks out — ours is the messages service here) and seeds each
     * nav2's last-service memory, so a level restore lands on the pair.
     */
    export function withRuntimeServices(services: string[], nav2Left?: Element | null, nav2Right?: Element | null): string[];
    export function ensureStudioPageAssets(): void;
    /** Port of CollabInit.getServices (mls-100554): menu actions per level/position. */
    export function buildStudioServices(siteProject: number): Promise<string[]>;
    export class CbeStudioHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            navsReady: {
                state: boolean;
            };
            navsError: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        navsReady: boolean;
        navsError: string;
        constructor();
        createRenderRoot(): this;
        connectedCallback(): void;
        private loadNavModules;
        private applyStudioServices;
        render(): any;
    }
}
declare module "_102033_/l2/cbe/studioStructure" {
    import "_102033_/l2/cbe/serviceClientApp";
    import "_102033_/l2/cbe/serviceRuntimeMessages";
    export const NAV1_HEIGHT_PX = 30;
    export const NAV2_HEIGHT_PX = 36;
    /**
     * Puts the runtime pair back on the nav3s — messages left, app right.
     *
     * What CLIENT mode shows. Leaving studio mode has to force these back: the toolbars remember the
     * last service opened, which by then is whatever the user was doing in the studio.
     */
    export function showRuntimeServices(host: ParentNode): void;
    /**
     * Builds the studio structure and appends it to `container`. Returns the
     * collab-page element, or throws when the studio environment is unavailable.
     * The caller decides when to reveal it / hide the classic layout.
     */
    export function upgradeToStudioStructure(container: HTMLElement, siteProject: number): Promise<HTMLElement>;
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    /** The event the shell listens for to send the user back to the collab-auth login. */
    export const BFF_UNAUTHENTICATED_EVENT = "collab-bff-unauthenticated";
    /** Explicit override (email). Empty string clears it and the session cookie takes over again. */
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102033_/l2/core/bff-client" {
    export * from "_102029_/l2/bffClient";
}
declare module "_102033_/l2/core/bff-client.test" { }
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102033_/l2/shellEvents";
}
declare module "_102033_/l2/shared/navigationVisibility" {
    /**
     * The items this user may see: `item.actors` ∩ the user's authorities of THIS module.
     *
     * Pure and conservative. With no authorities known — which is every session until the token issuer starts
     * emitting them — NOTHING is filtered: a menu that empties itself the moment a lookup fails would be a
     * worse failure than an unfiltered one. An item that declares no `actors` is for everybody either way.
     */
    export function visibleNavigation<T>(navigation: readonly T[], authorities: readonly string[], moduleId: string): T[];
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
            authorities: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        currentPath: string;
        /** The user's authorities, asked of the server once (the token is httpOnly; JS cannot read claims). */
        authorities: string[];
        createRenderRoot(): this;
        connectedCallback(): void;
        /**
         * The claims live in an httpOnly cookie, so the client cannot read them — it ASKS. Best-effort: a
         * failure leaves the list empty, which means "filter nothing" and the menu behaves as it always did.
         */
        private loadAuthorities;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/auraNavigate" {
    /** True when `href` is a route of the module currently booted (SPA navigation applies). */
    export function isInternalModuleHref(href: string, basePath: string): boolean;
    /**
     * Active state of a region's navigation entry. The module root answers to its aliases
     * (`/index.html`, `/overview`) — the rule the aside has always applied, now shared with the header.
     */
    export function isRegionLinkActive(href: string, currentPath: string, basePath?: string): boolean;
    export interface AuraNavigateOptions {
        /** Module base path from the boot config; routes outside it are a full page load. */
        basePath?: string;
        /** Ran right after an in-module navigation starts (the aside closes its drawer here). */
        afterNavigate?: () => void;
        busyLabel?: string;
        errorTitle?: string;
    }
    /**
     * Navigates to `href`: SPA push inside the current module (guarded by the blocking UI), full page
     * load anywhere else. Returns false when the href is not navigable (empty, or not absolute).
     */
    export function auraNavigate(href: string, options?: AuraNavigateOptions): boolean;
    /** Click handler for an in-app anchor: same protocol, taking the href from the event target. */
    export function auraNavigateFromEvent(event: Event, options?: AuraNavigateOptions): void;
}
declare module "_102033_/l2/shared/layout/auraHeaderCore" {
    import type { AppHeaderAction, AppHeaderBrand } from "_102029_/l2/runtimeConfigTypes";
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    /**
     * Fixed header band, in px.
     *
     * Every header profile in `clientShell.regions.header.profiles` MUST declare this as its
     * `heightPx`: the shell turns the active profile's `heightPx` into `--aura-header-height`, so
     * profiles with different values shift the whole page when switched (Ctrl+Alt+S / mls.sites.setHeader).
     */
    export const AURA_HEADER_HEIGHT_PX = 66;
    /** Mobile breakpoint of the header band (the shell keeps its own for the region layout). */
    export const AURA_MOBILE_BREAKPOINT_PX = 768;
    export type AuraHeaderBrand = AppHeaderBrand;
    export type AuraHeaderAction = AppHeaderAction;
    /** Hard cap for an inlined mark. Generous on purpose: a real mark may carry defs and many paths. */
    export const MAX_LOGO_SVG_BYTES = 12000;
    /**
     * Whether an SVG markup is safe AND suitable to be inlined in the header band.
     *
     * The markup is inlined, so it is executable surface: anything that can script, fetch or embed is
     * refused. It must also be a single `<svg>` root with a `viewBox` and no intrinsic size, or it cannot
     * scale into the band. Everything else — how many shapes, which colors, how it looks — is the
     * designer's call, not this function's.
     *
     * `monochrome: true` additionally requires currentColor-only paint (what makes a mark follow the
     * design system in both themes); it is OPT-IN, because a real brand mark may well be colored.
     *
     * Shared by the runtime and by the generator's validation, so both judge by the same rule.
     */
    export function isSafeLogoSvg(markup: string, options?: {
        monochrome?: boolean;
    }): boolean;
    /**
     * Only `.svg` logos are supported: it is the asset kind that survives into dist (raster brand
     * assets are not published), so anything else would 404 in production.
     */
    export function isSupportedLogoUrl(url: string): boolean;
    /**
     * Brand shown by a header profile. The identity comes from the CONFIG (`profiles[x].brand`, which
     * the shell hands over as `regionProps.brand`) — never hardcoded in a generated subclass, so
     * regenerating the header cannot lose it.
     */
    export function resolveHeaderBrand(bootConfig?: MasterFrontendBootConfig, regionProps?: Record<string, unknown>, fallbackTitle?: string): AuraHeaderBrand;
    /** Optional actions the profile turned on (`profiles[x].props.actions`); unknown names are dropped. */
    export function resolveHeaderActions(regionProps?: Record<string, unknown>): AuraHeaderAction[];
    /**
     * Locales this header offers, from `props.locales`, intersected with what the app actually runs.
     *
     * The profile is a FILTER, never a source: a locale the app does not ship has no messages, so it
     * would switch the page into a language nothing is translated to. Absent/empty = every runtime
     * language, which is the behaviour every header had before the field existed.
     */
    export function resolveHeaderLocales(regionProps: Record<string, unknown> | undefined, runtimeLanguages: readonly string[]): string[];
    /**
     * The entries a header links: the selected hrefs, resolved against everything the runtime offers.
     *
     * Both lists are searched — the current module's `navigation` AND the cross-module `moduleLinks` —
     * because a selection is made in the studio over the whole project, and filtering only the current
     * module would make a legitimate cross-module link silently disappear.
     *
     * Order comes from the runtime lists, not from the selection: the header must not reorder the
     * project's own navigation. No selection = every entry of `navigation` (what headers did before the
     * field existed).
     */
    export function selectNavEntries<T extends {
        href: string;
    }>(navigation: readonly T[], moduleLinks: readonly T[], wanted: readonly string[]): T[];
    /**
     * Routes this header links, from `props.navLinks`: the hrefs picked for the band.
     *
     * Absent/empty means "no selection recorded", NOT "no links": the caller keeps every route the
     * module declares, which is what headers generated before this field did.
     */
    export function resolveHeaderNavHrefs(regionProps?: Record<string, unknown>): string[];
    /**
     * Band height for this profile. Defaults to the shared constant: the shell writes the ACTIVE
     * profile's height into `--aura-header-height`, so a profile that disagrees shifts the page on
     * every switch.
     */
    export function resolveBandHeightPx(regionProps?: Record<string, unknown>): number;
    /**
     * The mobile aside toggle is the ONLY way to reach the menu when the aside is not inline, so it
     * shows exactly when the mobile aside mode is a drawer/fullscreen.
     */
    export function shouldShowMobileAsideToggle(bootConfig?: MasterFrontendBootConfig): boolean;
    /**
     * CSS of the user menu — NOT scoped by the header tag, on purpose.
     *
     * Painted with the SAME nav palette as the band (it reads as an extension of the header, not as a
     * card of the page), and attached to `document.body`, not to the band: the band carries `backdrop-filter`,
     * which establishes a containing block for fixed descendants, so a panel inside it would be trapped
     * and then clipped by the header region's `overflow: hidden`. Living in the body is what lets it
     * open below the header at all. Injected once per page.
     */
    export function buildUserMenuCss(): string;
    /**
     * Band CSS for one header tag.
     *
     * Scoped by the ELEMENT'S OWN tag (`this.localName`), never by a hardcoded tag: every subclass —
     * including the per-project generated ones — gets the same band without colliding with a sibling
     * header profile that may still be in the DOM.
     *
     * Colors come from DS role tokens with a hex fallback, because `<style id="ds-tokens">` is injected
     * at runtime and may not be there on the first paint.
     */
    export function buildHeaderBandCss(tagName: string): string;
}
declare module "_102033_/l2/shared/languageRuntime" {
    type RuntimeLanguageDocument = {
        documentElement: {
            lang: string;
        };
        querySelectorAll: (selector: string) => ArrayLike<unknown> | Iterable<unknown>;
    };
    export function listRuntimeLanguages(languages: readonly string[] | undefined): string[];
    export function resolveRuntimeLanguage(languages: readonly string[], requestedLanguage: string): string | undefined;
    export function getRuntimeLanguage(languages: readonly string[], documentLanguage: string): string | undefined;
    export function getNextRuntimeLanguage(languages: readonly string[], documentLanguage: string): string | undefined;
    export function setRuntimeLanguage(requestedLanguage: string, languages: readonly string[], runtimeDocument?: RuntimeLanguageDocument): void;
}
declare module "_102033_/l2/shared/sessionUser" {
    export interface SessionUser {
        authenticated: boolean;
        name?: string;
        email?: string;
        /** Avatar URL from the IdP (OIDC `picture`); absent when it does not send one. */
        picture?: string;
    }
    export function parseSessionUser(payload: unknown): SessionUser;
    /** The logged user, fetched once per page. Never rejects. */
    export function getSessionUser(): Promise<SessionUser>;
    /** Test/diagnostic hook: drops the cached probe so the next call asks again. */
    export function resetSessionUserCache(): void;
    /**
     * Initials for the avatar fallback: two from a name ("Guilherme Pereira" -> GP), one from an email
     * ("guilherme@x.dev" -> G), and a neutral dot when there is neither.
     */
    export function userInitials(user: SessionUser): string;
    /** What the avatar announces to a screen reader and shows on hover. */
    export function userLabel(user: SessionUser, anonymousLabel?: string): string;
}
declare module "_102033_/l2/shared/designSystemRuntime" {
    type RuntimeDesignSystemStyle = {
        id: string;
        textContent: string | null;
        dataset: Record<string, string | undefined>;
    };
    type RuntimeDesignSystemDocument = {
        getElementById: (id: string) => RuntimeDesignSystemStyle | null;
        createElement: (tagName: string) => RuntimeDesignSystemStyle;
        head: {
            appendChild: (element: RuntimeDesignSystemStyle) => unknown;
        };
    };
    type DesignSystemCssLoader = (name: string, path: string) => Promise<string>;
    export function listRuntimeDesignSystems(designSystems: readonly string[] | undefined): string[];
    export function resolveRuntimeDesignSystem(designSystems: readonly string[], requestedDesignSystem: string): string | undefined;
    export function getRuntimeDesignSystem(designSystems: readonly string[], runtimeDocument?: RuntimeDesignSystemDocument): string | undefined;
    export function getNextRuntimeDesignSystem(designSystems: readonly string[], currentDesignSystem: string | undefined): string | undefined;
    export function setRuntimeDesignSystem(requestedDesignSystem: string, designSystems: readonly string[], projectId: string, runtimeDocument?: RuntimeDesignSystemDocument, loadCss?: DesignSystemCssLoader): Promise<void>;
}
declare module "_102033_/l2/shared/layout/aura-header-base" {
    import { LitElement } from 'lit';
    import type { MasterFrontendBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    import { type AuraHeaderAction, type AuraHeaderBrand } from "_102033_/l2/shared/layout/auraHeaderCore";
    import { type SessionUser } from "_102033_/l2/shared/sessionUser";
    export type { AuraHeaderAction, AuraHeaderBrand };
    export { AURA_HEADER_HEIGHT_PX } from "_102033_/l2/shared/layout/auraHeaderCore";
    /** Event a header fires for an action with no route (see `emitHeaderAction`). */
    export const AURA_HEADER_ACTION_EVENT = "collab-aura:header-action";
    export abstract class AuraHeaderBase extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            regionProps: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
            sessionUser: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        /** Profile props handed over by the shell (`brand`, `heightPx`, `props.actions`, `profileName`). */
        regionProps?: Record<string, unknown>;
        currentPath: string;
        /** Who is logged in (for the avatar); undefined until the one-per-page probe answers. */
        sessionUser?: SessionUser;
        /** Guards the probe (once per element) and the broken-photo fallback. */
        private sessionRequested;
        private pictureBroken;
        private userMenu?;
        /** Light DOM — the shell's region CSS and the :root DS tokens depend on it. Do NOT override. */
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        /** Fires the one-per-page session probe, at most once per element. */
        private ensureSessionUser;
        /**
         * The logged user's display name (name, else email, else empty) — for a welcome message. Reading it
         * starts the session probe, so a header that greets the user does not have to ask for the avatar.
         */
        protected get userName(): string;
        /** First name only, which is what a greeting usually wants. */
        protected get userFirstName(): string;
        protected get userEmail(): string;
        private ensureBandStyles;
        /** Title used when the profile carries no brand (the master header names itself). */
        protected get fallbackBrandTitle(): string;
        protected get brand(): AuraHeaderBrand;
        protected get actions(): AuraHeaderAction[];
        protected hasAction(action: AuraHeaderAction): boolean;
        protected get bandHeightPx(): number;
        protected get basePath(): string;
        protected showMobileAsideToggle(): boolean;
        /**
         * Message set for the document language, for the `collab_i18n_start/end` block a header carries
         * when it has fixed copy. Resolution is the runtime's own (exact locale, then primary subtag,
         * then the first declared one), so Ctrl+Alt+L switches the header copy along with the pages.
         */
        protected localized<T>(messages: Record<string, T>): T;
        /** SPA navigation inside the module, full load elsewhere. Use this, never a bare href. */
        protected navigateTo(href: string): void;
        protected readonly handleNavigate: (event: Event) => void;
        /**
         * Announces a header action that has no route behind it (`user`, `search`, anything app-specific).
         *
         * A header must never invent a route: an action with no destination dispatches this event and the
         * app decides what to do (open a menu, a dialog, nothing at all). The event bubbles, so a listener
         * on window/document sees it.
         */
        protected emitHeaderAction(action: string, detail?: Record<string, unknown>): void;
        protected renderAsideToggle(): any;
        /**
         * The mark: inlined markup when the brand carries one (it inherits `currentColor`, so it follows
         * the design system in light and dark), otherwise the `<img>` for a URL. `resolveHeaderBrand`
         * already refused anything unsafe — see `isSafeLogoSvg` — so only a sanitized single `<svg>` root
         * reaches unsafeHTML here. Same shape the 102025 avatar uses.
         */
        protected renderLogo(): any;
        protected renderBrand(): any;
        /**
         * The navigation entries this header links: the project's, filtered by the hrefs the profile
         * selected (`props.navLinks`).
         *
         * With NO selection recorded the whole list survives — a band only calls renderNavLinks() when it
         * was asked for links, and headers generated before the field existed have no list to read.
         */
        protected get navEntries(): ProjectNavigationEntry[];
        protected renderNavLinks(entries?: ProjectNavigationEntry[]): any;
        protected renderModuleLinks(): any;
        protected renderLanguageSwitcher(): any;
        protected renderDesignSystemSwitcher(): any;
        /**
         * The logged user as an avatar: the IdP photo when there is one, otherwise the initials, otherwise
         * a neutral silhouette. It is a BUTTON — clicking announces the `user` action through
         * `emitHeaderAction`, and the app decides what opens (menu, profile, sign-out).
         *
         * Available to a generated header as `this.renderUserAvatar()`; the profile turns it on by listing
         * the `user` action.
         */
        /** Neutral silhouette for a user with no photo and no initials (anonymous, or an IdP that tells us nothing). */
        private renderAvatarFallbackIcon;
        protected renderUserAvatar(): any;
        /** Copy of the user menu. A subclass with an i18n block overrides this. */
        protected get userMenuLabels(): {
            signOut: string;
            anonymous: string;
        };
        private handleAvatarClick;
        /**
         * Opens the identity panel under the avatar.
         *
         * Attached to `document.body`, NOT inside the band: the band carries `backdrop-filter`, which makes
         * it a containing block for fixed descendants, and the shell clips the header region with
         * `overflow: hidden` — a panel rendered in place would be cut off instead of shown.
         */
        private toggleUserMenu;
        private readonly closeUserMenu;
        private readonly handleUserMenuKeydown;
        private readonly handleOutsidePointer;
        /**
         * Ends the session. Uses the runtime hook when the page has it (window.collabRuntimeAuth), and
         * falls back to importing the auth helper on demand — the header never pays for it until a click.
         */
        protected signOut(): Promise<void>;
        /**
         * The optional actions the profile enabled, in a stable order. `search` has no shell runtime behind
         * it: a subclass that declares it renders it itself (see `hasAction`). `user` is the avatar, which
         * the base draws — a subclass may still place it by hand with `renderUserAvatar()`.
         */
        protected renderActions(): any;
        /** Extra CSS for this subclass, injected once per tag. Scope every rule with its own tag. */
        protected bandCss(): string;
        /** The band's content. Everything around it (band, height, styles) belongs to the base. */
        protected abstract renderBand(): unknown;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { AuraHeaderBase } from "_102033_/l2/shared/layout/aura-header-base";
    export class AuraHeader extends AuraHeaderBase {
        protected get fallbackBrandTitle(): string;
        private renderTrace;
        protected renderBand(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: MasterFrontendRouteDefinition[], pathname: string): MasterFrontendRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/contentPageGenome" {
    export interface ContentPageRenderer {
        tag: string;
        entrypoint: string;
    }
    export interface ContentPageGenomeChange {
        ok: boolean;
        nextTag: string;
        nextEntrypoint: string;
        /** Empty when the swap is structurally possible; otherwise why setPage will stay on the current variant. */
        reason: string;
    }
    export function describeContentPageGenomeChange(current: ContentPageRenderer | undefined, genome: number): ContentPageGenomeChange;
}
declare module "_102033_/l2/shared/shell" {
    import type { MasterFrontendBootConfig, MasterFrontendDeviceKind, MasterFrontendInteractionState, MasterFrontendRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
            contentTabs: {
                state: boolean;
            };
            activeContentTabId: {
                state: boolean;
            };
        };
        bootConfig?: MasterFrontendBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: MasterFrontendInteractionState;
        resolvedDevice: MasterFrontendDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: MasterFrontendRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        private dynamicRegionRenderers;
        private dynamicRegionProps;
        private activeAsideWidthPx?;
        private activeHeaderHeightPx?;
        contentTabs: Array<{
            id: string;
            title: string;
            element: HTMLElement;
            closable: boolean;
        }>;
        activeContentTabId: string;
        private structureUpgraded;
        private structureUpgradeFailed;
        private studioModeOn;
        private structureUpgradeAttempted;
        private structureRetriesLeft;
        private regionsMounted;
        private readonly isEmbedded;
        private contentVariantRenderer?;
        private sitesRetryTimer?;
        private sitesRetriesLeft;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly setHeaderRenderer;
        private readonly setAsideRenderer;
        private readonly setShellProfile;
        private setRegionProfile;
        /**
         * Registers the TypeScript definition models of the project chain (Monaco resolves the
         * cross-project imports through them).
         *
         * Deferred to the studio switch on purpose: an app user never opens an editor, so this cost
         * has no reason to be paid at login. Idempotent — repeated toggles do nothing.
         */
        private loadStudioDefinitions;
        /**
         * Puts the client's own services (messages + app) back on the structure's nav3 pair.
         *
         * Called whenever the shell leaves studio mode, by either door: the Ctrl+Alt+S toggle or a
         * header profile switch. No-op while the structure is not up.
         */
        private showRuntimeServices;
        private setRegionRenderer;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private initializeDynamicRegions;
        private getRegionProfile;
        private getRegionPropsFromProfile;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getAsideWidthPx;
        private getAsideDrawerWidthPx;
        private getRegionProps;
        private getActiveContentRenderer;
        private reportContentPageMiss;
        private applyContentPageGenome;
        private getAvailableUxLayouts;
        private listLanguages;
        private getLanguage;
        private setLanguage;
        private rotateLanguage;
        private listDS;
        private getDS;
        private setDS;
        private rotateDesignSystem;
        private rotateContentVariant;
        private readonly registerSitesControls;
        private getRegionProfileNames;
        private getRegionIndex;
        private readonly openContentTab;
        private readonly closeContentTab;
        private readonly activateContentTab;
        private readonly handleContentTabsResize;
        private updateContentTabsMsize;
        private syncContentTabPanels;
        private structureRetryPending;
        private maybeUpgradeStructure;
        private static readonly STRUCTURE_UPGRADE_MAX_ATTEMPTS;
        private attemptStructureUpgrade;
        private verifyStudioStructureRendered;
        private wantsStudioStructure;
        private get structureState();
        private rotateHeaderProfile;
        private setRegionByIndex;
        private getContentPageGenome;
        private setContentPage;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102033_/l2/shared/chartRuntime" {
    import * as echarts from 'echarts/core';
    export { echarts };
    export type { ECharts, EChartsCoreOption } from 'echarts/core';
    /**
     * Handlers for ECharts events, by event name (`click`, `legendselectchanged`, `datazoom`, …).
     *
     * ECharts events do NOT reach the DOM: they are emitted on the instance via `chart.on(...)`, so
     * `@chartclick=${…}` in a Lit template is a listener that never fires — and it COMPILES, because any
     * `@name` is a valid Lit binding. A generated page wrote exactly that, which is why the handlers must
     * come through the directive instead.
     */
    export type ChartEvents = Record<string, (params: never) => void>;
    /**
     * Bind an ECharts option to the element this directive sits on.
     *
     * @param option a full EChartsCoreOption. Every chart type and component this runtime registers above is
     *        available — no `echarts.use()` needed at the call site, which is the whole point of the module:
     *        an unregistered piece renders BLANK with no error.
     * @param events optional handlers, e.g. `{ click: (p) => this.selectCategory(p.name) }`. Rebound on every
     *        update, so a closure over fresh state is always the one that runs.
     *
     * The element must have a height (ECharts measures its container; a container of height 0 draws nothing).
     */
    export const chart: any;
}
declare module "_102033_/l2/shared/contentPageGenome.test" { }
declare module "_102033_/l2/shared/designSystemRuntime.test" { }
declare module "_102033_/l2/shared/interactionRuntime.test" { }
declare module "_102033_/l2/shared/languageRuntime.test" { }
declare module "_102033_/l2/shared/navigationVisibility.test" { }
declare module "_102033_/l2/shared/routeRuntime.test" { }
declare module "_102033_/l2/shared/sessionUser.test" { }
declare module "_102033_/l2/shared/shell.defs" {
    export const skill: {
        readonly componentId: "collab-aura-shell";
        readonly purpose: "Render the frontend shell, expose header/aside/content regions, and mount module-owned region renderers.";
        readonly responsibilities: readonly ["Read the boot config injected by the server runtime.", "Resolve the active device from the viewport and module preferences.", "Render the shell layout and region visibility state.", "Control the aside mode as inline, drawer, or fullscreen.", "Load the module renderers for header, aside, and content.", "Apply Aura fallback renderers when a module does not define header or aside.", "Mount the active renderer into each region host."];
        readonly regions: readonly ["header", "aside", "content"];
        readonly supportedDevices: readonly ["desktop", "mobile"];
        readonly supportedShellModes: readonly ["spa", "pwa"];
    };
}
declare module "_102033_/l2/shared/layout/aura-contents" {
    import { LitElement } from 'lit';
    export class AuraContents extends LitElement {
        createRenderRoot(): this;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/auraHeaderCore.test" { }
declare module "_102033_/l2/shared/molecules/cn" {
    export function cn(...inputs: (string | undefined | null | false)[]): string;
}
declare module "_102033_/l2/shared/molecules/tableSort" {
    /**
     * The value the cell wants to be sorted by.
     *
     * Sorting by TEXT is misleading in every column whose text does not sort like the data: masked
     * currency, `dd/mm/yyyy` dates, status labels. That is why a cell may declare its real value:
     *
     *     <TableCell sort-value="987">R$ 987,00</TableCell>
     *     <TableCell sort-value="2026-01-02">2 de janeiro</TableCell>
     *
     * `liveText` is for molecules with live slots, which must read from the projected nodes instead of
     * the source `textContent` — the source is empty once projected.
     */
    export function cellSortKey(cell: Element | null | undefined, liveText?: string): string;
    /** Number out of formatted text. `null` when there is no recognizable number. */
    export function parseFormattedNumber(text: string): number | null;
    /**
     * Compares two keys: numeric when both are numbers, otherwise text with natural collation.
     * Always returns the ASCENDING order — direction is up to the caller.
     */
    export function compareSortKeys(a: string, b: string): number;
}
declare module "_102033_/l2/studio/studioLiveUpdate.test" { }
declare module "_102033_/l2/studio/studioTextEdit.test" { }
