declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102033_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class MoleculeAuraElement extends StateLitElement {
        protected slotTags: string[];
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        private _mutationLock;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
    }
}
declare module "_102033_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        constructor();
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
        telemetryReceived?: number;
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102033_/l2/core/bff-client" {
    export * from "_102029_/l2/bffClient";
}
declare module "_102033_/l2/core/bff-client.test" { }
declare module "_102033_/l2/shared/contracts/bootstrap" {
    export * from "_102029_/l2/contracts/bootstrap";
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102033_/l2/shared/interactionRuntime" {
    export * from "_102029_/l2/interactionRuntime";
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102033_/l2/shared/layout/aura-shell-events" {
    export * from "_102029_/l2/shellEvents";
}
declare module "_102033_/l2/shared/layout/aura-aside" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraAside extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            currentPath: {
                state: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        currentPath: string;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private readonly handleLocationChange;
        private isItemActive;
        private handleNavigate;
        private navigateWithinModule;
        render(): any;
    }
}
declare module "_102033_/l2/shared/layout/aura-header" {
    import { LitElement } from 'lit';
    import type { AuraBootConfig } from "_102033_/l2/shared/contracts/bootstrap";
    export class AuraHeader extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        createRenderRoot(): this;
        private showMobileAsideToggle;
        render(): any;
    }
}
declare module "_102033_/l2/shared/routeRuntime" {
    import type { AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    export function matchAuraRoute(routes: AuraRouteDefinition[], pathname: string): AuraRouteDefinition | undefined;
    export function getCollabRouteChunkCache(): Set<string>;
    export function getCollabRouteChunkPromises(): Map<string, Promise<unknown>>;
    export function loadAuraRouteChunk(entrypoint: string, importer?: (specifier: string) => Promise<unknown>): Promise<void>;
}
declare module "_102033_/l2/shared/shell" {
    import type { AuraBootConfig, AuraDeviceKind, AuraInteractionState, AuraRouteDefinition } from "_102033_/l2/shared/contracts/bootstrap";
    import "_102033_/l2/shared/layout/aura-aside";
    import "_102033_/l2/shared/layout/aura-header";
    import { LitElement } from 'lit';
    export class CollabAuraShell extends LitElement {
        static properties: {
            bootConfig: {
                attribute: boolean;
            };
            statusMessage: {
                state: boolean;
            };
            routeStatusMessage: {
                state: boolean;
            };
            interactionState: {
                attribute: boolean;
            };
            resolvedDevice: {
                state: boolean;
            };
            isAsideOpen: {
                state: boolean;
            };
            activeRoute: {
                attribute: boolean;
            };
        };
        bootConfig?: AuraBootConfig;
        statusMessage: string;
        routeStatusMessage: string;
        interactionState: AuraInteractionState;
        resolvedDevice: AuraDeviceKind;
        isAsideOpen: boolean;
        activeRoute?: AuraRouteDefinition;
        private mobileMediaQuery?;
        private unsubscribeInteraction?;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private mountModuleRoot;
        private readonly handleViewportChange;
        private readonly handleToggleAside;
        private readonly handleOpenAside;
        private readonly handleCloseAside;
        private readonly handleKeyDown;
        private readonly handlePopState;
        private syncResolvedDevice;
        private resolveDevice;
        private getDefaultAsideOpen;
        private getAsideModeForDevice;
        private getResolvedAsideMode;
        private getRenderer;
        private importRegion;
        private loadActiveRoute;
        private getBaseRegionVisibility;
        private getActualAsideOpen;
        private getRegionVisibility;
        private mountRegion;
        updated(): void;
        private renderBlockingError;
        render(): any;
    }
}
declare module "_102033_/l2/shared/bootstrap" {
    import "_102033_/l2/shared/shell";
}
declare module "_102033_/l2/core/bootstrap" {
    export interface CollabNavigationItem {
        label: string;
        href: string;
    }
    export interface CollabPageDefinition {
        path: string;
        title: string;
        tagName: string;
        loader: () => Promise<unknown>;
    }
    export interface CollabAppDefinition {
        projectId: string;
        appId: string;
        title: string;
        shellMode: 'spa' | 'pwa';
        pages: CollabPageDefinition[];
        navigation: CollabNavigationItem[];
    }
    export function bootstrapCollabApp(_app: CollabAppDefinition): Promise<void>;
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102033_/l2/molecules/groupenterdate/ml-compact-calendar" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlCompactCalendarMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private viewMonth;
        private viewYear;
        private hasFocus;
        private static idCounter;
        private instanceId;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private handleDayClick;
        private handleClear;
        private handlePrevMonth;
        private handleNextMonth;
        private handleFocusIn;
        private handleFocusOut;
        render(): TemplateResult;
        private renderViewMode;
        private renderLabel;
        private renderHeader;
        private renderCalendar;
        private renderDayCell;
        private renderFeedback;
        private setViewToToday;
        private parseIsoDate;
        private formatIsoDate;
        private formatDisplayValue;
        private getMonthTitle;
        private getWeekdayNames;
        private getCalendarDays;
        private isDateSelectable;
        private isSameDay;
        private getWeekNumber;
        private ensureViewWithinBounds;
        private canNavigatePrev;
        private canNavigateNext;
        private navigateToMonth;
        private getContainerClasses;
        private getNavButtonClasses;
        private getDayClasses;
    }
}
declare module "_102033_/l2/molecules/groupenterdate/ml-date-picker" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlDatePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private viewMonth;
        private viewYear;
        private fieldId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleToggleOpen;
        private handleFocus;
        private handleBlur;
        private handleOutsideClick;
        private handlePrevMonth;
        private handleNextMonth;
        private handleSelectDay;
        private handleClear;
        private syncViewToValue;
        private ensureViewWithinRange;
        private parseIsoDate;
        private toIsoDate;
        private toDateKey;
        private formatDisplay;
        private formatTriggerValue;
        private getWeekdayLabels;
        private getDaysInMonth;
        private addMonths;
        private isDateDisabled;
        private canNavigatePrev;
        private canNavigateNext;
        private getISOWeekNumber;
        private getContainerClasses;
        private getTriggerClasses;
        private getDayClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderCalendar;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupenterdateinterval/ml-date-interval-drag" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class DateIntervalDragMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDate: string | null;
        endDate: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        minRangeDays: number;
        maxRangeDays: number;
        firstDayOfWeek: number;
        allowSameDay: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private selectingEnd;
        private hoverDate;
        private isDragging;
        private hoverValid;
        private currentMonth;
        private hasFocus;
        private labelId;
        private errorId;
        private helperId;
        connectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private handleDayPointerDown;
        private handleDayPointerEnter;
        private handleDayPointerUp;
        private handleWindowPointerUp;
        private finishDrag;
        private handlePrevMonth;
        private handleNextMonth;
        private handleFocusIn;
        private handleFocusOut;
        private getLocale;
        private syncCurrentMonth;
        private parseIsoDate;
        private formatIsoDate;
        private formatDisplayDate;
        private diffInDays;
        private compareIso;
        private getOrderedRange;
        private isWithinMinMax;
        private isDateSelectableForStart;
        private isDateSelectableForEnd;
        private getWeekdayLabels;
        private getCalendarDays;
        private getActiveRange;
        private isInRange;
        private getMonthLabel;
        private canNavigatePrev;
        private canNavigateNext;
        private getRangeSummary;
        private getDayClasses;
        render(): any;
        private renderOverallLabel;
        private renderHeader;
        private renderCalendar;
        private renderFeedback;
        private renderLoading;
    }
}
declare module "_102033_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class DateRangeDualCalendarMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        private onDocumentClick;
        private isFocused;
        slotTags: string[];
        startDate: string | null;
        endDate: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        minRangeDays: number;
        maxRangeDays: number;
        firstDayOfWeek: number;
        allowSameDay: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private selectingEnd;
        private hoverDate;
        private currentMonthLeft;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private handleFocusIn;
        private handleFocusOut;
        private handleOpenCalendar;
        private handleOutsideClick;
        private closeCalendar;
        private handleDayHover;
        private handleDayClick;
        private handlePrevMonth;
        private handleNextMonth;
        private handleClear;
        private emitStartChange;
        private emitEndChange;
        private emitChange;
        private getToday;
        private parseISO;
        private formatISO;
        private formatDisplay;
        private getLocale;
        private compareDates;
        private toUtcDay;
        private addDays;
        private addMonths;
        private daysBetween;
        private adjustMonthToBounds;
        private canNavigateToMonth;
        private canSelectRange;
        private isDateDisabled;
        private isInRange;
        private getWeekdayLabels;
        private renderLabel;
        private renderStartLabel;
        private renderEndLabel;
        private renderHelperOrError;
        private renderCalendarIcon;
        private renderMonth;
        private renderCalendarPanel;
        private renderViewMode;
        private renderEditMode;
        render(): TemplateResult;
    }
}
declare module "_102033_/l2/molecules/groupenterdatetime/ml-datetime-picker" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlDatetimePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minuteStep: number;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private isFocused;
        private displayValue;
        private selectedDate;
        private selectedHour;
        private selectedMinute;
        private currentMonth;
        private labelId;
        private helperId;
        private errorId;
        private documentClickBound;
        createRenderRoot(): this;
        handleIcaStateChange(key: string, value: any): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleFocus;
        private handleBlur;
        private handleDaySelect;
        private handleHourSelect;
        private handleMinuteSelect;
        private handleConfirm;
        private handleClear;
        private handlePrevMonth;
        private handleNextMonth;
        private openPicker;
        private closePicker;
        private addDocumentListener;
        private removeDocumentListener;
        private handleDocumentClick;
        private prepareOpenState;
        private updateFromValue;
        private updateDisplay;
        private formatDisplay;
        private parseIso;
        private pad;
        private getMinuteOptions;
        private parseMinMax;
        private getMinDate;
        private getMaxDate;
        private isDateDisabled;
        private isTimeDisabled;
        private getFirstValidTime;
        private getFirstValidMinute;
        private getTriggerClasses;
        private getLabelClasses;
        private getPanelClasses;
        private getDayButtonClasses;
        private getTimeButtonClasses;
        private getAriaDescribedBy;
        private getWeekdays;
        private renderLabel;
        private renderHiddenInput;
        private renderHelperOrError;
        private renderTrigger;
        private renderCalendar;
        private renderTime;
        private renderPanel;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupenterdatetime/ml-enter-datetime-masked-input" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class EnterDatetimeMaskedInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minuteStep: number;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private isFocused;
        private inputValue;
        private static idCounter;
        private inputId;
        private labelId;
        private helperId;
        private errorId;
        firstUpdated(): void;
        updated(changedProps: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        render(): any;
        private renderViewMode;
        private renderLabel;
        private renderFeedback;
        private renderLoading;
        private renderIcon;
        private applyMask;
        private commitInputValue;
        private parseInputToIso;
        private updateInputValueFromValue;
        private formatValueForDisplay;
        private getIs12HourLocale;
        private getFormatConfig;
        private getSegmentsFromDigits;
        private joinDateParts;
        private joinTimeParts;
        private isValidDateParts;
        private pad;
        private getInputClasses;
    }
}
declare module "_102033_/l2/molecules/groupenterdatetimeinterval/ml-datetime-interval-timeline" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class DatetimeIntervalTimelineMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDatetime: string | null;
        endDatetime: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        minuteStep: number;
        allowSameInstant: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        activeField: 'start' | 'end' | null;
        private uid;
        private onStartFocus;
        private onEndFocus;
        private onFieldBlur;
        private onStartInput;
        private onEndInput;
        private toInputValue;
        private fromInputValue;
        private toDate;
        private isWithinMinMax;
        private isValidRange;
        private formatDateTime;
        private formatRange;
        private getContainerClasses;
        private getInputClasses;
        private getMarkerClasses;
        private getTimelineProgressClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private renderTimeline;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class EnterDatetimeIntervalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDatetime: string | null;
        endDatetime: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        minuteStep: number;
        allowSameInstant: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private startDraft;
        private endDraft;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        private dispatchFocus;
        private dispatchBlur;
        private dispatchStartChange;
        private dispatchEndChange;
        private dispatchChange;
        private handleOpenField;
        private setActiveField;
        private handleStartDraftInput;
        private handleEndDraftInput;
        private handleConfirmStart;
        private handleConfirmEnd;
        private handleClearStart;
        private handleClearEnd;
        private isStartDraftValid;
        private isEndDraftValid;
        private isWithinRange;
        private getMinEndIso;
        private getMaxEndIso;
        private getDisplayRange;
        private formatDateTime;
        private formatDate;
        private formatTime;
        private getDateKey;
        private parseIso;
        private parseIsoToTime;
        private toInputValueFromIso;
        private formatInputValue;
        private toIsoFromInput;
        private addMinutes;
        private toIsoString;
        private maxIso;
        private minIso;
        private pad;
        private renderLabel;
        private renderPreview;
        private renderInputBlock;
        private renderPickerPanel;
        private renderFeedback;
        private renderLoading;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupentermoney/ml-enter-money-display" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class EnterMoneyDisplayMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        currency: string;
        locale: string;
        decimals: number;
        min: number | null;
        max: number | null;
        showSymbol: boolean;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        private static idCounter;
        private labelId;
        private errorId;
        private inputId;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleFocus;
        private handleInput;
        private handleBlur;
        private getEffectiveLocale;
        private clampValue;
        private parseLocaleNumber;
        private getSeparators;
        private formatToRaw;
        private formatToDisplay;
        private getCurrencySymbolInfo;
        private getInputClasses;
        private getSymbolClasses;
        private getContainerClasses;
        private getAriaLabel;
        private renderLabel;
        private renderHelperOrError;
        private renderLoading;
        private renderInputRow;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupentermoney/ml-enter-money-minimal" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class EnterMoneyMinimalMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        currency: string;
        locale: string;
        decimals: number;
        min: number | null;
        max: number | null;
        showSymbol: boolean;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        private uid;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleFocus;
        private handleInput;
        private handleBlur;
        private getSeparators;
        private parseLocaleNumber;
        private formatToRaw;
        private clampValue;
        private getCurrencySymbol;
        private getAriaLabel;
        private stripHtml;
        private getContainerClasses;
        private getInputClasses;
        private getSymbolClasses;
        render(): TemplateResult;
        private renderViewMode;
        private renderEditMode;
        private renderLabel;
        private renderFeedback;
    }
}
declare module "_102033_/l2/molecules/groupenternumber/ml-number-input" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlNumberInputMolecule extends MoleculeAuraElement {
        private msg;
        private componentId;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private emitInput;
        private emitChange;
        private emitBlur;
        private emitFocus;
        private getSeparators;
        private parseRawValue;
        private roundToDecimals;
        private formatToDisplay;
        private getInputClasses;
        private getContainerClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderPrefix;
        private renderSuffix;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupenternumber/ml-number-stepper" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class NumberStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        private inputId;
        private labelId;
        private helperId;
        private errorId;
        connectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private increment;
        private decrement;
        private emitInput;
        private emitChange;
        private formatToDisplay;
        private parseRawToNumber;
        private normalizeValue;
        private roundToDecimals;
        private getNumberSeparators;
        private getInputClasses;
        private getButtonClasses;
        private getContainerClasses;
        private getRowClasses;
        render(): any;
        private renderViewMode;
        private renderLabel;
        private renderHelperOrError;
        private renderPrefix;
        private renderSuffix;
    }
}
declare module "_102033_/l2/molecules/groupentertext/ml-floating-text-input" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlFloatingTextInputMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private isFocused;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private shouldUseMask;
        private getMaskedDisplayValue;
        private applyMaskToRaw;
        private extractRawFromInput;
        private isMaskToken;
        private isCharValidForToken;
        private getLabelText;
        private getInputPlaceholder;
        private getViewValue;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderLabel;
        private getContainerClasses;
        private getInputClasses;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupentertext/ml-multiline-text" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MultilineTextMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private labelId;
        private inputId;
        private helperId;
        private errorId;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private isMaskActive;
        private shouldRenderTextarea;
        private normalizeValue;
        private syncRawDisplay;
        private applyMaxLength;
        private getRawFromInput;
        private matchToken;
        private applyMaskToRaw;
        private getDisplayValue;
        private getWrapperClasses;
        private getInputClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderLoading;
        private renderHelperOrError;
        private renderCounter;
        private handleInput;
        private handleBlur;
        private handleFocus;
        render(): any;
        private renderViewMode;
        private renderEditMode;
    }
}
declare module "_102033_/l2/molecules/groupentertime/ml-clock-time-picker" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class ClockTimePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private stage;
        private selectedHour;
        private selectedMinute;
        private selectedSecond;
        private amPm;
        handleIcaStateChange(key: string, value: any): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private onToggleOpen;
        private onOutsideClick;
        private onInputFocus;
        private onInputBlur;
        private onSelectHour;
        private onSelectMinute;
        private onSelectSecond;
        private onConfirm;
        private onClear;
        private onToggleAmPm;
        private canInteract;
        private syncSelectionFromValue;
        private parseTime;
        private formatTime;
        private buildValueString;
        private isSelectionComplete;
        private convertTo24Hour;
        private convertTo12Hour;
        private attachOutsideClick;
        private detachOutsideClick;
        private isHourDisabled;
        private isMinuteDisabled;
        private isSecondDisabled;
        private getHourOptions;
        private getMinuteOptions;
        private getSecondOptions;
        private getInputClasses;
        private getOptionClasses;
        private getPanelClasses;
        private getLabelClasses;
        private getStepLabel;
        private renderLabel;
        private renderHelperOrError;
        private renderClockOptions;
        private renderAmPm;
        private getLabelId;
        private getHelperId;
        private getErrorId;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupentertime/ml-time-scroll-picker" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlTimeScrollPickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private selectedHour;
        private selectedMinute;
        private selectedSecond;
        private selectedPeriod;
        private componentId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string): void;
        private handleToggleOpen;
        private handleOutsideClick;
        private handleFocus;
        private handleBlur;
        private handleConfirm;
        private handleClear;
        private handleHourSelect;
        private handleMinuteSelect;
        private handleSecondSelect;
        private handlePeriodSelect;
        private handleKeyDown;
        private syncFromValue;
        private parseTimeValue;
        private formatValueFromSelection;
        private formatDisplay;
        private to12Hour;
        private to24Hour;
        private getMinSeconds;
        private getMaxSeconds;
        private isTimeAllowed;
        private isSelectedTimeValid;
        private getMinutesList;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private renderInput;
        private renderClockIcon;
        private renderPicker;
        private renderHourColumn;
        private renderMinuteColumn;
        private renderSecondColumn;
        private renderPeriodColumn;
        private isPeriodAllowed;
        private getInputClasses;
        private getIconButtonClasses;
        private getItemClasses;
        private getActionButtonClasses;
        private getPrimaryButtonClasses;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupentertimeinterval/ml-time-interval-selector" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlTimeIntervalSelectorMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private tempHour;
        private tempMinute;
        private tempSecond;
        private tempAmPm;
        handleIcaStateChange(key: string, value: any): void;
        private handleOpen;
        private handleClose;
        private handleConfirm;
        private handleClear;
        private handleHourChange;
        private handleMinuteChange;
        private handleSecondChange;
        private handleAmPmChange;
        private parseTime;
        private formatToStorage;
        private formatForDisplay;
        private initTempFromTime;
        private toHour12;
        private toHour24;
        private getTimeFromTemp;
        private toSeconds;
        private isTimeWithinLimits;
        private isOvernight;
        private calcDurationMinutes;
        private isEndTimeValid;
        private isTimeValidForField;
        private getRangeDisplay;
        private getInputClasses;
        private getPickerClasses;
        private getSelectClasses;
        render(): TemplateResult;
        private renderViewMode;
        private renderEditMode;
        private renderPicker;
        private renderHourOptions;
        private renderMinuteOptions;
        private renderSecondOptions;
        private renderFeedback;
        private renderClockIcon;
    }
}
declare module "_102033_/l2/molecules/groupentertimeinterval/ml-time-interval-slider" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class TimeIntervalSliderMolecule extends MoleculeAuraElement {
        private msg;
        private baseId;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private draftStartSeconds;
        private draftEndSeconds;
        handleIcaStateChange(key: string, value: any): void;
        updated(changed: Map<string, unknown>): void;
        private syncDraftFromValues;
        private handleFocus;
        private handleBlur;
        private handleStartInput;
        private handleEndInput;
        private handleStartChange;
        private handleEndChange;
        private canInteract;
        private toSeconds;
        private secondsToTime;
        private formatDisplay;
        private getMinMaxSeconds;
        private getStepSeconds;
        private getCurrentStartSeconds;
        private getCurrentEndSeconds;
        private isOvernight;
        private durationMinutes;
        private isValidInterval;
        private isValidStart;
        private isValidEnd;
        private getTrackSegmentStyles;
        private getContainerClasses;
        private getInputBoxClasses;
        private getRangeClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupexpandcontent/ml-accordion" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlAccordionMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private findNextEnabledHeader;
        private getSectionContent;
        private getHeaderClasses;
        private getContentClasses;
        private getChevronClasses;
        render(): any;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private renderSection;
    }
}
declare module "_102033_/l2/molecules/groupnavigatesection/ml-tabs" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlTabsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private uid;
        private handleTabClick;
        private handleKeyDown;
        private parseTabs;
        private getActiveValue;
        private toSafeId;
        private getTabClasses;
        private getTabListClasses;
        private getPanelClasses;
        private renderLabel;
        private renderLoading;
        private renderError;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupnavigatesteps/ml-vertical-stepper" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlVerticalStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number;
        linear: boolean;
        disabled: boolean;
        loading: boolean;
        private handleStepClick;
        private handleKeydown;
        private parseSteps;
        private getLabelText;
        private canNavigateTo;
        private selectStep;
        private findNextNavigableIndex;
        private focusStep;
        private getStepButtonClasses;
        private getIndicatorClasses;
        private getTitleClasses;
        private getDescriptionClasses;
        private getConnectorClasses;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupnotifyuser/ml-notify-banner" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class NotifyBannerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: 'info' | 'success' | 'warning' | 'error' | string;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: string;
        private dismissTimer;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, unknown>): void;
        private startAutoDismiss;
        private clearAutoDismiss;
        private handleDismiss;
        private handleActionClick;
        private getRole;
        private getAriaLive;
        private getPositionClasses;
        private getContainerClasses;
        private getTypeClasses;
        private getIconClasses;
        private renderDefaultIcon;
        private renderIcon;
        private renderTitle;
        private renderMessage;
        private renderAction;
        private renderDismissButton;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupplaymedia/ml-video-player" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class VideoPlayerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        poster: string;
        autoplay: boolean;
        loop: boolean;
        muted: boolean;
        preload: string;
        disabled: boolean;
        loading: boolean;
        private isPlaying;
        private currentTime;
        private duration;
        private volume;
        private isMuted;
        private hasEnded;
        private captionsEnabled;
        handleIcaStateChange(key: string, value: any): void;
        playMedia(): void;
        pauseMedia(): void;
        togglePlay(): void;
        seekTo(seconds: number): void;
        setVolume(value: number): void;
        toggleMute(): void;
        enterFullscreen(): void;
        toggleCaptions(): void;
        private handlePlay;
        private handlePause;
        private handleEnded;
        private handleTimeUpdate;
        private handleLoadedMetadata;
        private handleVolumeChange;
        private handleMediaError;
        private handleSeekInput;
        private handleVolumeInput;
        private handleKeyDown;
        render(): any;
        private renderLabel;
        private renderControls;
        private readSources;
        private readTracks;
        private hasSources;
        private getMediaElement;
        private formatTime;
        private emitError;
        private isBlocked;
        private getButtonClasses;
        private getRangeClasses;
    }
}
declare module "_102033_/l2/molecules/groupscancode/ml-scan-code" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlScanCodeMolecule extends MoleculeAuraElement {
        private msg;
        private stream;
        private autoTimer;
        private errorId;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        facing: 'environment' | 'user';
        autoCapture: boolean;
        captureInterval: number;
        disabled: boolean;
        loading: boolean;
        private isOpen;
        private isCapturing;
        private cameraReady;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, unknown>): void;
        private openCamera;
        private closeCamera;
        private startCamera;
        private stopCamera;
        private setupAutoCapture;
        private captureFrame;
        private getVideoElement;
        private handleTriggerClick;
        private handleCaptureClick;
        private handleScanAgain;
        private handleKeydown;
        private getRootClasses;
        private getActionButtonClasses;
        private getCaptureButtonClasses;
        private getViewfinderClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderTrigger;
        private renderResult;
        private renderViewfinder;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlFileUploadDropzoneMolecule extends MoleculeAuraElement {
        private msg;
        private inputId;
        private labelId;
        private errorId;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private handleZoneClick;
        private handleZoneKeydown;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleInputChange;
        private handleRemoveFile;
        private processFiles;
        private validateFiles;
        private getAvailableSlots;
        private isFileTypeAccepted;
        private formatFileSize;
        private getInputElement;
        render(): any;
        private renderTriggerContent;
        private renderFileList;
    }
}
declare module "_102033_/l2/molecules/groupselectfileforupload/ml-file-upload-preview" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlFileUploadPreviewMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private previewUrls;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleTriggerKeydown;
        private handleInputChange;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleRemoveFile;
        private processFiles;
        private isAcceptedType;
        private syncPreviewUrls;
        private revokeAllPreviews;
        private getFileKey;
        private getPreviewUrl;
        private getContainerClasses;
        private getDropZoneClasses;
        private getFileItemClasses;
        private getRemoveButtonClasses;
        private formatSize;
        private renderLabel;
        private renderHelperOrError;
        private renderTriggerContent;
        private renderLoadingIndicator;
        private renderFileList;
        private getFileInput;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupselectmany/ml-dual-list-select" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlDualListSelectMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private hasFocus;
        private handleAddItem;
        private handleRemoveItem;
        private handleAddAll;
        private handleRemoveAll;
        private handleSearchInput;
        private handleFocusIn;
        private handleFocusOut;
        private isInteractionBlocked;
        private getMinSelection;
        private getMaxSelection;
        private canAddMore;
        private updateValue;
        private getSelectedValues;
        private mapItemElement;
        private getParsedItems;
        private getFilteredItems;
        private buildGroups;
        private getContainerClasses;
        private getPanelClasses;
        private getItemRowClasses;
        private getActionButtonClasses;
        private renderLabel;
        private renderEmpty;
        private renderSearch;
        private renderFeedback;
        private renderList;
        private renderActionColumn;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupselectmany/ml-multi-checkbox-list" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlMultiCheckboxListMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        private handleFocusIn;
        private handleFocusOut;
        private handleSearchInput;
        private handleToggleItem;
        private parseItem;
        private parseItems;
        private filterItems;
        private getSelectedValues;
        private getSelectedLabels;
        private getContainerClasses;
        private getItemClasses;
        private renderLabel;
        private renderFeedback;
        private renderCheckIcon;
        private renderItems;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupselectone/ml-dial-select" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class DialSelectMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private activeIndex;
        private uid;
        private lastVisibleItems;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(): void;
        private handleDocumentClick;
        private handleTriggerClick;
        private handleKeyDown;
        private handleSearchInput;
        private selectItem;
        private handleFocus;
        private handleBlur;
        private getPlainText;
        private getNextEnabledIndex;
        private getTriggerClasses;
        private getItemClasses;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupviewcard/ml-view-card-horizontal.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-view-card-horizontal\n# Objective\nProvide a compact horizontal card for list items with left media content and right text content, supporting interactive and stateful behaviors.\n# Responsibilities\n- Render a card with a horizontal layout.\n- Display the CardContent slot on the left side of the card.\n- Display the CardHeader slot to the right of CardContent.\n- Display the CardFooter slot below the CardHeader within the right section when provided.\n- Display the CardAction slot within the right section when provided.\n- Support a clickable state that makes the card interactive.\n- Emit a cardClick event when activated by pointer interaction while clickable.\n- Emit a cardClick event when activated by Enter or Space while focused and clickable.\n- Support a selected state that visually highlights the card.\n- Support a disabled state that makes the card non-interactive and visually dimmed.\n- Support a loading state that replaces content with a placeholder representation of the layout.\n- Pass the isEditing attribute to child components within the card.\n- Apply button semantics when clickable, including focusability.\n- Expose aria-selected when selected.\n- Expose aria-disabled when disabled.\n# Constraints\n- When disabled, the card must not emit cardClick events.\n- When loading, normal content must not be displayed.\n- The card must remain compact and suitable for use in list layouts.\n- Visual placement must keep left media content constrained to a small width and text content on the right.\n# Notes\n- CardHeader may include CardTitle and CardDescription content.";
}
declare module "_102033_/l2/molecules/groupviewcard/ml-view-card-horizontal" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class ViewCardHorizontalMolecule extends MoleculeAuraElement {
        slotTags: string[];
        clickable: boolean;
        selected: boolean;
        disabled: boolean;
        loading: boolean;
        isEditing: boolean;
        updated(): void;
        private handleCardClick;
        private handleKeyDown;
        private applyEditingAttribute;
        private getContainerClasses;
        private renderHeader;
        private renderContentLeft;
        private renderFooter;
        private renderAction;
        private renderSkeleton;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupviewchart/ml-bar-chart" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlBarChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private tooltip;
        private handlePointMouseEnter;
        private handlePointMouseLeave;
        private handlePointClick;
        private handlePointKeyDown;
        private parsePoint;
        private readSeries;
        private readStandalonePoints;
        private getCategories;
        private getMaxValue;
        private renderLabel;
        private renderLoading;
        private renderEmpty;
        private renderTooltip;
        private renderLegend;
        private renderDataTable;
        private getAriaLabel;
        private formatNumber;
        private getBarWidth;
        private getBarClasses;
        private getCategoryLabelClasses;
        private renderChart;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupviewchart/ml-pie-chart" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class PieChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private hoverState;
        private palette;
        private parsePoint;
        private readSeries;
        private readStandalonePoints;
        private getSegments;
        private handlePointClick;
        private handlePointKeydown;
        private handlePointEnter;
        private handlePointLeave;
        private polarToCartesian;
        private describeArc;
        private renderLabel;
        private renderLoading;
        private renderEmpty;
        private renderLegend;
        private renderAccessibleTable;
        private renderTooltip;
        private renderChart;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class HierarchyOrgchartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        expandAll: boolean;
        disabled: boolean;
        loading: boolean;
        private expandedState;
        private focusedPath;
        firstUpdated(): void;
        updated(): void;
        private buildTree;
        private createNodeModel;
        private getRootNodeElements;
        private getChildNodeElements;
        private getNodeLabelHtml;
        private getExpandedForPath;
        private ensureFocusPath;
        private focusButton;
        private handleNodeClick;
        private handleToggleClick;
        private applyToggle;
        private handleKeyDown;
        render(): any;
        private renderLoading;
        private renderEmpty;
        private renderNode;
        private renderChevron;
        private getNodeButtonClasses;
        private getToggleButtonClasses;
    }
}
declare module "_102033_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class HierarchyTreeDiagramMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        expandAll: boolean;
        disabled: boolean;
        loading: boolean;
        private focusedId;
        private expandedMap;
        private nodeIndex;
        private visibleNodeIds;
        createRenderRoot(): this;
        updated(changedProps: Map<string, unknown>): void;
        private buildTree;
        private isNestedNode;
        private parseNode;
        private getNodeLabelHtml;
        private isExpanded;
        private refreshVisibleNodes;
        private handleNodeClick;
        private handleToggle;
        private handleNodeKeydown;
        private moveFocus;
        private focusCurrentNode;
        private getToggleClasses;
        private getLabelClasses;
        private getCircleClasses;
        private renderToggleIcon;
        private renderConnector;
        private renderNode;
        private renderLabel;
        private renderEmpty;
        private renderLoading;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class HierarchyTreeMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        expandAll: boolean;
        disabled: boolean;
        loading: boolean;
        private expandedState;
        updated(changedProps: Map<string, unknown>): void;
        private isNodeElement;
        private getRootNodes;
        private getChildNodes;
        private getNodeLabelHtml;
        private getNodeValue;
        private isNodeDisabled;
        private getNodeExpanded;
        private setNodeExpanded;
        private expandAllNodes;
        private collapseSiblings;
        private handleToggle;
        private handleNodeClick;
        private handleNodeKeyDown;
        private focusAdjacentNode;
        private renderLabel;
        private renderLoading;
        private renderEmpty;
        private getToggleButtonClasses;
        private getContentButtonClasses;
        private renderChevron;
        private renderNode;
        private renderNodeList;
        render(): any;
    }
}
declare module "_102033_/l2/molecules/groupviewmetric/ml-metric-big-number" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlMetricBigNumberMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        render(): TemplateResult;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderLoadingSkeleton;
        private getContainerClasses;
        private getTrendClasses;
        private getTrendDirection;
        private getAriaLabel;
    }
}
declare module "_102033_/l2/molecules/groupviewmetric/ml-metric-gauge" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MetricGaugeMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        render(): any;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderGauge;
        private renderLoading;
        private getAriaLabel;
        private getTrendClasses;
    }
}
declare module "_102033_/l2/shared/interactionRuntime.test" { }
declare module "_102033_/l2/shared/routeRuntime.test" { }
declare module "_102033_/l2/shared/shell.defs" {
    export const skill: {
        readonly componentId: "collab-aura-shell";
        readonly purpose: "Render the frontend shell, expose header/aside/content regions, and mount module-owned region renderers.";
        readonly responsibilities: readonly ["Read the boot config injected by the server runtime.", "Resolve the active device from the viewport and module preferences.", "Render the shell layout and region visibility state.", "Control the aside mode as inline, drawer, or fullscreen.", "Load the module renderers for header, aside, and content.", "Apply Aura fallback renderers when a module does not define header or aside.", "Mount the active renderer into each region host."];
        readonly regions: readonly ["header", "aside", "content"];
        readonly supportedDevices: readonly ["desktop", "mobile"];
        readonly supportedShellModes: readonly ["spa", "pwa"];
    };
}
declare module "_102033_/l2/shared/layout/aura-contents" {
    import { LitElement } from 'lit';
    export class AuraContents extends LitElement {
        createRenderRoot(): this;
        render(): any;
    }
}
