export async function bootstrapCollabApp(_app) {
    await import('../shared/bootstrap.js');
}
//# sourceMappingURL=bootstrap.js.map