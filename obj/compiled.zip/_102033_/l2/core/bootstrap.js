export async function bootstrapCollabApp(_app) {
    await import('/_102033_/l2/shared/bootstrap.js');
}
