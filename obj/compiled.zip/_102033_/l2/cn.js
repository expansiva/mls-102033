/// <mls fileReference="_102033_/l2/cn.ts" enhancement="_blank"/>
export function cn(...inputs) {
    return inputs.filter(Boolean).join(' ');
}
//# sourceMappingURL=cn.js.map