var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var EnterMoneyDisplayMolecule_1;
/// <mls fileReference="_102033_/l2/molecules/groupentermoney/ml-enter-money-display.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// ENTER MONEY DISPLAY MOLECULE
// =============================================================================
// Skill Group: groupEnterMoney
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let EnterMoneyDisplayMolecule = EnterMoneyDisplayMolecule_1 = class EnterMoneyDisplayMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.currency = 'USD';
        this.locale = '';
        this.decimals = 2;
        this.min = null;
        this.max = null;
        this.showSymbol = true;
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.rawValue = '';
        this.labelId = `em-label-${EnterMoneyDisplayMolecule_1.idCounter++}`;
        this.errorId = `em-error-${EnterMoneyDisplayMolecule_1.idCounter++}`;
        this.inputId = `em-input-${EnterMoneyDisplayMolecule_1.idCounter++}`;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.rawValue = this.formatToRaw(this.value);
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const localeAttr = this.getAttribute('locale');
        const decimalsAttr = this.getAttribute('decimals');
        if (valueAttr === `{{${key}}}` || localeAttr === `{{${key}}}` || decimalsAttr === `{{${key}}}`) {
            this.rawValue = this.formatToRaw(this.value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleFocus(e) {
        if (this.disabled || this.loading)
            return;
        const input = e.target;
        input.select();
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleInput(e) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        this.rawValue = input.value;
        this.value = this.parseLocaleNumber(this.rawValue);
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleBlur() {
        if (this.disabled || this.loading) {
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            return;
        }
        if (this.readonly) {
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            return;
        }
        const trimmed = this.rawValue.trim();
        if (!trimmed) {
            this.value = null;
            this.rawValue = '';
        }
        else {
            let parsed = this.parseLocaleNumber(trimmed);
            if (parsed === null) {
                this.value = null;
                this.rawValue = '';
            }
            else {
                parsed = this.clampValue(parsed);
                this.value = parsed;
                this.rawValue = this.formatToRaw(parsed);
            }
        }
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getEffectiveLocale() {
        return this.locale ? this.locale : undefined;
    }
    clampValue(value) {
        let result = value;
        if (this.min !== null && result < this.min)
            result = this.min;
        if (this.max !== null && result > this.max)
            result = this.max;
        return result;
    }
    parseLocaleNumber(input) {
        const { decimalSeparator } = this.getSeparators();
        const allowed = new RegExp(`[^0-9\\${decimalSeparator}-]`, 'g');
        const cleaned = input.replace(allowed, '');
        if (!cleaned || cleaned === '-' || cleaned === decimalSeparator)
            return null;
        const normalized = decimalSeparator === '.' ? cleaned : cleaned.replace(new RegExp(`\\${decimalSeparator}`, 'g'), '.');
        const parsed = parseFloat(normalized);
        return isNaN(parsed) ? null : parsed;
    }
    getSeparators() {
        const locale = this.getEffectiveLocale();
        const parts = new Intl.NumberFormat(locale).formatToParts(1000.1);
        const decimal = parts.find(p => p.type === 'decimal')?.value || '.';
        const group = parts.find(p => p.type === 'group')?.value || ',';
        return { decimalSeparator: decimal, groupSeparator: group };
    }
    formatToRaw(value) {
        if (value === null || value === undefined)
            return '';
        const locale = this.getEffectiveLocale();
        return new Intl.NumberFormat(locale, {
            style: 'decimal',
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        }).format(value);
    }
    formatToDisplay(value) {
        if (value === null || value === undefined)
            return '—';
        const locale = this.getEffectiveLocale();
        if (this.showSymbol) {
            return new Intl.NumberFormat(locale, {
                style: 'currency',
                currency: this.currency,
                minimumFractionDigits: this.decimals,
                maximumFractionDigits: this.decimals,
            }).format(value);
        }
        return new Intl.NumberFormat(locale, {
            style: 'decimal',
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        }).format(value);
    }
    getCurrencySymbolInfo() {
        if (!this.showSymbol)
            return { symbol: '', isPrefix: true };
        const locale = this.getEffectiveLocale();
        const parts = new Intl.NumberFormat(locale, {
            style: 'currency',
            currency: this.currency,
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        }).formatToParts(1);
        const currencyIndex = parts.findIndex(p => p.type === 'currency');
        const integerIndex = parts.findIndex(p => p.type === 'integer');
        const symbol = parts.find(p => p.type === 'currency')?.value || this.currency;
        const isPrefix = currencyIndex > -1 && integerIndex > -1 ? currencyIndex < integerIndex : true;
        return { symbol, isPrefix };
    }
    getInputClasses() {
        const hasError = !!this.error;
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            hasError
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            (this.disabled || this.loading) ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    getSymbolClasses() {
        return [
            'px-2 text-sm',
            'bg-slate-50 dark:bg-slate-900',
            'border border-slate-200 dark:border-slate-700',
            'text-slate-600 dark:text-slate-400',
            'rounded-lg',
        ].join(' ');
    }
    getContainerClasses() {
        return [
            'w-full',
            (this.disabled || this.loading) ? 'opacity-50' : '',
        ].filter(Boolean).join(' ');
    }
    getAriaLabel() {
        if (this.hasSlot('Label'))
            return undefined;
        return this.currency ? `Amount (${this.currency})` : 'Amount';
    }
    // ===========================================================================
    // RENDER PARTS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label id="${this.labelId}" class="block mb-1 text-sm text-slate-600 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderHelperOrError() {
        if (this.error) {
            return html `
<p id="${this.errorId}" class="mt-1 text-xs text-red-600 dark:text-red-400">
${unsafeHTML(String(this.error))}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderLoading() {
        if (!this.loading)
            return html ``;
        return html `
<div class="mt-1 text-xs text-slate-500 dark:text-slate-400">
${this.msg.loading}
</div>
`;
    }
    renderInputRow() {
        const { symbol, isPrefix } = this.getCurrencySymbolInfo();
        const showSymbol = this.showSymbol && symbol;
        const ariaLabel = this.getAriaLabel();
        return html `
<div class="flex items-center gap-2">
${showSymbol && isPrefix ? html `<span class="${this.getSymbolClasses()}">${symbol}</span>` : nothing}
<input
id="${this.inputId}"
class="${this.getInputClasses()}"
.type="text"
inputmode="decimal"
.name="${this.name}"
.placeholder="${this.placeholder}"
.value="${this.rawValue}"
?disabled="${this.disabled || this.loading}"
?readonly="${this.readonly}"
aria-labelledby="${this.hasSlot('Label') ? this.labelId : nothing}"
aria-describedby="${this.error ? this.errorId : nothing}"
aria-invalid="${this.error ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
aria-label="${ariaLabel || nothing}"
@focus="${this.handleFocus}"
@input="${this.handleInput}"
@blur="${this.handleBlur}"
/>
${showSymbol && !isPrefix ? html `<span class="${this.getSymbolClasses()}">${symbol}</span>` : nothing}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `
<div class="${this.getContainerClasses()}">
${this.renderLabel()}
<div class="text-sm text-slate-900 dark:text-slate-100">
${this.formatToDisplay(this.value)}
</div>
</div>
`;
        }
        return html `
<div class="${this.getContainerClasses()}">
${this.renderLabel()}
${this.renderInputRow()}
${this.renderLoading()}
${this.renderHelperOrError()}
</div>
`;
    }
};
// ===========================================================================
// INTERNAL IDS
// ===========================================================================
EnterMoneyDisplayMolecule.idCounter = 0;
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyDisplayMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyDisplayMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyDisplayMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyDisplayMolecule.prototype, "currency", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyDisplayMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyDisplayMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyDisplayMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyDisplayMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-symbol' })
], EnterMoneyDisplayMolecule.prototype, "showSymbol", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyDisplayMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EnterMoneyDisplayMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyDisplayMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyDisplayMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyDisplayMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyDisplayMolecule.prototype, "loading", void 0);
__decorate([
    state()
], EnterMoneyDisplayMolecule.prototype, "rawValue", void 0);
EnterMoneyDisplayMolecule = EnterMoneyDisplayMolecule_1 = __decorate([
    customElement('groupentermoney--ml-enter-money-display')
], EnterMoneyDisplayMolecule);
export { EnterMoneyDisplayMolecule };
