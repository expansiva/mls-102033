/// <mls fileReference="_102033_/l2/molecules/groupscancode/ml-scan-code.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML SCAN CODE MOLECULE
// =============================================================================
// Skill Group: scan + code
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    openCamera: 'Open camera',
    capture: 'Capture',
    close: 'Close',
    scanAgain: 'Scan again',
    loading: 'Processing...',
    autoCapture: 'Auto scanning...',
    permissionDenied: 'Camera permission denied',
    cameraUnavailable: 'Camera unavailable',
    unknownError: 'Unable to open camera',
};
const messages = {
    en: message_en,
    pt: {
        openCamera: 'Abrir câmera',
        capture: 'Capturar',
        close: 'Fechar',
        scanAgain: 'Ler novamente',
        loading: 'Processando...',
        autoCapture: 'Escaneando automaticamente...',
        permissionDenied: 'Permissão da câmera negada',
        cameraUnavailable: 'Câmera indisponível',
        unknownError: 'Não foi possível abrir a câmera',
    },
};
/// **collab_i18n_end**
let MlScanCodeMolecule = class MlScanCodeMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        this.stream = null;
        this.autoTimer = null;
        this.errorId = `scan-error-${Math.random().toString(36).slice(2)}`;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Result'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.facing = 'environment';
        this.autoCapture = false;
        this.captureInterval = 500;
        this.disabled = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.isOpen = false;
        this.isCapturing = false;
        this.cameraReady = false;
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    disconnectedCallback() {
        this.stopCamera();
        super.disconnectedCallback();
    }
    updated(changedProps) {
        if (changedProps.has('value')) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            if (this.value !== null && this.isOpen) {
                this.closeCamera();
            }
        }
        if ((changedProps.has('autoCapture') || changedProps.has('captureInterval')) && this.isOpen) {
            this.setupAutoCapture();
        }
    }
    // =========================================================================
    // CAMERA CONTROL
    // =========================================================================
    async openCamera() {
        if (this.disabled || this.isOpen)
            return;
        this.isOpen = true;
        this.cameraReady = false;
        await this.updateComplete;
        await this.startCamera();
    }
    closeCamera() {
        if (this.disabled)
            return;
        this.stopCamera();
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('close', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    async startCamera() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facing },
            });
            this.stream = stream;
            const video = this.getVideoElement();
            if (video) {
                video.srcObject = stream;
                await video.play();
            }
            this.cameraReady = true;
            this.setupAutoCapture();
            this.dispatchEvent(new CustomEvent('open', {
                bubbles: true,
                composed: true,
                detail: {},
            }));
        }
        catch (err) {
            const error = err;
            if (error?.name === 'NotAllowedError' || error?.name === 'PermissionDeniedError') {
                this.error = this.msg.permissionDenied;
            }
            else if (error?.name === 'NotFoundError' || error?.name === 'OverconstrainedError') {
                this.error = this.msg.cameraUnavailable;
            }
            else {
                this.error = this.msg.unknownError;
            }
            this.isOpen = false;
        }
    }
    stopCamera() {
        if (this.autoTimer !== null) {
            window.clearInterval(this.autoTimer);
            this.autoTimer = null;
        }
        if (this.stream) {
            this.stream.getTracks().forEach((track) => track.stop());
            this.stream = null;
        }
        this.cameraReady = false;
    }
    setupAutoCapture() {
        if (!this.isOpen || !this.autoCapture) {
            if (this.autoTimer !== null) {
                window.clearInterval(this.autoTimer);
                this.autoTimer = null;
            }
            return;
        }
        if (this.autoTimer !== null) {
            window.clearInterval(this.autoTimer);
            this.autoTimer = null;
        }
        this.autoTimer = window.setInterval(() => {
            if (!this.isOpen || this.loading || this.disabled)
                return;
            this.captureFrame();
        }, this.captureInterval);
    }
    captureFrame() {
        if (this.disabled || this.loading || !this.cameraReady || this.isCapturing)
            return;
        const video = this.getVideoElement();
        if (!video || video.videoWidth === 0 || video.videoHeight === 0)
            return;
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const image = canvas.toDataURL('image/png');
        this.isCapturing = true;
        window.setTimeout(() => {
            this.isCapturing = false;
        }, 200);
        this.dispatchEvent(new CustomEvent('capture', {
            bubbles: true,
            composed: true,
            detail: { image },
        }));
    }
    getVideoElement() {
        return this.querySelector('video[data-role="scanner"]');
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleTriggerClick() {
        if (this.disabled)
            return;
        this.openCamera();
    }
    handleCaptureClick() {
        this.captureFrame();
    }
    handleScanAgain() {
        if (this.disabled)
            return;
        this.value = null;
        this.openCamera();
    }
    handleKeydown(e) {
        if (e.key === 'Escape' && this.isOpen) {
            this.closeCamera();
        }
    }
    // =========================================================================
    // RENDER HELPERS
    // =========================================================================
    getRootClasses() {
        return [
            'w-full rounded-xl border p-4 space-y-3',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
            'text-slate-900 dark:text-slate-100',
            this.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-default',
        ].filter(Boolean).join(' ');
    }
    getActionButtonClasses() {
        return [
            'inline-flex items-center justify-center rounded-lg px-4 py-2 text-sm font-medium border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'border-slate-200 dark:border-slate-700',
            'hover:bg-slate-50 dark:hover:bg-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    getCaptureButtonClasses() {
        return [
            'inline-flex items-center justify-center rounded-full w-14 h-14 border-4 transition',
            'bg-white dark:bg-slate-900',
            'border-sky-500 dark:border-sky-400',
            'text-slate-900 dark:text-slate-100',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.isCapturing ? 'scale-95' : '',
            this.disabled || this.loading ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    getViewfinderClasses() {
        return [
            'relative w-full aspect-video rounded-xl overflow-hidden border',
            'bg-slate-50 dark:bg-slate-900',
            'border-slate-200 dark:border-slate-700',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderHelperOrError() {
        if (this.error) {
            return html `<p id="${this.errorId}" class="text-xs text-red-600 dark:text-red-400">${this.error}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="text-xs text-slate-500 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderTrigger() {
        const content = this.hasSlot('Trigger')
            ? html `${unsafeHTML(this.getSlotContent('Trigger'))}`
            : html `<span>${this.msg.openCamera}</span>`;
        return html `
      <button
        type="button"
        class="${this.getActionButtonClasses()}"
        ?disabled=${this.disabled}
        role="button"
        aria-label="${this.msg.openCamera}"
        aria-describedby=${ifDefined(this.error ? this.errorId : undefined)}
        @click=${this.handleTriggerClick}
      >
        ${content}
      </button>
    `;
    }
    renderResult() {
        const resultContent = this.hasSlot('Result')
            ? html `${unsafeHTML(this.getSlotContent('Result'))}`
            : html `<span class="text-sm text-slate-900 dark:text-slate-100">${this.value ?? ''}</span>`;
        return html `
      <div class="space-y-3" aria-live="polite">
        <div class="rounded-lg border p-3 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
          ${resultContent}
        </div>
        <button
          type="button"
          class="${this.getActionButtonClasses()}"
          ?disabled=${this.disabled}
          @click=${this.handleScanAgain}
        >
          ${this.msg.scanAgain}
        </button>
      </div>
    `;
    }
    renderViewfinder() {
        return html `
      <div class="${this.getViewfinderClasses()}" @keydown=${this.handleKeydown} tabindex="0">
        <video data-role="scanner" class="w-full h-full object-cover" aria-hidden="true" autoplay muted playsinline></video>
        ${this.loading
            ? html `
              <div class="absolute inset-0 flex items-center justify-center bg-white/70 dark:bg-slate-900/70">
                <div class="text-sm text-slate-900 dark:text-slate-100">${this.msg.loading}</div>
              </div>
            `
            : nothing}
      </div>
      <div class="flex items-center justify-between">
        ${this.autoCapture
            ? html `<span class="text-xs text-slate-500 dark:text-slate-400">${this.msg.autoCapture}</span>`
            : html `
              <button
                type="button"
                class="${this.getCaptureButtonClasses()}"
                aria-label="${this.msg.capture}"
                ?disabled=${this.disabled || this.loading}
                @click=${this.handleCaptureClick}
              ></button>
            `}
        <button
          type="button"
          class="${this.getActionButtonClasses()}"
          aria-label="${this.msg.close}"
          ?disabled=${this.disabled}
          @click=${this.closeCamera}
        >
          ${this.msg.close}
        </button>
      </div>
    `;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasValue = this.value !== null;
        return html `
      <div class="${this.getRootClasses()}" aria-describedby=${ifDefined(this.error ? this.errorId : undefined)}>
        ${this.renderLabel()}
        <div class="space-y-3">
          ${this.isOpen
            ? this.renderViewfinder()
            : hasValue
                ? this.renderResult()
                : this.renderTrigger()}
        </div>
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "facing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'auto-capture' })
], MlScanCodeMolecule.prototype, "autoCapture", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'capture-interval' })
], MlScanCodeMolecule.prototype, "captureInterval", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanCodeMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanCodeMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlScanCodeMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlScanCodeMolecule.prototype, "isCapturing", void 0);
__decorate([
    state()
], MlScanCodeMolecule.prototype, "cameraReady", void 0);
MlScanCodeMolecule = __decorate([
    customElement('groupscancode--ml-scan-code')
], MlScanCodeMolecule);
export { MlScanCodeMolecule };
