/// <mls fileReference="_102033_/l2/shared/designSystemRuntime.ts" enhancement="_blank" />
async function loadDesignSystemCss(name, path) {
    const { getTokensCss } = await import('/_102029_/l2/designSystemBase.js');
    return getTokensCss(name, path);
}
function normalizeDesignSystem(name) {
    return name.trim().toLowerCase();
}
export function listRuntimeDesignSystems(designSystems) {
    const names = [];
    const seen = new Set();
    for (const value of designSystems ?? []) {
        if (typeof value !== 'string') {
            continue;
        }
        const name = value.trim();
        const key = normalizeDesignSystem(name);
        if (key && !seen.has(key)) {
            seen.add(key);
            names.push(name);
        }
    }
    return names;
}
export function resolveRuntimeDesignSystem(designSystems, requestedDesignSystem) {
    const requested = normalizeDesignSystem(requestedDesignSystem);
    if (!requested) {
        return undefined;
    }
    return designSystems.find((name) => normalizeDesignSystem(name) === requested);
}
export function getRuntimeDesignSystem(designSystems, runtimeDocument = document) {
    const active = runtimeDocument.getElementById('ds-tokens')?.dataset.designSystem;
    return resolveRuntimeDesignSystem(designSystems, active ?? '') ?? designSystems[0];
}
export function getNextRuntimeDesignSystem(designSystems, currentDesignSystem) {
    if (designSystems.length <= 1) {
        return undefined;
    }
    const current = currentDesignSystem
        ? resolveRuntimeDesignSystem(designSystems, currentDesignSystem)
        : undefined;
    const currentIndex = current ? designSystems.indexOf(current) : -1;
    return designSystems[(currentIndex + 1) % designSystems.length];
}
export async function setRuntimeDesignSystem(requestedDesignSystem, designSystems, projectId, runtimeDocument = document, loadCss = loadDesignSystemCss) {
    const designSystem = typeof requestedDesignSystem === 'string'
        ? resolveRuntimeDesignSystem(designSystems, requestedDesignSystem)
        : undefined;
    if (!designSystem) {
        const valid = designSystems.length > 0 ? designSystems.join(', ') : 'none';
        throw new Error(`mls.sites.setDS("${String(requestedDesignSystem)}"): design system not available (valid: ${valid}).`);
    }
    const css = await loadCss(designSystem, `/_${projectId}_/l2/designSystem.js`);
    if (!css) {
        throw new Error(`mls.sites.setDS("${designSystem}"): design system generated no token CSS.`);
    }
    let style = runtimeDocument.getElementById('ds-tokens');
    if (!style) {
        style = runtimeDocument.createElement('style');
        style.id = 'ds-tokens';
        runtimeDocument.head.appendChild(style);
    }
    style.textContent = css;
    style.dataset.designSystem = designSystem;
}
