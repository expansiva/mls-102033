function normalizeRoutePattern(route) {
    return [
        route.path,
        ...(route.aliases ?? []),
    ];
}
export function matchAuraRoute(routes, pathname) {
    const exactMatches = routes.flatMap((route) => normalizeRoutePattern(route)
        .filter((pattern) => (route.matchMode ?? 'exact') === 'exact' && pattern === pathname)
        .map(() => route));
    if (exactMatches.length > 0) {
        return exactMatches[0];
    }
    const prefixMatches = routes.flatMap((route) => normalizeRoutePattern(route)
        .filter((pattern) => (route.matchMode ?? 'exact') === 'prefix' && pathname.startsWith(`${pattern}/`))
        .map((pattern) => ({ route, patternLength: pattern.length })));
    prefixMatches.sort((left, right) => right.patternLength - left.patternLength);
    return prefixMatches[0]?.route;
}
export function getCollabRouteChunkCache() {
    if (!globalThis.window) {
        return new Set();
    }
    window.collabRouteChunkCache ?? (window.collabRouteChunkCache = new Set());
    return window.collabRouteChunkCache;
}
export function getCollabRouteChunkPromises() {
    if (!globalThis.window) {
        return new Map();
    }
    window.collabRouteChunkPromises ?? (window.collabRouteChunkPromises = new Map());
    return window.collabRouteChunkPromises;
}
export async function loadAuraRouteChunk(entrypoint, importer = (specifier) => import(specifier)) {
    const loadedChunks = getCollabRouteChunkCache();
    const pendingLoads = getCollabRouteChunkPromises();
    if (loadedChunks.has(entrypoint)) {
        return;
    }
    const cachedPromise = pendingLoads.get(entrypoint);
    if (cachedPromise) {
        await cachedPromise;
        return;
    }
    const pending = importer(entrypoint)
        .then(() => {
        loadedChunks.add(entrypoint);
    })
        .finally(() => {
        pendingLoads.delete(entrypoint);
    });
    pendingLoads.set(entrypoint, pending);
    await pending;
}
//# sourceMappingURL=routeRuntime.js.map