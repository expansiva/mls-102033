/// <mls fileReference="_102033_/l2/shared/chartRuntime.ts" enhancement="_blank" />
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var _chart, _observer, _bound, _a;
// Shared business-chart runtime. Consumers should dynamically import this module so
// esbuild emits ECharts as an on-demand chunk shared by every chart in the publication.
import { noChange } from 'lit';
import { AsyncDirective } from 'lit/async-directive.js';
import { directive, PartType } from 'lit/directive.js';
import * as echarts from 'echarts/core';
import { BarChart, BoxplotChart, CandlestickChart, FunnelChart, GaugeChart, GraphChart, HeatmapChart, LineChart, PieChart, SankeyChart, ScatterChart, SunburstChart, TreemapChart, } from 'echarts/charts';
import { AriaComponent, DataZoomComponent, DatasetComponent, GridComponent, LegendComponent, MarkAreaComponent, MarkLineComponent, MarkPointComponent, TitleComponent, ToolboxComponent, TooltipComponent, TransformComponent, VisualMapComponent, } from 'echarts/components';
import { LabelLayout, UniversalTransition } from 'echarts/features';
import { CanvasRenderer } from 'echarts/renderers';
echarts.use([
    BarChart,
    BoxplotChart,
    CandlestickChart,
    FunnelChart,
    GaugeChart,
    GraphChart,
    HeatmapChart,
    LineChart,
    PieChart,
    SankeyChart,
    ScatterChart,
    SunburstChart,
    TreemapChart,
    AriaComponent,
    DataZoomComponent,
    DatasetComponent,
    GridComponent,
    LegendComponent,
    MarkAreaComponent,
    MarkLineComponent,
    MarkPointComponent,
    TitleComponent,
    ToolboxComponent,
    TooltipComponent,
    TransformComponent,
    VisualMapComponent,
    LabelLayout,
    UniversalTransition,
    CanvasRenderer,
]);
export { echarts };
/**
 * Bind an ECharts option to the element this directive sits on.
 *
 * @param option a full EChartsCoreOption. Every chart type and component this runtime registers above is
 *        available — no `echarts.use()` needed at the call site, which is the whole point of the module:
 *        an unregistered piece renders BLANK with no error.
 * @param events optional handlers, e.g. `{ click: (p) => this.selectCategory(p.name) }`. Rebound on every
 *        update, so a closure over fresh state is always the one that runs.
 *
 * The element must have a height (ECharts measures its container; a container of height 0 draws nothing).
 */
export const chart = directive((_a = class extends AsyncDirective {
        constructor(partInfo) {
            super(partInfo);
            _chart.set(this, void 0);
            _observer.set(this, void 0);
            _bound.set(this, []);
            if (partInfo.type !== PartType.ELEMENT) {
                throw new Error('chart() must be used as an element directive: <div ${chart(option)}></div>');
            }
        }
        render(_option, _events) {
            return noChange;
        }
        update(part, [option, events]) {
            const element = part.element;
            if (!__classPrivateFieldGet(this, _chart, "f")) {
                __classPrivateFieldSet(this, _chart, echarts.init(element), "f");
                // The element can be resized by layout alone (a flex/grid sibling changing), which no Lit update
                // reports — so observe the node rather than hooking the render cycle.
                __classPrivateFieldSet(this, _observer, new ResizeObserver(() => __classPrivateFieldGet(this, _chart, "f")?.resize()), "f");
                __classPrivateFieldGet(this, _observer, "f").observe(element);
            }
            // Rebind every update: the handlers are closures over the render's state, and keeping the first ones
            // would silently act on stale data. Only the names bound here are removed, so a handler attached by
            // some other code on the same instance survives.
            for (const name of __classPrivateFieldGet(this, _bound, "f"))
                __classPrivateFieldGet(this, _chart, "f").off(name);
            __classPrivateFieldSet(this, _bound, Object.keys(events ?? {}), "f");
            for (const name of __classPrivateFieldGet(this, _bound, "f"))
                __classPrivateFieldGet(this, _chart, "f").on(name, events[name]);
            // `true` replaces the option instead of merging: a page that re-renders with fewer series must not
            // keep the old ones on screen.
            __classPrivateFieldGet(this, _chart, "f").setOption(option, true);
            return noChange;
        }
        /** Element left the DOM: release the canvas and the observer, or both leak for the session. */
        disconnected() {
            __classPrivateFieldGet(this, _observer, "f")?.disconnect();
            __classPrivateFieldSet(this, _observer, undefined, "f");
            __classPrivateFieldSet(this, _bound, [], "f");
            // dispose() drops the handlers with the instance; the list is cleared so a reconnect starts clean.
            __classPrivateFieldGet(this, _chart, "f")?.dispose();
            __classPrivateFieldSet(this, _chart, undefined, "f");
        }
        /** Lit reuses the directive when the element comes back; `update` runs again and re-inits. */
        reconnected() { }
    },
    _chart = new WeakMap(),
    _observer = new WeakMap(),
    _bound = new WeakMap(),
    _a));
