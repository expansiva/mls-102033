/// <mls fileReference="_102033_/l2/shared/languageRuntime.ts" enhancement="_blank" />
function normalizeLanguage(language) {
    return language.trim().replace(/_/gu, '-').toLowerCase();
}
export function listRuntimeLanguages(languages) {
    return [...new Set((languages ?? [])
            .filter((language) => typeof language === 'string')
            .map(normalizeLanguage)
            .filter(Boolean))];
}
export function resolveRuntimeLanguage(languages, requestedLanguage) {
    const requested = normalizeLanguage(requestedLanguage);
    if (!requested) {
        return undefined;
    }
    const exact = languages.find((language) => normalizeLanguage(language) === requested);
    if (exact) {
        return exact;
    }
    const primary = requested.split('-')[0];
    return languages.find((language) => normalizeLanguage(language).split('-')[0] === primary);
}
export function getRuntimeLanguage(languages, documentLanguage) {
    return resolveRuntimeLanguage(languages, documentLanguage)
        ?? languages[0]
        ?? (normalizeLanguage(documentLanguage) || undefined);
}
export function getNextRuntimeLanguage(languages, documentLanguage) {
    if (languages.length <= 1) {
        return undefined;
    }
    const current = getRuntimeLanguage(languages, documentLanguage);
    const currentIndex = current ? languages.indexOf(current) : -1;
    return languages[(currentIndex + 1) % languages.length];
}
export function setRuntimeLanguage(requestedLanguage, languages, runtimeDocument = document) {
    const language = typeof requestedLanguage === 'string'
        ? resolveRuntimeLanguage(languages, requestedLanguage)
        : undefined;
    if (!language) {
        const valid = languages.length > 0 ? languages.join(', ') : 'none';
        throw new Error(`mls.sites.setLanguage("${String(requestedLanguage)}"): language not available (valid: ${valid}).`);
    }
    runtimeDocument.documentElement.lang = language;
    for (const element of Array.from(runtimeDocument.querySelectorAll('*'))) {
        const component = element;
        if (typeof component.requestUpdate === 'function') {
            component.requestUpdate();
        }
    }
}
