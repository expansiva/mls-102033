/// <mls fileReference="_102033_/l2/shared/layout/auraNavigate.ts" enhancement="_blank" />
import { beginExpectedNavigationLoad, runBlockingUiAction } from '/_102033_/l2/shared/interactionRuntime.js';
import { findModuleTabForPath, isModuleRegistered, openModuleTab, rememberShellRoute, navigateModuleTab, } from '/_102033_/l2/shared/moduleTab.js';
function traceLazy(event, details) {
    if (!window.isTraceLazy) {
        return;
    }
    console.log('[traceLazy][auraNavigate]', event, details ?? {});
}
/** True when `href` is a route of the module currently booted (SPA navigation applies). */
export function isInternalModuleHref(href, basePath) {
    if (!href.startsWith('/'))
        return false;
    if (!basePath)
        return true;
    return href === basePath || href.startsWith(`${basePath}/`);
}
/**
 * Active state of a region's navigation entry. The module root answers to its aliases
 * (`/index.html`, `/overview`) — the rule the aside has always applied, now shared with the header.
 */
export function isRegionLinkActive(href, currentPath, basePath) {
    if (basePath && href === basePath) {
        return currentPath === href
            || currentPath === `${href}/index.html`
            || currentPath === `${href}/overview`;
    }
    return currentPath === href;
}
/** Pushes the route and lets the shell's popstate handler settle the expected load. */
async function pushRoute(href, signal) {
    const pendingLoad = beginExpectedNavigationLoad(signal);
    traceLazy('pushRoute.dispatch', { href });
    window.history.pushState({}, '', href);
    window.dispatchEvent(new PopStateEvent('popstate'));
    await pendingLoad;
    traceLazy('pushRoute.resolved', { href });
}
function bootBasePath() {
    const boot = window.collabBoot;
    return boot?.basePath ?? '';
}
function basePathForNewTab(href, hinted, bootBase) {
    const path = href.split(/[?#]/u, 1)[0];
    if (hinted && hinted !== bootBase && (path === hinted || path.startsWith(`${hinted}/`))) {
        return hinted;
    }
    const segment = path.split('/').filter(Boolean)[0];
    return segment ? `/${segment}` : path;
}
/** Module tab: pushState, render that tab, activate it. popstate settles the expected load. */
async function pushModuleTab(href, basePath, alreadyOpen, signal) {
    const pendingLoad = beginExpectedNavigationLoad(signal);
    const bootBase = bootBasePath();
    if (bootBase && isInternalModuleHref(window.location.pathname, bootBase)) {
        rememberShellRoute(`${window.location.pathname}${window.location.search}${window.location.hash}`);
    }
    traceLazy('pushModuleTab.dispatch', { href, basePath, alreadyOpen });
    window.history.pushState({}, '', href);
    if (alreadyOpen)
        await navigateModuleTab(basePath, href);
    else
        await openModuleTab(basePath, href);
    window.collabRuntimeNav3?.activateTab(`mod-${basePath}`);
    const PopState = globalThis.PopStateEvent ?? Event;
    window.dispatchEvent(new PopState('popstate'));
    await pendingLoad;
    traceLazy('pushModuleTab.resolved', { href });
}
/**
 * Navigates to `href`: SPA push inside the current module (guarded by the blocking UI), full page
 * load anywhere else. Returns false when the href is not navigable (empty, or not absolute).
 */
export function auraNavigate(href, options = {}) {
    if (!href || !href.startsWith('/')) {
        return false;
    }
    const hinted = options.basePath ?? '';
    const bootBase = bootBasePath() || hinted;
    const path = href.split(/[?#]/u, 1)[0];
    const ownedByBoot = Boolean(bootBase) && isInternalModuleHref(path, bootBase);
    const openTab = ownedByBoot ? undefined : findModuleTabForPath(path);
    if (!ownedByBoot) {
        const basePath = openTab?.basePath ?? basePathForNewTab(href, hinted, bootBase);
        traceLazy('auraNavigate.moduleTab', { href, basePath, alreadyOpen: Boolean(openTab) });
        // Not a registered module (e.g. "/"): a plain link, a full page load as before — never a tab with an error.
        const go = async (signal) => {
            if (!openTab && !(await isModuleRegistered(basePath))) {
                traceLazy('auraNavigate.notModule', { href, basePath });
                window.location.href = href;
                return;
            }
            await pushModuleTab(href, basePath, Boolean(openTab), signal);
        };
        const retry = () => go();
        void runBlockingUiAction(async (signal) => {
            await go(signal);
        }, {
            mode: 'silent',
            busyLabel: options.busyLabel ?? 'Carregando pagina...',
            errorTitle: options.errorTitle ?? 'Nao foi possivel carregar esta pagina',
            retry,
        });
        options.afterNavigate?.();
        return true;
    }
    if (window.location.pathname !== href) {
        traceLazy('auraNavigate', { href });
        const retry = () => pushRoute(href);
        void runBlockingUiAction(async (signal) => {
            await pushRoute(href, signal);
        }, {
            clearContentWhileBusy: true,
            busyLabel: options.busyLabel ?? 'Carregando pagina...',
            errorTitle: options.errorTitle ?? 'Nao foi possivel carregar esta pagina',
            retry,
        });
    }
    options.afterNavigate?.();
    return true;
}
/** Click handler for an in-app anchor: same protocol, taking the href from the event target. */
export function auraNavigateFromEvent(event, options = {}) {
    const target = event.currentTarget;
    const href = target?.getAttribute('href');
    if (!href || !href.startsWith('/')) {
        return;
    }
    event.preventDefault();
    auraNavigate(href, options);
}
