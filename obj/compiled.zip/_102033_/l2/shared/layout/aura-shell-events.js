/// <mls fileReference="_102033_/l2/shared/layout/aura-shell-events.ts" enhancement="_blank" />
export * from '../../shellEvents.js';
//# sourceMappingURL=aura-shell-events.js.map