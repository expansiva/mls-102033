/// <mls fileReference="_102033_/l2/shared/sessionUser.ts" enhancement="_blank" />
const ANONYMOUS = { authenticated: false };
const SESSION_TIMEOUT_MS = 10000;
const ONBOARDING_STATUS = new Set([
    'ready', 'incomplete', 'pending', 'unregistered', 'unavailable',
]);
let pending;
function readString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
/** Only http(s) and data: images — a `javascript:` src in an <img> would be a hole. */
function safePicture(value) {
    const url = readString(value);
    if (!url)
        return undefined;
    return /^(https?:\/\/|data:image\/)/iu.test(url) ? url : undefined;
}
/** Only an authenticated session with a non-empty string mdmId. Anything else is omitted. */
function readId(authenticated, value) {
    if (!authenticated || !value || typeof value !== 'object')
        return undefined;
    const mdmId = readString(value.mdmId);
    return mdmId ? { mdmId } : undefined;
}
/** A same-origin path: one leading slash, no protocol-relative `//` and no origin. */
function localPath(value) {
    const path = readString(value);
    if (!path || !path.startsWith('/') || path.startsWith('//') || path.includes('://'))
        return undefined;
    return path;
}
function readOnboarding(authenticated, value) {
    if (!authenticated || !value || typeof value !== 'object')
        return undefined;
    const body = value;
    const status = body.status;
    const entryPath = localPath(body.entryPath);
    const moduleBasePath = localPath(body.moduleBasePath);
    if (typeof status !== 'string' || !ONBOARDING_STATUS.has(status) || !entryPath || !moduleBasePath)
        return undefined;
    if (entryPath !== moduleBasePath && !entryPath.startsWith(`${moduleBasePath}/`))
        return undefined;
    const onboarding = { status: status, entryPath, moduleBasePath };
    if (body.requestId !== undefined) {
        const requestId = readString(body.requestId);
        if (!requestId)
            return undefined;
        onboarding.requestId = requestId;
    }
    return onboarding;
}
/**
 * Enabled entry sends `company` and `onboarding` together. A legacy body has neither.
 * A present gate that the parser would drop is an invalid protocol — never a synthetic `ready`.
 */
function assertSessionProtocol(payload) {
    if (!payload || typeof payload !== 'object')
        return;
    const info = payload;
    if (info.authenticated !== true)
        return;
    const gated = Object.hasOwn(info, 'company') || Object.hasOwn(info, 'onboarding');
    if (!gated)
        return;
    if (!readOnboarding(true, info.onboarding)) {
        throw new Error('session/info invalid protocol');
    }
    if (info.company != null && !readId(true, info.company)) {
        throw new Error('session/info invalid protocol');
    }
}
export function parseSessionUser(payload) {
    if (!payload || typeof payload !== 'object')
        return ANONYMOUS;
    const info = payload;
    const authenticated = info.authenticated === true;
    const user = {
        authenticated,
        name: readString(info.name),
        email: readString(info.email),
        picture: safePicture(info.picture),
    };
    const person = readId(authenticated, info.person);
    if (person)
        user.person = person;
    const company = readId(authenticated, info.company);
    if (company)
        user.company = company;
    const onboarding = readOnboarding(authenticated, info.onboarding);
    if (onboarding)
        user.onboarding = onboarding;
    return user;
}
function rejectOnAbort(signal) {
    if (signal.aborted)
        return Promise.reject(signal.reason ?? new Error('session/info timed out'));
    return new Promise((_, reject) => {
        signal.addEventListener('abort', () => {
            reject(signal.reason instanceof Error ? signal.reason : new Error('session/info timed out'));
        }, { once: true });
    });
}
/** Headers and body share one deadline. A late body failure must not surface as unhandled. */
async function readJsonBody(response, signal) {
    const body = response.json().then((payload) => payload, (error) => Promise.reject(error instanceof Error ? error : new Error(String(error))));
    try {
        return await Promise.race([body, rejectOnAbort(signal)]);
    }
    catch (error) {
        void body.catch(() => undefined);
        throw error;
    }
}
async function readSessionProbe() {
    const controller = new AbortController();
    const timer = setTimeout(() => {
        controller.abort(new Error('session/info timed out'));
    }, SESSION_TIMEOUT_MS);
    try {
        const response = await fetch('/session/info', { credentials: 'same-origin', signal: controller.signal });
        if (!response.ok)
            throw new Error(`session/info HTTP ${response.status}`);
        const payload = await readJsonBody(response, controller.signal);
        assertSessionProtocol(payload);
        return { user: parseSessionUser(payload) };
    }
    catch (error) {
        return { error: error instanceof Error ? error : new Error(String(error)) };
    }
    finally {
        clearTimeout(timer);
    }
}
function sessionProbe() {
    pending ?? (pending = readSessionProbe());
    return pending;
}
/** The logged user, fetched once per page. Never rejects. */
export async function getSessionUser() {
    const probe = await sessionProbe();
    return 'user' in probe ? probe.user : ANONYMOUS;
}
/**
 * Same fetch and parse as getSessionUser. Rejects when the probe fails or the enabled-entry
 * payload is not a known state with local paths. Never coerces that failure to anonymous.
 */
export async function getSessionUserStrict() {
    const probe = await sessionProbe();
    if ('error' in probe)
        throw probe.error;
    return probe.user;
}
/** Test/diagnostic hook: drops the cached probe so the next call asks again. */
export function resetSessionUserCache() {
    pending = undefined;
}
/**
 * Initials for the avatar fallback: two from a name ("Guilherme Pereira" -> GP), one from an email
 * ("guilherme@x.dev" -> G), and a neutral dot when there is neither.
 */
export function userInitials(user) {
    const name = user.name;
    if (name) {
        const words = name.split(/\s+/u).filter(Boolean);
        const initials = words.length > 1
            ? `${words[0][0]}${words[words.length - 1][0]}`
            : words[0].slice(0, 2);
        return initials.toUpperCase();
    }
    const email = user.email;
    if (email)
        return email[0].toUpperCase();
    return '';
}
/** What the avatar announces to a screen reader and shows on hover. */
export function userLabel(user, anonymousLabel = 'Account') {
    return user.name || user.email || anonymousLabel;
}
