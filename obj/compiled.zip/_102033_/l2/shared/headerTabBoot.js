/// <mls fileReference="_102033_/l2/shared/headerTabBoot.ts" enhancement="_blank" />
function samePath(left, right) {
    const norm = (value) => (value ?? '').replace(/\/+$/u, '') || '/';
    return norm(left) === norm(right);
}
/** The header's boot for a tab: the app's, or — on a module tab — the app's with the module's fields. */
export function headerBootForTab(appBoot, moduleBoot) {
    if (!moduleBoot || samePath(moduleBoot.basePath, appBoot.basePath))
        return appBoot;
    const appModule = { label: appBoot.pageTitle ?? appBoot.moduleId, href: appBoot.basePath };
    const others = [appModule, ...(appBoot.moduleLinks ?? [])].filter((link) => !samePath(link.href, moduleBoot.basePath));
    return {
        ...appBoot,
        moduleId: moduleBoot.moduleId,
        basePath: moduleBoot.basePath,
        routes: moduleBoot.routes,
        pageTitle: moduleBoot.pageTitle,
        navigation: moduleBoot.navigation ?? [],
        moduleLinks: others,
    };
}
