/// <mls fileReference="_102033_/l2/shared/regionMsize.ts" enhancement="_blank" />
// Host-side msize helpers for the runtime shell. The studio collab-page already
// cascades msize through splitter → nav3 → service; this module is the shell's
// own copy of that contract for classic regions and for keeping the service
// host height on the CURRENT attribute (serviceBase writes style.height from
// the previous this.msize because it reads the property before super).
export function formatMsize(rect) {
    return [rect.width.toFixed(2), rect.height.toFixed(2), rect.top.toFixed(2), rect.left.toFixed(2)].join(',');
}
export function msizeForRect(rect) {
    if (rect.width <= 0 || rect.height <= 0)
        return null;
    return formatMsize(rect);
}
export function parseMsizeHeight(msize, fallbackStyleHeight = '') {
    let height = parseFloat((msize || '').split(',')[1] || '');
    if (!Number.isFinite(height) || height <= 0)
        height = parseFloat(fallbackStyleHeight || '');
    if (!Number.isFinite(height) || height <= 0)
        return null;
    return height;
}
export function writeMsize(el, msize) {
    el.setAttribute('msize', msize);
    el.layout?.();
}
export function writeMsizeForRect(el, rect) {
    const msize = msizeForRect(rect);
    if (!msize)
        return false;
    writeMsize(el, msize);
    return true;
}
export function createCoalescedRunner(run, schedule, cancel) {
    let id = 0;
    return {
        trigger() {
            if (id)
                return;
            id = schedule(() => {
                id = 0;
                run();
            });
        },
        cancel() {
            if (!id)
                return;
            cancel(id);
            id = 0;
        },
    };
}
export function attachViewportMsizeListeners(env, onResize) {
    env.addEventListener('resize', onResize);
    env.visualViewport?.addEventListener('resize', onResize);
    return () => {
        env.removeEventListener('resize', onResize);
        env.visualViewport?.removeEventListener('resize', onResize);
    };
}
