/// <mls fileReference="_102033_/l2/shared/chartRuntimeLocal.ts" enhancement="_blank" />
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _instances, _chart, _observer, _element, _option_1, _events_1, _needsOption, _bound, _apply, _a;
import { noChange } from 'lit';
import { AsyncDirective } from 'lit/async-directive.js';
import { directive, PartType } from 'lit/directive.js';
const ECHARTS_RUNTIME_URL = '/_libs/echarts.min.js';
/** Browser-safe local ECharts loader. This module intentionally has no bare ECharts import. */
export function loadECharts() {
    const runtimeWindow = window;
    if (runtimeWindow.echarts)
        return Promise.resolve(runtimeWindow.echarts);
    if (runtimeWindow.collabEChartsLocalRuntime)
        return runtimeWindow.collabEChartsLocalRuntime;
    runtimeWindow.collabEChartsLocalRuntime = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = ECHARTS_RUNTIME_URL;
        script.async = true;
        script.dataset.collabEcharts = 'local';
        script.onload = () => runtimeWindow.echarts
            ? resolve(runtimeWindow.echarts)
            : reject(new Error('Local ECharts runtime loaded without exposing window.echarts.'));
        script.onerror = () => reject(new Error(`Unable to load local ECharts runtime at ${ECHARTS_RUNTIME_URL}.`));
        document.head.appendChild(script);
    });
    return runtimeWindow.collabEChartsLocalRuntime;
}
export const chart = directive((_a = class extends AsyncDirective {
        constructor(partInfo) {
            super(partInfo);
            _instances.add(this);
            _chart.set(this, void 0);
            _observer.set(this, void 0);
            _element.set(this, void 0);
            _option_1.set(this, void 0);
            _events_1.set(this, void 0);
            _needsOption.set(this, true);
            _bound.set(this, []);
            if (partInfo.type !== PartType.ELEMENT) {
                throw new Error('chart() must be used as an element directive: <div ${chart(option)}></div>');
            }
        }
        render(_option, _events) {
            return noChange;
        }
        update(part, [option, events]) {
            __classPrivateFieldSet(this, _element, part.element, "f");
            if (__classPrivateFieldGet(this, _option_1, "f") !== option) {
                __classPrivateFieldSet(this, _option_1, option, "f");
                __classPrivateFieldSet(this, _needsOption, true, "f");
            }
            __classPrivateFieldSet(this, _events_1, events, "f");
            void loadECharts().then(runtime => __classPrivateFieldGet(this, _instances, "m", _apply).call(this, runtime)).catch(error => console.error(error));
            return noChange;
        }
        disconnected() {
            __classPrivateFieldGet(this, _observer, "f")?.disconnect();
            __classPrivateFieldSet(this, _observer, undefined, "f");
            __classPrivateFieldSet(this, _element, undefined, "f");
            __classPrivateFieldSet(this, _option_1, undefined, "f");
            __classPrivateFieldSet(this, _events_1, undefined, "f");
            __classPrivateFieldSet(this, _bound, [], "f");
            __classPrivateFieldSet(this, _needsOption, true, "f");
            __classPrivateFieldGet(this, _chart, "f")?.dispose();
            __classPrivateFieldSet(this, _chart, undefined, "f");
        }
        reconnected() { }
    },
    _chart = new WeakMap(),
    _observer = new WeakMap(),
    _element = new WeakMap(),
    _option_1 = new WeakMap(),
    _events_1 = new WeakMap(),
    _needsOption = new WeakMap(),
    _bound = new WeakMap(),
    _instances = new WeakSet(),
    _apply = function _apply(runtime) {
        const element = __classPrivateFieldGet(this, _element, "f");
        if (!element || !element.isConnected || !__classPrivateFieldGet(this, _option_1, "f"))
            return;
        if (!__classPrivateFieldGet(this, _chart, "f")) {
            __classPrivateFieldSet(this, _chart, runtime.init(element), "f");
            __classPrivateFieldSet(this, _needsOption, true, "f");
            __classPrivateFieldSet(this, _observer, new ResizeObserver(() => __classPrivateFieldGet(this, _chart, "f")?.resize()), "f");
            __classPrivateFieldGet(this, _observer, "f").observe(element);
        }
        for (const name of __classPrivateFieldGet(this, _bound, "f"))
            __classPrivateFieldGet(this, _chart, "f").off(name);
        __classPrivateFieldSet(this, _bound, Object.keys(__classPrivateFieldGet(this, _events_1, "f") ?? {}), "f");
        for (const name of __classPrivateFieldGet(this, _bound, "f"))
            __classPrivateFieldGet(this, _chart, "f").on(name, __classPrivateFieldGet(this, _events_1, "f")[name]);
        if (__classPrivateFieldGet(this, _needsOption, "f")) {
            __classPrivateFieldGet(this, _chart, "f").setOption(__classPrivateFieldGet(this, _option_1, "f"), true);
            __classPrivateFieldSet(this, _needsOption, false, "f");
        }
    },
    _a));
