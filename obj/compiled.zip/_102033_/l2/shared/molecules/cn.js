/// <mls fileReference="_102033_/l2/shared/molecules/cn.ts" enhancement="_blank"/>
export function cn(...inputs) {
    return inputs.filter(Boolean).join(' ');
}
