/// <mls fileReference="_102033_/l2/moleculeBase.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
// =============================================================================
// BASE CLASS
// =============================================================================
export class MoleculeAuraElement extends StateLitElement {
    constructor() {
        // ===========================================================================
        // DATA-CLASS — consumer-provided CSS classes for the root element
        // Usage: <my-component data-class="w-full mt-4">
        // ===========================================================================
        super(...arguments);
        this.cssClass = '';
        // ===========================================================================
        // SLOT TAGS DEFINITION
        // Override in child component
        // ===========================================================================
        this.slotTags = [];
        // ===========================================================================
        // INERT MODE — Molecule inside another molecule's slot tag
        // ===========================================================================
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        this._isInert = false;
        // ===========================================================================
        // SNAPSHOT — Parsed copy of slot tags for reading
        // ===========================================================================
        this._snapshot = null;
        // ===========================================================================
        // INTERNAL — MutationObserver
        // ===========================================================================
        this._slotObserver = null;
        this._updateDebounceTimer = null;
        this._mutationLock = false;
        // ===========================================================================
        // SLOT TAG VISIBILITY
        // ===========================================================================
        this._stopNativeFormEvent = (e) => {
            if (!(e instanceof CustomEvent))
                e.stopImmediatePropagation();
        };
    }
    /**
     * Checks if this element is inside a slot tag of a parent molecule.
     * Walks up the DOM looking for a parent MoleculeAuraElement whose
     * slot tags include one of our ancestors.
     */
    _checkIfInert() {
        let current = this.parentElement;
        let slotTagCandidate = null;
        while (current) {
            // Check if current is a MoleculeAuraElement
            if (current instanceof MoleculeAuraElement) {
                // Check if any of our ancestors (between us and this molecule)
                // is one of its slot tags
                if (slotTagCandidate && current.slotTags.length > 0) {
                    const candidateTag = slotTagCandidate.tagName;
                    const isSlotTag = current.slotTags.some(st => st.toUpperCase() === candidateTag);
                    if (isSlotTag) {
                        return true;
                    }
                }
                // This molecule is not our slot tag parent, stop looking
                // (we don't want to go beyond the nearest molecule ancestor)
                return false;
            }
            // Track the highest non-molecule ancestor as potential slot tag
            slotTagCandidate = current;
            current = current.parentElement;
        }
        return false;
    }
    /**
     * Returns a parsed Document snapshot for querying slot tags.
     */
    getSnapshot() {
        if (!this._snapshot) {
            this._takeSnapshot();
        }
        return this._snapshot;
    }
    /**
     * Takes a snapshot: reads outerHTML from slot tag children,
     * parses into isolated Document.
     */
    _takeSnapshot() {
        const parts = [];
        const children = Array.from(this.children);
        for (const child of children) {
            const tagName = child.tagName;
            const isSlotTag = this.slotTags.some(st => st.toUpperCase() === tagName);
            if (isSlotTag) {
                parts.push(child.outerHTML);
            }
        }
        const parser = new DOMParser();
        this._snapshot = parser.parseFromString(`<body>${parts.join('')}</body>`, 'text/html');
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        // Check if we're inside another molecule's slot tag
        this._isInert = this._checkIfInert();
        if (this._isInert) {
            // Do NOT render, do NOT call super.connectedCallback()
            // This element exists only as raw HTML for the parent to read
            return;
        }
        this._snapshot = null;
        this._hideSlotTags();
        super.connectedCallback();
        this._setupSlotObserver();
        this.addEventListener('change', this._stopNativeFormEvent);
        this.addEventListener('input', this._stopNativeFormEvent);
    }
    disconnectedCallback() {
        if (this._isInert)
            return;
        this.removeEventListener('change', this._stopNativeFormEvent);
        this.removeEventListener('input', this._stopNativeFormEvent);
        super.disconnectedCallback();
        this._teardownSlotObserver();
    }
    _hideSlotTags() {
        Array.from(this.children).forEach(child => {
            const tag = child.tagName?.toLowerCase();
            if (tag && this.slotTags.map(t => t.toLowerCase()).includes(tag)) {
                child.style.display = 'none';
            }
        });
    }
    // ===========================================================================
    // MUTATION OBSERVER — Slot Tag Reactivity
    // ===========================================================================
    _setupSlotObserver() {
        this._slotObserver = new MutationObserver((mutations) => {
            if (this._mutationLock)
                return;
            const hasSlotChange = mutations.some((mutation) => {
                if (mutation.type === 'childList') {
                    // Direct children: new slot tags added or removed?
                    if (mutation.target === this) {
                        for (const node of Array.from(mutation.addedNodes)) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                const tagName = node.tagName;
                                if (this.slotTags.some(st => st.toUpperCase() === tagName)) {
                                    return true;
                                }
                            }
                        }
                        for (const node of Array.from(mutation.removedNodes)) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                const tagName = node.tagName;
                                if (this.slotTags.some(st => st.toUpperCase() === tagName)) {
                                    return true;
                                }
                            }
                        }
                    }
                    // Changes inside existing slot tags (e.g., new TableRow inside TableBody)
                    if (this._isInsideSlotTag(mutation.target)) {
                        return true;
                    }
                    return false;
                }
                if (mutation.type === 'characterData' || mutation.type === 'attributes') {
                    return this._isInsideSlotTag(mutation.target);
                }
                return false;
            });
            if (hasSlotChange) {
                this._debouncedSlotUpdate();
            }
        });
        this._slotObserver.observe(this, {
            childList: true,
            subtree: true,
            characterData: true,
            attributes: true,
        });
    }
    _isInsideSlotTag(node) {
        let current = node;
        while (current && current !== this) {
            if (current.nodeType === Node.ELEMENT_NODE) {
                const tagName = current.tagName;
                if (this.slotTags.some(st => st.toUpperCase() === tagName)) {
                    return true;
                }
            }
            current = current.parentNode;
        }
        return false;
    }
    _teardownSlotObserver() {
        if (this._slotObserver) {
            this._slotObserver.disconnect();
            this._slotObserver = null;
        }
        if (this._updateDebounceTimer !== null) {
            clearTimeout(this._updateDebounceTimer);
            this._updateDebounceTimer = null;
        }
    }
    _debouncedSlotUpdate() {
        if (this._updateDebounceTimer !== null) {
            clearTimeout(this._updateDebounceTimer);
        }
        this._updateDebounceTimer = window.setTimeout(() => {
            this._updateDebounceTimer = null;
            this._onSlotTagsChanged();
        }, 16);
    }
    /**
     * Called when slot tag content changes.
     * Re-takes snapshot, re-hides, re-renders.
     */
    _onSlotTagsChanged() {
        this._mutationLock = true;
        this._hideSlotTags();
        this._mutationLock = false;
        // Invalidate snapshot
        this._snapshot = null;
        // Force re-render
        this.requestUpdate();
    }
    // ===========================================================================
    // SLOT TAG READERS (read from snapshot)
    // ===========================================================================
    getSlot(tag) {
        return this.getSnapshot().querySelector(tag);
    }
    getSlots(tag) {
        return Array.from(this.getSnapshot().querySelectorAll(tag));
    }
    getSlotAttr(tag, attr) {
        return this.getSnapshot().querySelector(tag)?.getAttribute(attr) || null;
    }
    getSlotContent(tag) {
        const el = this.getSnapshot().querySelector(tag);
        return el ? el.innerHTML : '';
    }
    hasSlot(tag) {
        return this.getSnapshot().querySelector(tag) !== null;
    }
    getSlotClass(tag) {
        return this.getSlotAttr(tag, 'data-class') || '';
    }
}
__decorate([
    propertyDataSource({ type: String, attribute: 'data-class' })
], MoleculeAuraElement.prototype, "cssClass", void 0);
