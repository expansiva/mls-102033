/// <mls fileReference="_102033_/l2/moleculeBase.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
// =============================================================================
// BASE CLASS
// =============================================================================
export class MoleculeAuraElement extends StateLitElement {
    constructor() {
        // ===========================================================================
        // DATA-CLASS — consumer-provided CSS classes for the root element
        // Usage: <my-component data-class="w-full mt-4">
        // ===========================================================================
        super(...arguments);
        this.cssClass = '';
        // ===========================================================================
        // SLOT TAGS DEFINITION
        // Override in child component
        // ===========================================================================
        this.slotTags = [];
        // ===========================================================================
        // LIVE SLOTS — composition instead of serialization
        // ===========================================================================
        /**
         * Opt in to LIVE slots: the consumer's slot content is MOVED into place as real
         * DOM nodes, instead of being read as a string and re-emitted with unsafeHTML.
         *
         * Why this exists: the snapshot path serializes slot children via `outerHTML` and
         * re-parses them. Serializing destroys event bindings and component identity, so
         * anything interactive the consumer puts in a slot is dead on arrival — and nested
         * molecules had to be made inert to keep the parent's snapshot readable. That makes
         * slots content-only, which defeats composition.
         *
         * With live slots the nodes are never serialized: they are moved, and moving preserves
         * listeners, Lit part references and nested custom elements. A molecule that opts in
         * also stops forcing its slotted descendants to be inert — they render normally.
         *
         * Opt-in per molecule so the two mechanisms coexist. Keep the snapshot path where the
         * slot carries DATA to be parsed (`TableHead key=…`, `Item value=…`); use live slots
         * where it carries CONTENT or CONTROLS (`Action`, `Label`, `Icon`, `Trigger`).
         */
        this.usesLiveSlots = false;
        /**
         * The consumer's live nodes, per slot tag, held by reference.
         *
         * Holding them is what makes the mechanism survive the anchor coming and going. When a
         * template branch leaves the render (a hidden modal, a collapsed region), Lit removes
         * the anchor and everything under it — including these nodes. Removing a node from the
         * DOM does not destroy it while something still references it, and its listeners stay
         * attached, so the next projection can simply put it back.
         */
        this._liveNodes = new Map();
        /** Last anchor that held each key — see `_currentNodes`. */
        this._liveHosts = new Map();
        /** Detached holder per key, so eviction does not lose content. */
        this._liveHolders = new Map();
        /**
         * Per-element anchors, for molecules that don't pass a slot through but TRANSFORM it.
         *
         * A table is the motivating case: it reads `TableBody > TableRow > TableCell`, sorts and
         * paginates, then re-emits real `<tr>`/`<td>`. The source of a cell's content is a nested
         * element, not a direct child, and there are N×M of them — so an anchor keyed by tag name
         * can't address it. These map an id to the source element instead.
         *
         * The id lives in a WeakMap so the SAME element always gets the SAME id across renders,
         * which is what lets `_liveNodes` survive a row leaving the page and coming back.
         */
        this._liveRefSeq = 0;
        this._liveRefIds = new WeakMap();
        this._liveRefs = new Map();
        // ===========================================================================
        // INERT MODE — Molecule inside another molecule's slot tag
        // ===========================================================================
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        this._isInert = false;
        // ===========================================================================
        // SNAPSHOT — Parsed copy of slot tags for reading
        // ===========================================================================
        this._snapshot = null;
        // ===========================================================================
        // INTERNAL — MutationObserver
        // ===========================================================================
        this._slotObserver = null;
        this._updateDebounceTimer = null;
        this._mutationLock = false;
        // ===========================================================================
        // SLOT TAG VISIBILITY
        // ===========================================================================
        this._stopNativeFormEvent = (e) => {
            if (!(e instanceof CustomEvent))
                e.stopImmediatePropagation();
        };
    }
    /**
     * Renders the placeholder where a live slot's content lands.
     *
     * The anchor must stay free of Lit bindings: Lit does not manage children it did not
     * create, so nodes appended here survive every re-render. Put bindings around the
     * anchor, never inside it.
     */
    renderLiveSlot(tag, cls = '') {
        return html `<span data-ml-live-slot="${tag}" class="${cls}"></span>`;
    }
    /**
     * Same as `renderLiveSlot`, but bound to a specific source ELEMENT instead of a tag.
     *
     * Use it when the molecule transforms the slot structure and one tag maps to many
     * destinations — a table cell, a list item. Pass the LIVE element (from `getLiveSlot`),
     * never a snapshot clone: a clone's children are copies, and moving copies projects
     * dead nodes.
     */
    renderLiveSlotFrom(source, cls = '') {
        if (!source)
            return html ``;
        let id = this._liveRefIds.get(source);
        if (!id) {
            id = `ref${(this._liveRefSeq += 1)}`;
            this._liveRefIds.set(source, id);
        }
        this._liveRefs.set(id, source);
        return html `<span data-ml-live-ref="${id}" class="${cls}"></span>`;
    }
    /**
     * Text currently rendered for a source element, projected or not.
     *
     * A transforming molecule that sorts or filters by cell text cannot read the source
     * element after projection — its children were moved out, so `textContent` is empty.
     * This reads the projected nodes instead, which keeps the value CURRENT: caching the
     * text at capture time would go stale the moment the consumer changed it.
     */
    getLiveText(source) {
        if (!source)
            return '';
        const id = this._liveRefIds.get(source);
        // `_currentNodes` and not `_liveNodes`: when the consumer swaps the slot's content, the
        // capture list goes stale, and sorting by it would use the old text.
        const nodes = id ? this._currentNodes(id) : undefined;
        if (nodes && nodes.length > 0) {
            // Comment nodes are skipped because `textContent` on a Comment returns its DATA, and
            // the projected nodes carry Lit's part markers (`?lit$<id>$`). Including them made the
            // sort key of a projected cell read `?lit$622922547$70` instead of `70`: every
            // projected cell then shared that prefix, sorted among themselves, and the whole block
            // landed before the unprojected rows — `?` collates before digits. Measured with the
            // P4 demo page on 2026-08-03. Element children are safe: `Element.textContent` already
            // concatenates descendant TEXT only, never comment data.
            return nodes
                .filter((n) => n.nodeType !== Node.COMMENT_NODE)
                .map((n) => n.textContent || '')
                .join('')
                .trim();
        }
        return (source.textContent || '').trim();
    }
    /**
     * The LIVE slot element for `tag` — not the snapshot clone.
     *
     * Structure reads (how many rows, which attributes) should come from here in a molecule
     * that projects, because the snapshot goes stale between mutations and, worse, a
     * re-snapshot after projection reads the emptied sources.
     */
    getLiveSlot(tag) {
        return this._findSlotChild(tag);
    }
    /**
     * Moves each live slot's children into its anchor.
     *
     * Runs from `update()` — right after Lit commits the DOM, so the anchors exist. It is
     * deliberately NOT in `updated()`: most molecules override that without calling super,
     * which would silently skip projection.
     */
    _projectLiveSlots() {
        if (!this.usesLiveSlots)
            return;
        const byTag = this.querySelectorAll('[data-ml-live-slot]');
        const byRef = this.querySelectorAll('[data-ml-live-ref]');
        if (byTag.length === 0 && byRef.length === 0)
            return;
        // moving nodes mutates the subtree; without the lock the observer would see it as a
        // slot change and schedule another render, which would re-enter here in a loop
        this._mutationLock = true;
        try {
            byTag.forEach((anchor) => this._fillAnchor(anchor, anchor.dataset.mlLiveSlot, (tag) => this._findSlotChild(tag)));
            byRef.forEach((anchor) => this._fillAnchor(anchor, anchor.dataset.mlLiveRef, (id) => this._liveRefs.get(id) ?? null));
        }
        finally {
            this._mutationLock = false;
        }
    }
    /** Capture-once + reattach-when-empty, shared by both anchor kinds. */
    _fillAnchor(anchor, key, resolve) {
        if (!key)
            return;
        // An anchor can change owner. Lit reuses DOM by position in a `.map()` without
        // `repeat()`, so sorting or paginating a table hands anchor #2 a different source id
        // while it still holds the previous source's nodes. Evicting is safe — `_liveNodes`
        // keeps the references, so the nodes stay alive and detached, ready to be reattached
        // wherever their real owner lands. Without this the reattach guard below would see a
        // non-empty anchor and leave the wrong row's content in place.
        const held = anchor.dataset.mlLiveHeld;
        if (held && held !== key) {
            // Hand them back to that owner's holder instead of discarding them: those nodes can be
            // NEWER than the ones in `_liveNodes` (see `_currentNodes`), and throwing them away would
            // lose content.
            const deposito = this._holderFor(held);
            while (anchor.firstChild)
                deposito.appendChild(anchor.firstChild);
            delete anchor.dataset.mlLiveHeld;
        }
        // Capture once. The source's CHILDREN are what gets projected — not the slot element
        // itself — matching what the snapshot path exposed through getSlotContent().
        if (!this._liveNodes.has(key)) {
            const source = resolve(key);
            if (!source)
                return;
            const nodes = Array.from(source.childNodes);
            if (nodes.length === 0)
                return;
            this._liveNodes.set(key, nodes);
            source.style.display = 'none';
        }
        // (Re)attach whenever the anchor is empty. This runs on EVERY update on purpose: an
        // anchor that left the template and came back is a new, empty element, and the nodes
        // are detached but alive. Projecting only once was a real bug — the content vanished
        // the first time the branch was hidden.
        if (!anchor.firstChild) {
            for (const node of this._currentNodes(key))
                anchor.appendChild(node);
        }
        this._liveHosts.set(key, anchor);
        anchor.dataset.mlLiveHeld = key;
    }
    /**
     * Holder per key: a detached element where the nodes wait while they have no anchor.
     * It exists so eviction does not lose content.
     */
    _holderFor(key) {
        let holder = this._liveHolders.get(key);
        if (!holder) {
            holder = document.createElement('div');
            this._liveHolders.set(key, holder);
        }
        return holder;
    }
    /**
     * The CURRENT nodes for a key, which are not always the captured ones.
     *
     * `_liveNodes` is the list taken at capture time. It goes stale when the consumer REPLACES the
     * slot's content instead of just updating values — `${loading ? spinner : table}`, for example:
     * Lit removes the old nodes and inserts different ones between the same markers, which are
     * still in the anchor. Reattaching the capture list would hand back only the already-discarded
     * nodes, and the region would come back EMPTY when reopened. Measured on 2026-08-04 with
     * demotable--pedidosdetalhe: opening, closing and opening again showed a blank row.
     *
     * Hence the order of preference: the last anchor that held the key (Lit removes the anchor from
     * the DOM, but its children stay INSIDE it), then the holder, and only then the capture.
     */
    _currentNodes(key) {
        // `mlLiveHeld === key` is mandatory, not caution: when sorting, Lit reuses the anchors by
        // position and an anchor changes owner. `_liveHosts` still points at it under the OLD key, and
        // without this check we would pull the wrong row's content — in practice, blank rows and
        // scrambled content. Whoever was already evicted loses its `mlLiveHeld`, so it falls through
        // to the holder, which is where its nodes actually are.
        const ultimaAncora = this._liveHosts.get(key);
        if (ultimaAncora?.dataset.mlLiveHeld === key && ultimaAncora.firstChild) {
            return Array.from(ultimaAncora.childNodes);
        }
        const deposito = this._liveHolders.get(key);
        if (deposito?.firstChild)
            return Array.from(deposito.childNodes);
        return this._liveNodes.get(key) ?? [];
    }
    /** The consumer's slot element for `tag`, among this element's own children. */
    _findSlotChild(tag) {
        const wanted = tag.toUpperCase();
        return Array.from(this.children).find((c) => c.tagName === wanted) ?? null;
    }
    /**
     * Checks if this element is inside a slot tag of a parent molecule.
     * Walks up the DOM looking for a parent MoleculeAuraElement whose
     * slot tags include one of our ancestors.
     */
    _checkIfInert() {
        let current = this.parentElement;
        let slotTagCandidate = null;
        while (current) {
            // Check if current is a MoleculeAuraElement
            if (current instanceof MoleculeAuraElement) {
                // NOTE: there is deliberately NO `if (current.usesLiveSlots) return false` here.
                //
                // That short-circuit existed to let a molecule inside a live slot render, but it
                // was per-MOLECULE, not per-SLOT: it woke up everything under a live-slot parent,
                // including content sitting in slots that are still SERIALIZED. Measured on
                // 2026-08-03 with mls-102053/l2/demo-live-slots/notificacoes.ts — a button molecule
                // inside <Message> of a migrated ml-notify-banner rendered itself, `_takeSnapshot()`
                // then serialized it with `outerHTML` (which now carried that rendered markup), and
                // the clone painted it AGAIN: two buttons on screen, one dead and one live. The same
                // page with a NON-migrated molecule showed one button, which is what pinned the
                // cause on this line.
                //
                // Nothing replaces it, because the projection already gives per-slot precision for
                // free: `_fillAnchor` MOVES the nodes into `<span data-ml-live-slot>`, and moving a
                // connected node re-runs disconnected/connectedCallback. On that second pass the
                // walk below finds the anchor's plain ancestors instead of a slot tag, so the node
                // stops being inert exactly when — and only when — it is really projected. Content
                // left in a serialized slot stays inert, and the snapshot stays clean.
                //
                // Check if any of our ancestors (between us and this molecule)
                // is one of its slot tags
                if (slotTagCandidate && current.slotTags.length > 0) {
                    const candidateTag = slotTagCandidate.tagName;
                    const isSlotTag = current.slotTags.some(st => st.toUpperCase() === candidateTag);
                    if (isSlotTag) {
                        return true;
                    }
                }
                // This molecule is not our slot tag parent, stop looking
                // (we don't want to go beyond the nearest molecule ancestor)
                return false;
            }
            // Track the highest non-molecule ancestor as potential slot tag
            slotTagCandidate = current;
            current = current.parentElement;
        }
        return false;
    }
    /**
     * Returns a parsed Document snapshot for querying slot tags.
     */
    getSnapshot() {
        if (!this._snapshot) {
            this._takeSnapshot();
        }
        return this._snapshot;
    }
    /**
     * Takes a snapshot: reads outerHTML from slot tag children,
     * parses into isolated Document.
     */
    _takeSnapshot() {
        const parts = [];
        const children = Array.from(this.children);
        for (const child of children) {
            const tagName = child.tagName;
            const isSlotTag = this.slotTags.some(st => st.toUpperCase() === tagName);
            if (isSlotTag) {
                parts.push(child.outerHTML);
            }
        }
        const parser = new DOMParser();
        this._snapshot = parser.parseFromString(`<body>${parts.join('')}</body>`, 'text/html');
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        // Check if we're inside another molecule's slot tag
        this._isInert = this._checkIfInert();
        if (this._isInert) {
            // Do NOT render, do NOT call super.connectedCallback()
            // This element exists only as raw HTML for the parent to read
            return;
        }
        this._snapshot = null;
        this._hideSlotTags();
        super.connectedCallback();
        this._setupSlotObserver();
        this.addEventListener('change', this._stopNativeFormEvent);
        this.addEventListener('input', this._stopNativeFormEvent);
    }
    /**
     * Projection hook.
     *
     * `update()` is where Lit commits the template to the DOM, so the anchors exist right
     * after `super.update()`. Chosen over `updated()` on purpose: most molecules override
     * `updated()` without calling super, and projection would silently never run. No
     * molecule overrides `update()`.
     */
    update(changed) {
        // Drop the strong id→element map; `render()` repopulates it for the elements this pass
        // actually draws. The WeakMap keeps ids stable, so `_liveNodes` still matches an element
        // that comes back later (a row returning from another page).
        //
        // `_liveNodes` itself is NOT pruned on purpose: a source whose children were moved out
        // is empty forever, so dropping its cached nodes because it is off-screen this pass
        // would blank the cell when it returns.
        this._liveRefs.clear();
        super.update(changed);
        this._projectLiveSlots();
    }
    disconnectedCallback() {
        if (this._isInert)
            return;
        this.removeEventListener('change', this._stopNativeFormEvent);
        this.removeEventListener('input', this._stopNativeFormEvent);
        super.disconnectedCallback();
        this._teardownSlotObserver();
    }
    _hideSlotTags() {
        Array.from(this.children).forEach(child => {
            const tag = child.tagName?.toLowerCase();
            if (tag && this.slotTags.map(t => t.toLowerCase()).includes(tag)) {
                child.style.display = 'none';
            }
        });
    }
    // ===========================================================================
    // MUTATION OBSERVER — Slot Tag Reactivity
    // ===========================================================================
    _setupSlotObserver() {
        this._slotObserver = new MutationObserver((mutations) => {
            if (this._mutationLock)
                return;
            const hasSlotChange = mutations.some((mutation) => {
                if (mutation.type === 'childList') {
                    // Direct children: new slot tags added or removed?
                    if (mutation.target === this) {
                        for (const node of Array.from(mutation.addedNodes)) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                const tagName = node.tagName;
                                if (this.slotTags.some(st => st.toUpperCase() === tagName)) {
                                    return true;
                                }
                            }
                        }
                        for (const node of Array.from(mutation.removedNodes)) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                const tagName = node.tagName;
                                if (this.slotTags.some(st => st.toUpperCase() === tagName)) {
                                    return true;
                                }
                            }
                        }
                    }
                    // Changes inside existing slot tags (e.g., new TableRow inside TableBody)
                    if (this._isInsideSlotTag(mutation.target)) {
                        return true;
                    }
                    return false;
                }
                if (mutation.type === 'characterData' || mutation.type === 'attributes') {
                    return this._isInsideSlotTag(mutation.target);
                }
                return false;
            });
            if (hasSlotChange) {
                this._debouncedSlotUpdate();
            }
        });
        this._slotObserver.observe(this, {
            childList: true,
            subtree: true,
            characterData: true,
            attributes: true,
        });
    }
    _isInsideSlotTag(node) {
        let current = node;
        while (current && current !== this) {
            if (current.nodeType === Node.ELEMENT_NODE) {
                const tagName = current.tagName;
                if (this.slotTags.some(st => st.toUpperCase() === tagName)) {
                    return true;
                }
            }
            current = current.parentNode;
        }
        return false;
    }
    _teardownSlotObserver() {
        if (this._slotObserver) {
            this._slotObserver.disconnect();
            this._slotObserver = null;
        }
        if (this._updateDebounceTimer !== null) {
            clearTimeout(this._updateDebounceTimer);
            this._updateDebounceTimer = null;
        }
    }
    _debouncedSlotUpdate() {
        if (this._updateDebounceTimer !== null) {
            clearTimeout(this._updateDebounceTimer);
        }
        this._updateDebounceTimer = window.setTimeout(() => {
            this._updateDebounceTimer = null;
            this._onSlotTagsChanged();
        }, 16);
    }
    /**
     * Called when slot tag content changes.
     * Re-takes snapshot, re-hides, re-renders.
     */
    _onSlotTagsChanged() {
        this._mutationLock = true;
        this._hideSlotTags();
        this._mutationLock = false;
        // Invalidate snapshot
        this._snapshot = null;
        // Re-capture a live slot ONLY when its source has children again — that means the
        // consumer replaced the slot's content wholesale. Clearing the map blindly would be a
        // bug: the source is normally empty (we moved its children out), so a blind clear
        // would drop the references and lose the content for good.
        //
        // Content edited *inside* an already-projected slot needs nothing here: those nodes
        // live in the anchor now, and the consumer's own render updates them in place.
        for (const tag of this.slotTags) {
            const source = this._findSlotChild(tag);
            if (source && source.childNodes.length > 0)
                this._liveNodes.delete(tag);
        }
        // Same rule for per-element sources: Lit re-creating a cell's subtree puts children back
        // on the source, and that is the signal to capture again.
        for (const [id, source] of this._liveRefs) {
            if (source.childNodes.length > 0)
                this._liveNodes.delete(id);
        }
        // Force re-render
        this.requestUpdate();
    }
    // ===========================================================================
    // SLOT TAG READERS (read from snapshot)
    // ===========================================================================
    getSlot(tag) {
        return this.getSnapshot().querySelector(tag);
    }
    getSlots(tag) {
        return Array.from(this.getSnapshot().querySelectorAll(tag));
    }
    getSlotAttr(tag, attr) {
        return this.getSnapshot().querySelector(tag)?.getAttribute(attr) || null;
    }
    getSlotContent(tag) {
        const el = this.getSnapshot().querySelector(tag);
        return el ? el.innerHTML : '';
    }
    hasSlot(tag) {
        return this.getSnapshot().querySelector(tag) !== null;
    }
    getSlotClass(tag) {
        return this.getSlotAttr(tag, 'data-class') || '';
    }
}
__decorate([
    propertyDataSource({ type: String, attribute: 'data-class' })
], MoleculeAuraElement.prototype, "cssClass", void 0);
