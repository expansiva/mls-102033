/// <mls fileReference="_102033_/l2/cbe/studioEditSlot.ts" enhancement="_blank" />
// Where the editing TOOLS plug into the running app (TASK-102033-studio-to-102020).
//
// The tools (the in-place editor, the class picker, the live-update bridge) used to live in this
// project and be imported straight from `serviceClientApp`. They are authoring, not runtime: they now
// live in the Studio plugin, and this file is the seam that lets them attach WITHOUT this project
// naming them.
//
//   serviceClientApp --publishEditHost({host, chromeHost, studioMode, editLevel})--> slot
//                                                                                     |
//   the tool module (declared by a plugin, loaded by loadStudioTools) --register------+
//
// The direction is the whole point. The master frontend announces "here is the app region and the
// user is on the edit level"; whoever knows what to do with that says so by registering. A tool that
// never loads costs exactly nothing, and a client app with no Studio plugin simply has no tools.
const tools = new Set();
let current = null;
/**
 * A tool announces itself. Returns the unregister.
 *
 * It is called immediately with the current state: a tool loaded lazily (the plugin scan only runs
 * when studio mode turns on) would otherwise wait for the NEXT change to learn it should be armed —
 * and the change that armed it already happened.
 */
export function registerStudioEditTool(tool) {
    tools.add(tool);
    if (current)
        safely(tool, current);
    return () => {
        tools.delete(tool);
    };
}
/** The app side publishes; it does not know who listens. */
export function publishEditHost(state) {
    current = state;
    for (const tool of tools)
        safely(tool, state);
}
/** The state a tool would get if it registered right now. */
export function currentEditHost() {
    return current;
}
let visibleSwap = null;
const waitingSwaps = new Map();
function swapKey(ref) {
    return `${ref.project}/${ref.level}/${ref.folder}/${ref.shortName}`;
}
/**
 * The live-update tool announces how to swap a visible screen. Same direction as `registerStudioEditTool`:
 * this project never names the Studio plugin. A swap asked for before the tool loaded (the plugin scan runs
 * when studio mode turns on) waits and is replayed here, once per screen.
 */
export function registerVisibleScreenSwap(swap) {
    visibleSwap = swap;
    const waiting = [...waitingSwaps.values()];
    waitingSwaps.clear();
    for (const ref of waiting) {
        void swap(ref).catch((err) => console.warn('[studioEditSlot] visible swap failed:', err));
    }
    return () => {
        if (visibleSwap === swap)
            visibleSwap = null;
    };
}
/** Asks for the live swap of one screen; held until a tool registers when none has yet. */
export async function swapVisibleScreen(ref) {
    if (!visibleSwap) {
        waitingSwaps.set(swapKey(ref), ref);
        return;
    }
    await visibleSwap(ref);
}
let previewTabsUpdate = null;
export function registerPreviewTabsUpdate(update) {
    previewTabsUpdate = update;
    return () => {
        if (previewTabsUpdate === update)
            previewTabsUpdate = null;
    };
}
export async function askPreviewTabsUpdate(project, files) {
    if (!previewTabsUpdate) {
        console.error('[studioEditSlot] preview tabs were not updated: no tool registered');
        throw new Error('preview tabs update is not registered');
    }
    await previewTabsUpdate(project, files);
}
/** Only for tests: forget every tool, the last state and the swap. */
export function resetStudioEditSlot() {
    tools.clear();
    current = null;
    visibleSwap = null;
    waitingSwaps.clear();
    previewTabsUpdate = null;
}
/**
 * A tool that throws must not take the app's own chrome down with it.
 *
 * This runs inside the service's lifecycle (connect, level change, studio mode toggle) — an exception
 * from a plugin here would leave the app half-mounted, which is a far worse failure than a tool that
 * does not appear.
 */
function safely(tool, state) {
    try {
        tool(state);
    }
    catch (err) {
        console.warn('[studioEditSlot] edit tool failed:', err);
    }
}
