/// <mls fileReference="_102033_/l2/cbe/pinTag/pinTagCore.ts" enhancement="_blank" />
// PinTag: client comments pinned to elements of the running app (collabMyFiles/pinTagIdeia.md).
//
// This module is the part that loads EARLY and stays small: the pin type, the storage, the screen
// lookup, export/import and the Ctrl+Shift+P shortcut. The interface itself (pinTagMode.ts) is only
// imported the first time the client enters the mode.
//
// Demo phase: the pins live in localStorage (`collab:pins:<project>`). The pin format is already the
// one a future task needs: turning a pin into a task changes WHERE it is written, not the pin.
import { matchAuraRoute } from '/_102033_/l2/shared/routeRuntime.js';
import { siteProjectFromBoot } from '/_102033_/l2/shared/siteProject.js';
export const PIN_KINDS = ['bug', 'suggestion', 'question'];
export const PIN_VERSION = 1;
export function pinStorageKey(project) {
    return `collab:pins:${project}`;
}
// ─── Validation ─────────────────────────────────────────────────────────────
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
function str(value, fallback = '') {
    return typeof value === 'string' ? value : fallback;
}
function fraction(value) {
    if (typeof value !== 'number' || !Number.isFinite(value))
        return 0.5;
    return Math.min(1, Math.max(0, value));
}
/**
 * Reads one pin from untrusted JSON (storage edited by hand, an imported file).
 * Returns undefined when the pin cannot be placed or identified; fills the rest with defaults.
 */
export function parsePin(value) {
    if (!isRecord(value))
        return undefined;
    const id = str(value.id);
    if (!id)
        return undefined;
    const screen = isRecord(value.screen) ? value.screen : undefined;
    const target = isRecord(value.target) ? value.target : undefined;
    if (!screen || !target)
        return undefined;
    const route = str(screen.route);
    if (!route)
        return undefined;
    const chain = Array.isArray(target.chain) ? target.chain.filter((t) => typeof t === 'string' && t.length > 0) : [];
    if (chain.length === 0)
        return undefined;
    const offset = isRecord(target.offset) ? target.offset : {};
    const author = isRecord(value.author) ? value.author : {};
    const context = isRecord(value.context) ? value.context : {};
    const kind = PIN_KINDS.includes(value.kind) ? value.kind : 'suggestion';
    const createdAt = str(value.createdAt, new Date(0).toISOString());
    return {
        id,
        version: typeof value.version === 'number' ? value.version : PIN_VERSION,
        kind,
        text: str(value.text),
        status: value.status === 'resolved' ? 'resolved' : 'open',
        createdAt,
        updatedAt: str(value.updatedAt, createdAt),
        author: { id: str(author.id, 'anon'), label: str(author.label, '-') },
        screen: {
            project: typeof screen.project === 'number' ? screen.project : 0,
            module: str(screen.module),
            route,
            href: str(screen.href, route),
            title: str(screen.title),
        },
        target: {
            chain,
            selector: str(target.selector),
            offset: { x: fraction(offset.x), y: fraction(offset.y) },
            label: str(target.label),
        },
        context: { viewport: str(context.viewport), device: str(context.device) },
    };
}
/** A list of pins from JSON. Invalid JSON, a non-array or invalid entries give fewer pins, never a throw. */
export function parsePinList(json) {
    if (!json)
        return [];
    let data;
    try {
        data = JSON.parse(json);
    }
    catch {
        return [];
    }
    if (!Array.isArray(data))
        return [];
    const seen = new Set();
    const pins = [];
    for (const item of data) {
        const pin = parsePin(item);
        if (!pin || seen.has(pin.id))
            continue;
        seen.add(pin.id);
        pins.push(pin);
    }
    return pins;
}
// ─── Storage ────────────────────────────────────────────────────────────────
/** The browser storage, or null when even touching it throws. */
export function browserPinStorage() {
    try {
        const storage = globalThis.localStorage;
        return storage ?? null;
    }
    catch {
        return null;
    }
}
export function readPins(storage, project) {
    if (!storage)
        return { pins: [], ok: false };
    try {
        return { pins: parsePinList(storage.getItem(pinStorageKey(project))), ok: true };
    }
    catch {
        return { pins: [], ok: false };
    }
}
/** Returns false when the write failed (blocked storage, quota). */
export function writePins(storage, project, pins) {
    if (!storage)
        return false;
    try {
        storage.setItem(pinStorageKey(project), JSON.stringify(pins));
        return true;
    }
    catch {
        return false;
    }
}
// ─── Filters ────────────────────────────────────────────────────────────────
export function pinsForScreen(pins, route) {
    return pins.filter((pin) => pin.screen.route === route);
}
/** Pins of the other screens, grouped by module and route, in first-seen order. */
export function groupOtherScreens(pins, route) {
    const groups = new Map();
    for (const pin of pins) {
        if (pin.screen.route === route)
            continue;
        const key = `${pin.screen.module}\u0000${pin.screen.route}`;
        let group = groups.get(key);
        if (!group) {
            group = { module: pin.screen.module, route: pin.screen.route, title: pin.screen.title, pins: [] };
            groups.set(key, group);
        }
        group.pins.push(pin);
    }
    return [...groups.values()];
}
// ─── Export / import ────────────────────────────────────────────────────────
export function exportPins(pins) {
    return JSON.stringify(pins, null, 2);
}
/** Joins the imported pins by `id`: a pin already here is kept as is, a new one is added. */
export function importPins(existing, json) {
    let data;
    try {
        data = JSON.parse(json);
    }
    catch {
        return { pins: [...existing], added: 0, ok: false };
    }
    if (!Array.isArray(data))
        return { pins: [...existing], added: 0, ok: false };
    const ids = new Set(existing.map((pin) => pin.id));
    const pins = [...existing];
    let added = 0;
    for (const pin of parsePinList(json)) {
        if (ids.has(pin.id))
            continue;
        ids.add(pin.id);
        pins.push(pin);
        added++;
    }
    return { pins, added, ok: true };
}
// ─── Ids ────────────────────────────────────────────────────────────────────
export function newPinId(random = Math.random) {
    let id = '';
    for (let i = 0; i < 8; i++)
        id += Math.floor(random() * 16).toString(16);
    return `pin_${id}`;
}
/**
 * The screen a URL shows: the registered route (no params) when the boot knows it, else the path
 * itself. A module tab of another module is not in this boot's routes, so it falls back to its path.
 */
export function screenFor(boot, location, documentTitle = '') {
    const project = siteProjectFromBoot(boot);
    const routes = Array.isArray(boot?.routes) ? boot.routes : [];
    const match = routes.length ? matchAuraRoute(routes, location.pathname) : undefined;
    const route = match?.path ?? location.pathname;
    const firstSegment = route.split('/').filter(Boolean)[0] ?? '';
    return {
        project,
        module: match && boot?.moduleId ? boot.moduleId : firstSegment,
        route,
        href: `${location.pathname}${location.search}${location.hash}`,
        title: match?.title || documentTitle || route,
    };
}
export function currentScreen() {
    const boot = window.collabBoot;
    return screenFor(boot, window.location, document.title);
}
/** The site project the pins belong to. 0 when the boot has none. */
export function currentPinProject() {
    return siteProjectFromBoot(window.collabBoot);
}
// ─── Mode toggle and shortcut ───────────────────────────────────────────────
const SHORTCUT_KEY = 'P';
/** Loads the interface on first use, then enters or leaves the mode. */
export async function togglePinTagMode() {
    try {
        const mode = await import('/_102033_/l2/cbe/pinTag/pinTagMode.js');
        mode.togglePinTagMode();
    }
    catch (error) {
        console.error('[pinTag] mode failed to load', error);
    }
}
/** Ctrl+Shift+P, only the plain combination: Alt and Meta belong to other shortcuts. */
export function isPinTagShortcut(ev) {
    return ev.ctrlKey && ev.shiftKey && !ev.altKey && !ev.metaKey
        && typeof ev.key === 'string' && ev.key.toUpperCase() === SHORTCUT_KEY;
}
/**
 * Installs only the shortcut — once per page. Called at module load, like the report bug's
 * Ctrl+Shift+B. Firefox may keep Ctrl+Shift+P for its private window; the menu item still works.
 */
export function installPinTag() {
    if (typeof window === 'undefined' || typeof window.addEventListener !== 'function')
        return;
    const w = window;
    if (w.__collabPinTagInstalled)
        return;
    w.__collabPinTagInstalled = true;
    window.addEventListener('keydown', (ev) => {
        if (!isPinTagShortcut(ev))
            return;
        ev.preventDefault();
        ev.stopPropagation();
        void togglePinTagMode();
    }, true);
}
installPinTag();
