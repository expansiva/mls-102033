/// <mls fileReference="_102033_/l2/cbe/studioDraftFiles.ts" enhancement="_blank" />
// Point the in-memory file list at the draft blobs from draftDiff.
// Memory only: do not call savePrjInfo, updateProjectFilesInfo or loadOtherProjectInfoIfNeeded,
// and do not change the project updated-at. The next login would overwrite these files.
function errorText(err) {
    return err instanceof Error ? err.message : String(err);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/** `l2/cbe/studioDraftFiles.ts` → level, folder, short name, extension. Other paths → undefined. */
function parseDraftFile(path) {
    const layer = path.startsWith('l1/') ? 1 : path.startsWith('l2/') ? 2 : path.startsWith('l3/') ? 3 : 0;
    if (layer === 0)
        return undefined;
    const rest = path.slice(3);
    if (rest.length === 0 || rest.startsWith('/') || rest.endsWith('/'))
        return undefined;
    const slash = rest.lastIndexOf('/');
    const folder = slash === -1 ? '' : rest.slice(0, slash);
    const filename = slash === -1 ? rest : rest.slice(slash + 1);
    if (!filename || (slash !== -1 && !folder))
        return undefined;
    // First dot, same split as parseStorFileName (static/libs/mls.js:3568).
    const dot = filename.indexOf('.');
    if (dot < 0)
        return { level: layer, folder, shortName: filename, extension: '' };
    const shortName = filename.slice(0, dot);
    if (!shortName)
        return undefined;
    return { level: layer, folder, shortName, extension: filename.slice(dot) };
}
function toOp(action, path, loc, sha) {
    return {
        action,
        path,
        level: loc.level,
        folder: loc.folder,
        shortName: loc.shortName,
        extension: loc.extension,
        sha,
    };
}
function opsOfRename(file) {
    const created = parseDraftFile(file.path);
    if (typeof file.from !== 'string' || file.from.length === 0) {
        if (!created)
            return [];
        throw new Error('rename without from');
    }
    const removed = parseDraftFile(file.from);
    if (!removed && !created)
        return [];
    const ops = [];
    if (removed)
        ops.push(toOp('delete', file.from, removed, null));
    if (created)
        ops.push(toOp('add', file.path, created, file.sha));
    return ops;
}
function opsOf(file) {
    if (file.status === 'R')
        return opsOfRename(file);
    const loc = parseDraftFile(file.path);
    if (!loc)
        return [];
    if (file.status === 'A')
        return [toOp('add', file.path, loc, file.sha)];
    if (file.status === 'M')
        return [toOp('modify', file.path, loc, file.sha)];
    if (file.status === 'D')
        return [toOp('delete', file.path, loc, null)];
    throw new Error(`unsupported status ${file.status}`);
}
/** One operation per side of an l1, l2 or l3 diff entry. Anything else is left out. */
export function draftFileOps(files) {
    const ops = [];
    for (const file of files)
        ops.push(...opsOf(file));
    return ops;
}
async function postExec(body) {
    let response;
    try {
        response = await fetch('/exec', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    let parsed;
    try {
        parsed = await response.json();
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    if (!response.ok) {
        const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : `HTTP ${response.status}`;
        throw new Error(msg);
    }
    return parsed;
}
function draftDiffFile(item) {
    if (!isRecord(item) || typeof item.status !== 'string' || typeof item.path !== 'string') {
        throw new Error('draftDiff file entry is invalid');
    }
    if (item.sha !== null && typeof item.sha !== 'string')
        throw new Error('draftDiff file entry is invalid');
    if (item.from !== undefined && typeof item.from !== 'string')
        throw new Error('draftDiff file entry is invalid');
    const file = { status: item.status, path: item.path, sha: item.sha };
    if (typeof item.from === 'string')
        file.from = item.from;
    return file;
}
async function requestDraftDiff(project, slug) {
    const parsed = await postExec({ action: 'draftDiff', project, draft: slug, names: true });
    if (!isRecord(parsed) || parsed.status !== 'files' || typeof parsed.head !== 'string' || parsed.head.length === 0) {
        const code = isRecord(parsed) && typeof parsed.code === 'string' ? parsed.code : 'bad response';
        throw new Error(code);
    }
    if (!Array.isArray(parsed.files))
        throw new Error('draftDiff response has no files array');
    return { head: parsed.head, files: parsed.files.map(draftDiffFile) };
}
function defaultHasLocalEdit(project, path) {
    const loc = parseDraftFile(path);
    if (!loc) {
        console.error(`[studioDraftFiles] ${path}: local edit check is not an l1/l2/l3 file`);
        return false;
    }
    const base = {
        project,
        level: loc.level,
        shortName: loc.shortName,
        extension: loc.extension,
        folder: loc.folder,
    };
    const key = mls.stor.getKeyToFile(base);
    return mls.stor.files[key]?.inLocalStorage === true;
}
const defaultDeps = {
    draftDiff: requestDraftDiff,
    hasLocalEdit: defaultHasLocalEdit,
    addOrUpdateFile: (info) => mls.stor.addOrUpdateFile(info),
    fileKey: (info) => mls.stor.getKeyToFile(info),
    files: () => mls.stor.files,
};
async function applyOp(project, op, deps) {
    const base = {
        project,
        level: op.level,
        shortName: op.shortName,
        extension: op.extension,
        folder: op.folder,
    };
    const stored = deps.files();
    const key = deps.fileKey(base);
    if (op.action === 'delete') {
        delete stored[key];
        return 'removed';
    }
    if (!op.sha)
        throw new Error('missing sha');
    const existing = stored[key];
    if (op.action === 'modify' && existing) {
        existing.versionRef = op.sha;
        return 'changed';
    }
    await deps.addOrUpdateFile({ ...base, versionRef: op.sha });
    return 'added';
}
export async function applyDraftFiles(project, slug, deps = defaultDeps) {
    let diff;
    try {
        diff = await deps.draftDiff(project, slug);
    }
    catch (err) {
        console.error(`[studioDraftFiles] draftDiff: ${errorText(err)}`);
        return { added: 0, changed: 0, removed: 0 };
    }
    const counts = { added: 0, changed: 0, removed: 0 };
    for (const file of diff.files) {
        let ops;
        try {
            ops = draftFileOps([file]);
        }
        catch (err) {
            console.error(`[studioDraftFiles] ${file.path}: ${errorText(err)}`);
            continue;
        }
        for (const op of ops) {
            if (deps.hasLocalEdit(project, op.path)) {
                console.info(`[studioDraftFiles] ${op.path}: local edit kept`);
                continue;
            }
            try {
                const outcome = await applyOp(project, op, deps);
                counts[outcome] += 1;
            }
            catch (err) {
                console.error(`[studioDraftFiles] ${op.path}: ${errorText(err)}`);
            }
        }
    }
    return counts;
}
