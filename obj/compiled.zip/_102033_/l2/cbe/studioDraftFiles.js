/// <mls fileReference="_102033_/l2/cbe/studioDraftFiles.ts" enhancement="_blank" />
// Point the in-memory file list at the draft blobs from draftDiff.
// Memory only: do not call savePrjInfo, updateProjectFilesInfo or loadOtherProjectInfoIfNeeded,
// and do not change the project updated-at. The next login would overwrite these files.
export function sourceModelSlot(extension) {
    if (extension === '.ts')
        return 'ts';
    if (extension === '.test.ts')
        return 'test';
    if (extension === '.defs.ts')
        return 'defs';
    if (extension === '.html')
        return 'html';
    if (extension === '.less')
        return 'style';
    return undefined;
}
/**
 * Bytes `_checkSameContent` hashes. `.less` drops the token block and trims;
 * every other source file is hashed as stored.
 */
export function draftContentCrc(text, extension) {
    const source = extension === '.less'
        ? text.replace(/\/\/Start Less Tokens[\s\S]*?\/\/End Less Tokens/g, '').trim()
        : text;
    return mls.common.crc.crc32(source).toString(16);
}
/** CRC of the last draft send, per file. Not the published baseline. */
const sentCrc = new Map();
function sentCrcKey(file) {
    return `${file.project}\u0000${file.level}\u0000${file.folder}\u0000${file.shortName}\u0000${file.extension}`;
}
export function rememberSentCrc(file, crc) {
    sentCrc.set(sentCrcKey(file), crc);
}
export function sentCrcOf(file) {
    return sentCrc.get(sentCrcKey(file));
}
/** Window event: the unsaved count may have changed, and no file event fired. 102033 does not import the listener. */
export const COLLAB_DRAFT_RECOUNT = 'collabDraftRecount';
export function requestDraftRecount(project) {
    if (typeof project !== 'number' || project <= 0) {
        console.error('[studioDraftFiles] collabDraftRecount was not dispatched: project is missing');
        return;
    }
    const target = globalThis.window;
    if (!target || typeof target.dispatchEvent !== 'function') {
        console.error('[studioDraftFiles] collabDraftRecount was not dispatched: window is missing');
        return;
    }
    const detail = { project };
    try {
        target.dispatchEvent(new CustomEvent(COLLAB_DRAFT_RECOUNT, { detail }));
    }
    catch (err) {
        console.error('[studioDraftFiles] collabDraftRecount was not dispatched:', err);
    }
}
/** Studio entry has asked for the diff and has not finished seeding. Born false: no draft, no hold. */
let entrySeedOpen = false;
/** Only `enterStudioDraft` opens the hold, before its diff. Other `requestDraftDiff` callers (discard module) never do. */
export function beginDraftEntrySeed() {
    entrySeedOpen = true;
}
export function draftEntrySeedPending() {
    return entrySeedOpen;
}
/** Seeding finished, saved or failed. The recount is what publishes the cover, once. */
export function completeDraftEntrySeed(project) {
    if (!entrySeedOpen)
        return;
    entrySeedOpen = false;
    requestDraftRecount(project);
}
/** Window event after a draft restore was accepted. Same name the panel already emits. */
export const COLLAB_DRAFT_DISCARDED = 'collabDraftDiscarded';
/** Paths last seen in this tab's draft. Undo of a local copy uses this to tell a saved file from a browser-only one. */
const draftPaths = new Set();
function draftPathKey(project, path) {
    return `${project}\u0000${path}`;
}
export function rememberDraftPaths(project, paths) {
    for (const path of paths) {
        if (path.length === 0)
            continue;
        draftPaths.add(draftPathKey(project, path));
    }
}
export function forgetDraftPaths(project, paths) {
    for (const path of paths)
        draftPaths.delete(draftPathKey(project, path));
}
export function draftPathIsSaved(project, path) {
    return draftPaths.has(draftPathKey(project, path));
}
let browserOnlyUndo = 0;
/** True while Discard module is clearing local copies. Those undos must not call the server again. */
export function draftUndoBrowserOnly() {
    return browserOnlyUndo > 0;
}
export async function withDraftUndoBrowserOnly(body) {
    browserOnlyUndo += 1;
    try {
        return await body();
    }
    finally {
        browserOnlyUndo -= 1;
    }
}
const DRAFT_SLUG_RE = /^(team|user)-([a-z0-9_.-]{1,64})$/;
function dispatchDraftDiscarded(project, paths) {
    const target = globalThis.window;
    if (!target || typeof target.dispatchEvent !== 'function') {
        console.error('[studioDraftFiles] collabDraftDiscarded was not dispatched: window is missing');
        return;
    }
    const detail = { project, before: [...paths], after: [] };
    try {
        target.dispatchEvent(new CustomEvent(COLLAB_DRAFT_DISCARDED, { detail }));
    }
    catch (err) {
        console.error('[studioDraftFiles] collabDraftDiscarded was not dispatched:', err);
    }
}
/**
 * One `draftRestorePaths` for every path, then the browser copy, one recount, one preview reload.
 * A server refusal throws before `afterRestore`, so the browser stays as it was.
 */
export async function undoDraftPaths(project, slug, paths, afterRestore, fetchImpl) {
    if (paths.length === 0 || paths.some((path) => path.trim() === '')) {
        console.error('[studioDraftFiles] undo path is empty');
        throw new Error('undo path is empty');
    }
    if (!DRAFT_SLUG_RE.test(slug)) {
        console.error(`[studioDraftFiles] undo draft slug is invalid: ${slug}`);
        throw new Error(`undo draft slug is invalid: ${slug}`);
    }
    const fetchFn = fetchImpl ?? ((input, init) => fetch(input, init));
    let response;
    try {
        response = await fetchFn('/exec', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'draftRestorePaths',
                project,
                draft: slug,
                ref: 'main',
                paths: [...paths],
            }),
        });
    }
    catch (err) {
        const message = errorText(err);
        console.error(`[studioDraftFiles] draftRestorePaths: ${message}`);
        throw new Error(message);
    }
    let parsed;
    try {
        parsed = await response.json();
    }
    catch (err) {
        const message = errorText(err);
        console.error(`[studioDraftFiles] draftRestorePaths: ${message}`);
        throw new Error(message);
    }
    if (!isRecord(parsed)) {
        console.error('[studioDraftFiles] draftRestorePaths response was not a JSON object');
        throw new Error('response was not a JSON object');
    }
    if (typeof parsed.code === 'string') {
        const message = typeof parsed.msg === 'string' ? parsed.msg : parsed.code;
        console.error(`[studioDraftFiles] draftRestorePaths: ${message}`);
        throw new Error(message);
    }
    if (parsed.status !== 'restored' && parsed.status !== 'unchanged') {
        const message = typeof parsed.status === 'string' ? parsed.status : 'draftRestorePaths failed';
        console.error(`[studioDraftFiles] draftRestorePaths: ${message}`);
        throw new Error(message);
    }
    try {
        await afterRestore();
    }
    catch (err) {
        const message = errorText(err);
        console.error(`[studioDraftFiles] draftRestorePaths accepted but the browser copy stayed: ${message}`);
        throw err instanceof Error ? err : new Error(message);
    }
    forgetDraftPaths(project, paths);
    requestDraftRecount(project);
    dispatchDraftDiscarded(project, paths);
}
/** Published commit from the last draftDiff. Undo reads it to load the published blob. */
let publishedCommit;
export function draftPublishedCommit() {
    return publishedCommit;
}
/** Keep a non-empty main. An empty value does not wipe a commit already stored. */
export function rememberDraftMain(main) {
    if (main.length === 0) {
        console.error('[studioDraftFiles] draftDiff main is empty');
        return;
    }
    publishedCommit = main;
}
function errorText(err) {
    return err instanceof Error ? err.message : String(err);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/** `l2/cbe/studioDraftFiles.ts` → level, folder, short name, extension. Other paths → undefined. */
function parseDraftFile(path) {
    const layer = path.startsWith('l1/') ? 1 : path.startsWith('l2/') ? 2 : path.startsWith('l3/') ? 3 : 0;
    if (layer === 0)
        return undefined;
    const rest = path.slice(3);
    if (rest.length === 0 || rest.startsWith('/') || rest.endsWith('/'))
        return undefined;
    const slash = rest.lastIndexOf('/');
    const folder = slash === -1 ? '' : rest.slice(0, slash);
    const filename = slash === -1 ? rest : rest.slice(slash + 1);
    if (!filename || (slash !== -1 && !folder))
        return undefined;
    // First dot, same split as parseStorFileName (static/libs/mls.js:3568).
    const dot = filename.indexOf('.');
    if (dot < 0)
        return { level: layer, folder, shortName: filename, extension: '' };
    const shortName = filename.slice(0, dot);
    if (!shortName)
        return undefined;
    return { level: layer, folder, shortName, extension: filename.slice(dot) };
}
function toOp(action, path, loc, sha) {
    return {
        action,
        path,
        level: loc.level,
        folder: loc.folder,
        shortName: loc.shortName,
        extension: loc.extension,
        sha,
    };
}
function opsOfRename(file) {
    const created = parseDraftFile(file.path);
    if (typeof file.from !== 'string' || file.from.length === 0) {
        if (!created)
            return [];
        throw new Error('rename without from');
    }
    const removed = parseDraftFile(file.from);
    if (!removed && !created)
        return [];
    const ops = [];
    if (removed)
        ops.push(toOp('delete', file.from, removed, null));
    if (created)
        ops.push(toOp('add', file.path, created, file.sha));
    return ops;
}
function opsOf(file) {
    if (file.status === 'R')
        return opsOfRename(file);
    const loc = parseDraftFile(file.path);
    if (!loc)
        return [];
    if (file.status === 'A')
        return [toOp('add', file.path, loc, file.sha)];
    if (file.status === 'M')
        return [toOp('modify', file.path, loc, file.sha)];
    if (file.status === 'D')
        return [toOp('delete', file.path, loc, null)];
    throw new Error(`unsupported status ${file.status}`);
}
/** One operation per side of an l1, l2 or l3 diff entry. Anything else is left out. */
export function draftFileOps(files) {
    const ops = [];
    for (const file of files)
        ops.push(...opsOf(file));
    return ops;
}
async function postExec(body) {
    let response;
    try {
        response = await fetch('/exec', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    let parsed;
    try {
        parsed = await response.json();
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    if (!response.ok) {
        const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : `HTTP ${response.status}`;
        throw new Error(msg);
    }
    return parsed;
}
function draftDiffFile(item) {
    if (!isRecord(item) || typeof item.status !== 'string' || typeof item.path !== 'string') {
        throw new Error('draftDiff file entry is invalid');
    }
    if (item.sha !== null && typeof item.sha !== 'string')
        throw new Error('draftDiff file entry is invalid');
    if (item.from !== undefined && typeof item.from !== 'string')
        throw new Error('draftDiff file entry is invalid');
    const file = { status: item.status, path: item.path, sha: item.sha };
    if (typeof item.from === 'string')
        file.from = item.from;
    return file;
}
export async function requestDraftDiff(project, slug) {
    const parsed = await postExec({ action: 'draftDiff', project, draft: slug, names: true });
    if (!isRecord(parsed) || parsed.status !== 'files' || typeof parsed.head !== 'string' || parsed.head.length === 0) {
        const code = isRecord(parsed) && typeof parsed.code === 'string' ? parsed.code : 'bad response';
        throw new Error(code);
    }
    if (!Array.isArray(parsed.files))
        throw new Error('draftDiff response has no files array');
    const files = parsed.files.map(draftDiffFile);
    // The list and the source do not need main; only the undo does, and it reports the gap itself.
    if (typeof parsed.main !== 'string' || parsed.main.length === 0) {
        console.error('[studioDraftFiles] draftDiff response has no main; undo cannot find the published version');
        return { head: parsed.head, files };
    }
    rememberDraftMain(parsed.main);
    return { head: parsed.head, main: parsed.main, files };
}
function defaultHasLocalEdit(project, path) {
    const loc = parseDraftFile(path);
    if (!loc) {
        console.error(`[studioDraftFiles] ${path}: local edit check is not an l1/l2/l3 file`);
        return false;
    }
    const base = {
        project,
        level: loc.level,
        shortName: loc.shortName,
        extension: loc.extension,
        folder: loc.folder,
    };
    const key = mls.stor.getKeyToFile(base);
    return mls.stor.files[key]?.inLocalStorage === true;
}
const defaultDeps = {
    draftDiff: requestDraftDiff,
    hasLocalEdit: defaultHasLocalEdit,
    addOrUpdateFile: (info) => mls.stor.addOrUpdateFile(info),
    fileKey: (info) => mls.stor.getKeyToFile(info),
    files: () => mls.stor.files,
};
function draftStorStatus(gitStatus) {
    if (gitStatus === 'A')
        return 'new';
    if (gitStatus === 'M')
        return 'changed';
    if (gitStatus === 'R')
        return 'renamed';
    return undefined;
}
function asStoredFile(value) {
    if (typeof value !== 'object' || value === null)
        return undefined;
    if (typeof value.versionRef !== 'string')
        return undefined;
    return value;
}
function writeDraftStatus(op, row, status) {
    if (!status) {
        console.error(`[studioDraftFiles] ${op.path}: no draft status to store`);
        return;
    }
    if (!row) {
        console.error(`[studioDraftFiles] ${op.path}: no stored row for status ${status}`);
        return;
    }
    row.status = status;
}
async function applyOp(project, op, deps, status) {
    const base = {
        project,
        level: op.level,
        shortName: op.shortName,
        extension: op.extension,
        folder: op.folder,
    };
    const stored = deps.files();
    const key = deps.fileKey(base);
    if (op.action === 'delete') {
        delete stored[key];
        return 'removed';
    }
    if (!op.sha)
        throw new Error('missing sha');
    const existing = stored[key];
    if (op.action === 'modify' && existing) {
        existing.versionRef = op.sha;
        writeDraftStatus(op, existing, status);
        return 'changed';
    }
    const created = asStoredFile(await deps.addOrUpdateFile({ ...base, versionRef: op.sha }));
    writeDraftStatus(op, created ?? deps.files()[key], status);
    return 'added';
}
function identityOf(project, loc) {
    return {
        project,
        level: loc.level,
        shortName: loc.shortName,
        extension: loc.extension,
        folder: loc.folder,
    };
}
function rowAt(project, path, deps) {
    const loc = parseDraftFile(path);
    if (!loc)
        return undefined;
    return deps.files()[deps.fileKey(identityOf(project, loc))];
}
/** Original `getValueInfo` under our wrapper, or null when the wrapper had none. */
const pinBase = new WeakMap();
/**
 * `_createModel` keeps `info.originalCRC` only when `info.content` is set, and it
 * reads `getValueInfo` before replacing it. Return the draft text with the published CRC.
 */
function installPublishedCrc(row, crc, path) {
    const current = row.getValueInfo;
    const known = current ? pinBase.get(current) : undefined;
    const base = known !== undefined ? known ?? undefined : current?.bind(row);
    const readContent = row.getContent?.bind(row);
    const pinned = async () => {
        let info;
        try {
            info = base ? await base() : undefined;
        }
        catch (err) {
            console.error(`[studioDraftFiles] ${path}: ${errorText(err)}`);
            return undefined;
        }
        if (info?.content)
            return { ...info, originalCRC: crc };
        let loaded = null;
        try {
            loaded = readContent ? await readContent() : null;
        }
        catch (err) {
            console.error(`[studioDraftFiles] ${path}: ${errorText(err)}`);
        }
        if (typeof loaded !== 'string' || loaded.length === 0) {
            console.error(`[studioDraftFiles] ${path}: published baseline has no draft text to keep`);
            return { content: null, originalCRC: crc };
        }
        return { content: loaded, originalCRC: crc };
    };
    pinBase.set(pinned, base ?? null);
    row.getValueInfo = pinned;
}
function assignOpenModel(project, loc, crc) {
    const slot = sourceModelSlot(loc.extension);
    if (!slot)
        return;
    const editor = mls.editor;
    if (!editor?.getKeyModel || !editor.models)
        return;
    try {
        const key = editor.getKeyModel(project, loc.shortName, loc.folder, loc.level);
        const model = editor.models[key]?.[slot];
        if (!model)
            return;
        model.originalCRC = crc;
    }
    catch (err) {
        console.error(`[studioDraftFiles] ${loc.shortName}: could not set the published CRC`, err);
    }
}
function plantPublishedCrc(project, path, text, deps) {
    const loc = parseDraftFile(path);
    const row = rowAt(project, path, deps);
    if (!loc || !row) {
        console.error(`[studioDraftFiles] ${path}: no stored row for the published baseline`);
        return;
    }
    let crc;
    try {
        crc = draftContentCrc(text, loc.extension);
    }
    catch (err) {
        console.error(`[studioDraftFiles] ${path}: ${errorText(err)}`);
        return;
    }
    installPublishedCrc(row, crc, path);
    assignOpenModel(project, loc, crc);
}
/** One driver getContents call covers at most this many paths. */
const DRAFT_CONTENT_BATCH = 100;
/** Draft reads omit `ref`. Published reads pass the commit of main. */
async function readContents(project, fileInfos, ref) {
    const driver = await mls.stor.others.getDefaultDriver(project);
    const read = driver.getContents;
    if (ref === undefined)
        return await read(project, fileInfos);
    return await read(project, fileInfos, ref);
}
function sentCrcTarget(project, path, deps) {
    const loc = parseDraftFile(path);
    const row = rowAt(project, path, deps);
    if (!loc || !row || !row.getContent)
        return undefined;
    return { path, loc, row };
}
function contentRequest(project, target) {
    const row = target.row;
    if (row.level === target.loc.level
        && row.folder === target.loc.folder
        && row.shortName === target.loc.shortName
        && row.extension === target.loc.extension) {
        return target.row;
    }
    const request = {
        project,
        level: target.loc.level,
        folder: target.loc.folder,
        shortName: target.loc.shortName,
        extension: target.loc.extension,
        versionRef: target.row.versionRef,
    };
    return request;
}
function fileRequest(project, loc) {
    const request = {
        project,
        level: loc.level,
        folder: loc.folder,
        shortName: loc.shortName,
        extension: loc.extension,
        versionRef: '',
    };
    return request;
}
function rememberLoadedCrc(project, target, loaded) {
    if (typeof loaded !== 'string') {
        console.error(`[studioDraftFiles] ${target.path}: draft text is not a string`);
        return;
    }
    try {
        rememberSentCrc(identityOf(project, target.loc), draftContentCrc(loaded, target.loc.extension));
    }
    catch (err) {
        console.error(`[studioDraftFiles] ${target.path}: ${errorText(err)}`);
    }
}
/** Draft text for the sent CRC, one getContents per batch. A failed batch is logged and skipped. */
async function seedSentCrcs(project, targets) {
    for (let start = 0; start < targets.length; start += DRAFT_CONTENT_BATCH) {
        const batch = targets.slice(start, start + DRAFT_CONTENT_BATCH);
        const paths = batch.map((target) => target.path).join(', ');
        const fileInfos = batch.map((target) => contentRequest(project, target));
        let loaded;
        try {
            loaded = await readContents(project, fileInfos);
        }
        catch (err) {
            console.error(`[studioDraftFiles] ${paths}: ${errorText(err)}`);
            continue;
        }
        const byInfo = new Map();
        for (const item of loaded ?? [])
            byInfo.set(item.fileInfo, item.content);
        for (let index = 0; index < batch.length; index++) {
            rememberLoadedCrc(project, batch[index], byInfo.get(fileInfos[index]));
        }
    }
    if (!draftEntrySeedPending())
        requestDraftRecount(project);
}
/** M/R files whose published blob is read at `main`. A rename reads `from`. */
function publishedReads(files, main) {
    const reads = [];
    for (const file of files) {
        if (file.status !== 'M' && file.status !== 'R')
            continue;
        if (!parseDraftFile(file.path))
            continue;
        const publishedPath = file.status === 'R' && file.from ? file.from : file.path;
        const loc = parseDraftFile(publishedPath);
        if (!loc) {
            console.error(`[studioDraftFiles] ${file.path}: published content is missing at ${main}`);
            continue;
        }
        reads.push({ file, loc });
    }
    return reads;
}
/** Published text for every M/R, one getContents per batch, before any row is removed. */
async function loadPublishedTexts(project, reads, main) {
    const texts = new Map();
    for (let start = 0; start < reads.length; start += DRAFT_CONTENT_BATCH) {
        const batch = reads.slice(start, start + DRAFT_CONTENT_BATCH);
        const paths = batch.map((read) => read.file.path).join(', ');
        const fileInfos = batch.map((read) => fileRequest(project, read.loc));
        let loaded;
        try {
            loaded = await readContents(project, fileInfos, main);
        }
        catch (err) {
            console.error(`[studioDraftFiles] ${paths}: ${errorText(err)}`);
            continue;
        }
        const byInfo = new Map();
        for (const item of loaded ?? [])
            byInfo.set(item.fileInfo, item.content);
        for (let index = 0; index < batch.length; index++) {
            const text = byInfo.get(fileInfos[index]);
            if (typeof text !== 'string') {
                console.error(`[studioDraftFiles] ${batch[index].file.path}: published content is missing at ${main}`);
                continue;
            }
            texts.set(batch[index].file, text);
        }
    }
    return texts;
}
/** l1/l2/l3 browser copies that are not a side of this draftDiff. */
function outsideLocals(project, rows, inDiff) {
    const found = [];
    for (const row of Object.values(rows)) {
        if (!row || row.project !== project || row.inLocalStorage !== true)
            continue;
        if (row.level !== 1 && row.level !== 2 && row.level !== 3)
            continue;
        if (typeof row.shortName !== 'string' || row.shortName.length === 0 || typeof row.folder !== 'string' || typeof row.extension !== 'string') {
            console.error('[studioDraftFiles] local copy has no path');
            continue;
        }
        const folder = row.folder.length > 0 ? `${row.folder}/` : '';
        const path = `l${row.level}/${folder}${row.shortName}${row.extension}`;
        if (inDiff.has(path))
            continue;
        if (!parseDraftFile(path)) {
            console.error(`[studioDraftFiles] ${path}: local copy is not an l1/l2/l3 file`);
            continue;
        }
        found.push({ path, row });
    }
    found.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
    return found;
}
async function localCopyText(path, row) {
    if (!row.getValueInfo) {
        console.error(`[studioDraftFiles] ${path}: local copy has no getValueInfo`);
        return undefined;
    }
    try {
        const info = await row.getValueInfo();
        if (typeof info?.content !== 'string') {
            console.error(`[studioDraftFiles] ${path}: local copy is not text`);
            return undefined;
        }
        return info.content;
    }
    catch (err) {
        console.error(`[studioDraftFiles] ${path}: ${errorText(err)}`);
        return undefined;
    }
}
/** IndexedDB row gone, and the file is no longer "edited". */
async function clearLocalCopy(path, row) {
    const setContent = mls.stor.localStor?.setContent;
    if (typeof setContent !== 'function') {
        console.error(`[studioDraftFiles] ${path}: localStor.setContent is missing`);
        return;
    }
    try {
        const stored = await setContent(row, { contentType: 'string', content: null });
        if (stored === false) {
            console.error(`[studioDraftFiles] ${path}: local copy was not cleared`);
            return;
        }
    }
    catch (err) {
        console.error(`[studioDraftFiles] ${path}: ${errorText(err)}`);
        return;
    }
    row.inLocalStorage = false;
    row.status = 'nochange';
}
/**
 * A local copy that matches `main` and is absent from the draft is the published file.
 * One that is still in the draft stays: undo keeps that copy until the draft comes back.
 */
async function dropLocalsEqualToPublished(project, files, main, deps) {
    const inDiff = new Set();
    for (const file of files) {
        inDiff.add(file.path);
        if (typeof file.from === 'string' && file.from.length > 0)
            inDiff.add(file.from);
    }
    const copies = outsideLocals(project, deps.files(), inDiff);
    const comparable = [];
    const locals = new Map();
    for (const copy of copies) {
        const text = await localCopyText(copy.path, copy.row);
        if (text === undefined)
            continue;
        locals.set(copy.path, text);
        comparable.push(copy);
    }
    if (comparable.length === 0)
        return;
    const asDiff = comparable.map((copy) => ({ status: 'M', path: copy.path, sha: null }));
    const published = await loadPublishedTexts(project, publishedReads(asDiff, main), main);
    const publishedByPath = new Map();
    for (const file of asDiff) {
        const text = published.get(file);
        if (typeof text === 'string')
            publishedByPath.set(file.path, text);
    }
    for (const copy of comparable) {
        const onMain = publishedByPath.get(copy.path);
        if (onMain === undefined || onMain !== locals.get(copy.path))
            continue;
        await clearLocalCopy(copy.path, copy.row);
    }
}
export async function applyDraftFiles(project, slug, deps = defaultDeps, known) {
    try {
        return await applyDraftFilesNow(project, slug, deps, known);
    }
    catch (err) {
        console.error(`[studioDraftFiles] draft seed failed: ${errorText(err)}`);
        throw err;
    }
    finally {
        if (draftEntrySeedPending())
            completeDraftEntrySeed(project);
    }
}
async function applyDraftFilesNow(project, slug, deps, known) {
    let diff;
    if (known) {
        diff = known;
    }
    else {
        try {
            diff = await deps.draftDiff(project, slug);
        }
        catch (err) {
            console.error(`[studioDraftFiles] draftDiff: ${errorText(err)}`);
            return { added: 0, changed: 0, removed: 0 };
        }
    }
    if (typeof diff.main === 'string')
        rememberDraftMain(diff.main);
    const noted = [];
    for (const file of diff.files) {
        noted.push(file.path);
        if (typeof file.from === 'string' && file.from.length > 0)
            noted.push(file.from);
    }
    rememberDraftPaths(project, noted);
    const counts = { added: 0, changed: 0, removed: 0 };
    const sentTargets = [];
    // Read every published blob first. A rename's applyOp deletes the origin row.
    const published = diff.main
        ? await loadPublishedTexts(project, publishedReads(diff.files, diff.main), diff.main)
        : new Map();
    for (const file of diff.files) {
        let ops;
        try {
            ops = draftFileOps([file]);
        }
        catch (err) {
            console.error(`[studioDraftFiles] ${file.path}: ${errorText(err)}`);
            continue;
        }
        for (const op of ops) {
            if (deps.hasLocalEdit(project, op.path)) {
                console.info(`[studioDraftFiles] ${op.path}: local edit kept`);
                continue;
            }
            try {
                const outcome = await applyOp(project, op, deps, draftStorStatus(file.status));
                counts[outcome] += 1;
            }
            catch (err) {
                console.error(`[studioDraftFiles] ${op.path}: ${errorText(err)}`);
            }
        }
        const text = published.get(file);
        if (typeof text !== 'string')
            continue;
        plantPublishedCrc(project, file.path, text, deps);
        const target = sentCrcTarget(project, file.path, deps);
        if (target)
            sentTargets.push(target);
    }
    if (typeof diff.main === 'string' && diff.main.length > 0) {
        await dropLocalsEqualToPublished(project, diff.files, diff.main, deps);
    }
    await seedSentCrcs(project, sentTargets);
    return counts;
}
