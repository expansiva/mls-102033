/// <mls fileReference="_102033_/l2/cbe/studioExitReload.ts" enhancement="_blank" />
import { readRelease as pingRelease } from '/_102033_/l2/cbe/releaseInfo.js';
import { readDraftCookie } from '/_102033_/l2/cbe/studioDraft.js';
export function studioReleaseId(id) {
    return { id };
}
/** True only when both sides have an id and they differ. A missing id is not a change. */
export function shouldReload(before, now) {
    if (before === null || now === null)
        return false;
    return before.id !== now.id;
}
let readRelease = null;
let captured = null;
/** Store the reader and the entry ping. Exit awaits this promise, so a fast toggle still sees the entry id. */
export function rememberRelease(read) {
    readRelease = read;
    const pending = Promise.resolve().then(read);
    captured = pending.then((release) => release, (error) => {
        console.warn('studio: failed to read the release on enter', error);
        return null;
    });
    return captured;
}
/** `/desenv/sair?to=<path>` when a draft cookie is set; null when the page is already on production. */
export function leaveDraftUrl(cookieString, path) {
    if (readDraftCookie(cookieString) === undefined)
        return null;
    return '/desenv/sair?to=' + encodeURIComponent(path);
}
/** Fresh ping against the entry id. Reload only when they differ; a failed ping warns and does not reload.
 *  With a draft cookie, navigate to `/desenv/sair` instead: that response already loads the current release. */
export async function onStudioExit(reload, leave) {
    if (leave !== undefined) {
        const url = leaveDraftUrl(leave.cookie, leave.path);
        if (url !== null) {
            leave.navigate(url);
            return;
        }
    }
    const read = readRelease;
    const beforePromise = captured;
    if (read === null || beforePromise === null) {
        console.warn('studio: exit without a remembered release; not reloading');
        return;
    }
    const before = await beforePromise;
    let now;
    try {
        now = await read();
    }
    catch (error) {
        console.warn('studio: ping failed on exit; not reloading', error);
        return;
    }
    if (shouldReload(before, now))
        reload();
}
/** Current release id from the same ping `collabRelease` exposes (`readRelease`). */
export async function readCollabReleaseId() {
    const id = (await pingRelease()).release?.id;
    return typeof id === 'string' ? studioReleaseId(id) : null;
}
