/// <mls fileReference="_102033_/l2/cbe/driverVm.ts" enhancement="_blank" />
// Storage driver that reads and writes project SOURCES from the runtime VM
// instead of a git host. It answers the cfe's cache misses over the cbe /exec
// endpoint of the very server that serves this page (same origin, session by
// cookie) — no network call ever leaves the VM.
//
// SLOTS
// The driver's own slot is 'vm'. registerVmDriver registers only there: the
// login (mls-102034/cbeLogin.ts) marks every VM project's projectDriver as
// 'vm', including ones with no declared projectSettings, so getDefaultDriver
// always resolves through this slot — no more borrowing 'github'.
//
// WHY THE SOURCES ARE NEEDED AT ALL
// The login payload carries `jsContent` (compiled js), NOT the .ts source. So
// running modules works from cache, but opening a file in the editor or an
// agent reading/writing a .ts always misses and lands here.
//
// LOADING: this module extends a class that only exists at runtime
// (mls.stor.others.DriverIOBase), so it MUST be imported dynamically, after
// window.mls is up — never with a static import.
const EXEC_URL = '/exec';
/** Same-origin page that shows one source file — see getUrl. */
const SOURCE_VIEW_URL = '/cbe/source';
/**
 * Repository path of a file: `l<level>/<folder>/<shortName><extension>`.
 * Same construction the GitHub driver uses, so both drivers address a file
 * identically (level 0 has no prefix; the extension may come without the dot).
 */
export function toShortPath(fileInfo) {
    const folderSep = fileInfo.folder === '' || fileInfo.folder.endsWith('/') ? '' : '/';
    const extSep = fileInfo.extension.startsWith('.') ? '' : '.';
    const levelPath = fileInfo.level === 0 ? '' : `l${fileInfo.level}/`;
    return `${levelPath}${fileInfo.folder.replace(/\\/gu, '/')}${folderSep}${fileInfo.shortName}${extSep}${fileInfo.extension}`;
}
async function execAction(action, payload) {
    const response = await fetch(EXEC_URL, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...payload }),
    });
    if (!response.ok)
        throw new Error(`cbe ${action} failed: HTTP ${response.status}`);
    return await response.json();
}
export class DriverVm extends mls.stor.others.DriverIOBase {
    constructor() {
        super();
        /** Diagnostic label only (DriverIOBase.shortName is typed mls.cbe.Provider, which has
         * no 'vm' member) — actual slot registration is by the 'vm' string key passed to
         * addDriver in registerVmDriver, not by this field. Kept as 'github' only because the
         * abstract type requires a value from mls.cbe.Provider. */
        this.shortName = 'github';
        /** Not bound to a single project: it serves every project the VM hosts. */
        this.project = 0;
        this.driverVersion = '1.0.0-vm';
        // ── Implemented ───────────────────────────────────────────────────────────
        this.getContents = async (project, fileInfos) => {
            if (fileInfos.length === 0)
                return [];
            // The contract guarantees a single project per call — one request, not one per file.
            const byShortPath = new Map();
            for (const fileInfo of fileInfos)
                byShortPath.set(toShortPath(fileInfo), fileInfo);
            const rc = await execAction('getContents', {
                project,
                shortPaths: [...byShortPath.keys()],
            });
            if (rc.statusCode !== 200)
                throw new Error(`getContents: ${rc.msg || 'error'}`);
            const contents = new Map();
            for (const file of rc.files ?? []) {
                contents.set(file.shortPath, file.encoding === 'base64' ? atob(file.content) : file.content);
            }
            // The cfe matches results by object identity: return the SAME fileInfo it handed us.
            // A file the VM does not have comes back as null — that is "absent", not "failed".
            return [...byShortPath.entries()].map(([shortPath, fileInfo]) => ({
                fileInfo,
                content: contents.has(shortPath) ? contents.get(shortPath) : null,
            }));
        };
        this.setContents = async (project, fileInfos, _comments) => {
            if (fileInfos.length === 0)
                return true;
            const files = [];
            const deletes = [];
            for (const fileInfo of fileInfos) {
                const shortPath = toShortPath(fileInfo);
                if (fileInfo.status === 'deleted') {
                    deletes.push(shortPath);
                    continue;
                }
                if (fileInfo.status === 'renamed') {
                    // Write the new path and drop the old one — the rename origin lives in getValueInfo.
                    const info = fileInfo.getValueInfo ? await fileInfo.getValueInfo() : undefined;
                    // No original name = nothing provable to delete; writing the new path alone
                    // leaves a stale copy, but inventing a path to remove is worse.
                    if (info?.originalShortName) {
                        const originalFolder = (info.originalFolder || '').replace(/\\/gu, '/');
                        deletes.push(toShortPath({ ...fileInfo, folder: originalFolder, shortName: info.originalShortName }));
                    }
                }
                const payload = await this.readFilePayload(fileInfo, shortPath);
                if (payload)
                    files.push(payload);
            }
            if (files.length === 0 && deletes.length === 0)
                return true;
            const rc = await execAction('setContents', { project, files, deletes });
            if (rc.statusCode !== 200)
                throw new Error(`setContents: ${rc.msg || 'error'}`);
            return true;
        };
        if (mls.istrace)
            console.info(`vmDriver: ${this.driverVersion}`);
    }
    /**
     * Commits that touched the file, newest first — read from the project's git
     * repo on the VM (every mls-<id> there is one; see gitReposSetup.mjs).
     *
     * CAVEAT: studio saves write the tree without committing, so this lists the
     * PUBLISH history, not the edits made here. That is the honest answer today;
     * commit-on-save is a separate decision.
     *
     * Returns null only when the call itself failed — the UI reads null and an
     * empty list the same way, but null keeps "broke" distinct from "no commits".
     */
    async getHistory(fileInfo) {
        // A file that was never saved has nothing in git, and asking costs a round trip.
        if (fileInfo.status === 'new')
            return [];
        try {
            const rc = await execAction('getHistory', {
                project: fileInfo.project,
                shortPath: toShortPath(fileInfo),
            });
            if (rc.statusCode !== 200)
                return null;
            return (rc.history ?? []).map((entry) => ({
                authorName: entry.authorName,
                // No avatars on the VM; mlsHistoryList falls back to a generic icon when empty.
                authorUrl: '',
                data: new Date(entry.date),
                ref: entry.ref,
                message: entry.message,
                additions: entry.additions,
                deletions: entry.deletions,
            }));
        }
        catch {
            // The history panel is an accessory — a failure here must not break the editor.
            return null;
        }
    }
    /** The file's content at one commit of getHistory, for the side-by-side diff. */
    async getHistoryContent(fileInfo, ref) {
        try {
            const rc = await execAction('getHistoryContent', {
                project: fileInfo.project,
                shortPath: toShortPath(fileInfo),
                ref,
            });
            if (rc.statusCode !== 200)
                return null;
            return rc.content ?? null;
        }
        catch {
            return null;
        }
    }
    async loadFilesInfo(project) {
        const rc = await execAction('loadFilesInfo', { project });
        if (rc.statusCode !== 200)
            throw new Error(`loadFilesInfo: ${rc.msg || 'error'}`);
        return rc.filesInfo ?? [];
    }
    /**
     * Content to persist, read the same way the GitHub driver does: force
     * inLocalStorage so getContent serves the LOCAL edit — otherwise a cache miss
     * would call this very driver back — and restore the flag afterwards.
     */
    async readFilePayload(fileInfo, shortPath) {
        const previous = fileInfo.inLocalStorage;
        fileInfo.inLocalStorage = true;
        let content = null;
        try {
            if (fileInfo.getValueInfo)
                content = (await fileInfo.getValueInfo()).content ?? null;
            if (content === null)
                content = await fileInfo.getContent();
        }
        finally {
            fileInfo.inLocalStorage = previous;
        }
        if (content === null)
            return null;
        if (typeof content === 'string')
            return { shortPath, content, encoding: 'utf8' };
        const buffer = new Uint8Array(await content.arrayBuffer());
        let binary = '';
        for (const byte of buffer)
            binary += String.fromCharCode(byte);
        return { shortPath, content: btoa(binary), encoding: 'base64' };
    }
    /**
     * Where the editor's "View on repository" goes. On the VM the repository IS
     * the VM, so this points at the cbe's own source view, which reads the same
     * tree getContents reads.
     *
     * getUrl is SYNCHRONOUS by contract, so whatever it returns has to be
     * derivable here, without a round trip — which rules out asking the server
     * for a real git remote. A same-origin url is the only honest answer.
     *
     * Uses toShortPath, so the level is part of the path: the GitHub driver
     * hardcodes `/l2/` and therefore points an l1 file at a path that does not
     * exist.
     */
    getUrl(file) {
        if (!file?.project)
            return '';
        return `${SOURCE_VIEW_URL}?project=${file.project}&path=${encodeURIComponent(toShortPath(file))}`;
    }
    // ── Not supported on the VM ───────────────────────────────────────────────
    // Branches and pull requests belong to a git host: the VM has the repository
    // but no notion of review. They return the "nothing here" value of their
    // contract instead of throwing, so the studio UI degrades quietly rather than
    // breaking on a feature that does not exist here. (History and getUrl are NOT
    // in this list — both are served by the VM itself, above.)
    async getVersionFromFiles() { return undefined; }
    async checkBranchExistence() { return false; }
    async reviewPullRequest() { return false; }
    async listPullRequests() { return []; }
    async listForks() { return []; }
    async listBranches() { return []; }
    async getUserInfo() { return {}; }
    async getOrganizations() { return []; }
    async createRepository() { return false; }
    async deleteRepository() { return false; }
    async createFork() { return false; }
    async renameRepository() { return false; }
    async createFileInRepo() { return false; }
    async changeVisibility() { return false; }
    async verifyRepositoryNew() { return 'error'; }
    async verifyPermission() { return {}; }
    async addVariable() { return false; }
    async updateVariable() { return false; }
    async listVariables() {
        return { variables: [], total_count: 0 };
    }
    async delVariable() { return false; }
    async checkFork() { return false; }
    // ── serviceSave's onSave() ceremony (fork/branch/PR) ──────────────────────
    // serviceSave.ts's fork+branch+pull-request flow treats a falsy return from
    // these as a hard failure and throws (it has no "not supported" case, unlike
    // the read/list methods above). The VM writes files directly — no fork,
    // branch or PR ever really happens — so these report success unconditionally
    // and let the flow fall through to onSavenewPullrequest's mls.stor.setContents,
    // which is the actual save (driverVm.setContents below).
    async checkForkIO() { return true; }
    async syncFork() { return true; }
    async createNewBranch() { return true; }
    async createPullRequest() { return true; }
}
