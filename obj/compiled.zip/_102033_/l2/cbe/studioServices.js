/// <mls fileReference="_102033_/l2/cbe/studioServices.ts" enhancement="_blank" />
// Service list the runtime nav1/nav2 consume. The runtime DECLARES the studio
// widgets it uses; it does not ask 100554's plugin index what exists.
export const STUDIO_BASE_PROJECT = 100554;
// Same shape CollabInit.anonymousServices uses: 8 levels, 'leftCsv;rightCsv'.
export const ANONYMOUS_SERVICES = ['', '', '', '', '', '', '', ';_100554_serviceDetail,'];
// The runtime pair hosted by the shared nav3s (studioStructure): messages left, app right.
export const SERVICE_MESSAGES = '_102033_/l2/cbe/serviceRuntimeMessages';
export const SERVICE_APP = '_102033_/l2/cbe/serviceClientApp';
// The runtime DECLARES the studio widgets it uses. It does not ask 100554's
// plugin index what exists: that is what brought 16 services (411 KB never
// mounted) into a client app.
export const RUNTIME_STUDIO_SERVICES = [
    '_100554_serviceDetail',
    '_100554_serviceReportBug',
];
// serviceSource/serviceUnit (level 2, both sides) and serviceSourceL1 (level 1, both sides) sit on
// BOTH sides of their level — RUNTIME_STUDIO_SERVICES can't express "one level, both sides" (it is
// always right-side/every-level), so these are declared instead in
// mls-102020/l2/pluginCollabCoreIndex.ts (scope: l<N>ServicesLeft + l<N>ServicesRight) and reach the
// runtime through the normal scan of 102020 (a real dependency of every Aura client). dropScannedStudio
// must let exactly these through even though they carry the _100554_ prefix, or the blanket 100554
// filter below strips them right back out.
const SCANNED_STUDIO_ALLOWLIST = new Set(['_100554_serviceSource', '_100554_serviceUnit', '_100554_serviceSourceL1', '_100554_serviceSave', '_100554_serviceProject', '_100554_serviceHistories', '_100554_serviceUser']);
function seedLastService(nav2, level, position, widget) {
    const state = nav2?.state_?.[level];
    if (state)
        state[position] = widget;
}
function dropScannedStudio(csv) {
    return csv.split(',').filter((widget) => widget
        && !widget.endsWith('serviceCollabMessages')
        && (SCANNED_STUDIO_ALLOWLIST.has(widget) || !widget.startsWith('_100554_'))).join(',');
}
/**
 * Adds the runtime service pair and the declared studio widgets to a scanned
 * list, per level. Declared studio widgets sit on the RIGHT of every level
 * (after the app service), matching the previous UI.
 *
 * BOTH toolbars need it — the content structure's nav2s and the studio header's — because they
 * drive the SAME nav3s. A toolbar without these entries strands the user: switching header
 * profile would leave no way back to the app or the messages.
 *
 * Also drops the studio's own serviceCollabMessages (on the VM it points at the
 * msg.collab.codes endpoints and blanks out — ours is the messages service here) and seeds each
 * nav2's last-service memory, so a level restore lands on the pair.
 */
export function withRuntimeServices(services, nav2Left, nav2Right) {
    const rc = [...services];
    const declaredRight = RUNTIME_STUDIO_SERVICES.join(',');
    for (let level = 0; level <= 7; level += 1) {
        const [rawLeft = '', rawRight = ''] = (rc[level] ?? ';').split(';');
        const left = dropScannedStudio(rawLeft);
        const right = dropScannedStudio(rawRight);
        rc[level] = `${SERVICE_MESSAGES}${left ? `,${left}` : ''};${SERVICE_APP},${declaredRight}${right ? `,${right}` : ''}`;
        seedLastService(nav2Left, level, 'left', SERVICE_MESSAGES);
        seedLastService(nav2Right, level, 'right', SERVICE_APP);
    }
    return rc;
}
function collectScanProjects(siteProject, mlsApi) {
    const projectList = [];
    const add = (project) => {
        if (!project || project === STUDIO_BASE_PROJECT || projectList.includes(project))
            return;
        projectList.push(project);
    };
    add(siteProject);
    try {
        for (const dep of mlsApi.l5?.getProjectDependencies?.(siteProject, false) ?? [])
            add(dep);
    }
    catch { /* dependencies are best-effort */ }
    return projectList;
}
/**
 * Menu actions per level/position from the site project and its dependencies.
 * Does not scan 100554 — studio widgets the runtime uses are declared in
 * RUNTIME_STUDIO_SERVICES and injected by withRuntimeServices.
 */
export async function buildStudioServices(siteProject, api = globalThis.mls) {
    if (!api?.plugin?.loadAll || !api.plugin.getAllMenuActions)
        return ANONYMOUS_SERVICES;
    const projectList = collectScanProjects(siteProject, api);
    for (const project of projectList) {
        await api.stor?.server?.loadProjectInfoIfNeeded?.(project);
        await api.plugin.loadAll(project, false);
    }
    const services = [];
    for (let level = 0; level <= 7; level += 1) {
        const byPosition = { Left: [], Right: [] };
        for (const position of ['Left', 'Right']) {
            const addedShortNames = new Set();
            for (const project of projectList) {
                const actions = api.plugin.getAllMenuActions(project, { scope: `l${level}Services${position}` }) ?? [];
                for (const action of actions.sort((a, b) => (a.priority || 1) - (b.priority || 1))) {
                    // Malformed menu actions produce requests like /_1_/l2/undefined.js —
                    // only widgets with a real project reference pass.
                    if (!action?.widget || !/^_\d{6,}_/u.test(action.widget))
                        continue;
                    const info = api.actual?.[0]?.setFullName(action.widget);
                    const shortName = info?.getStorFileBase?.()?.shortName || info?.path?.split('/').pop() || action.widget;
                    if (addedShortNames.has(shortName))
                        continue;
                    addedShortNames.add(shortName);
                    byPosition[position].push(action.widget);
                }
            }
        }
        services.push(`${byPosition.Left.join(',')};${byPosition.Right.join(',')}`);
    }
    const hasAny = services.some((entry) => entry !== ';');
    return hasAny ? services : ANONYMOUS_SERVICES;
}
// --- Editing tools (TASK-102033-studio-to-102020) ---
/**
 * Scope a plugin uses to declare a module that plugs into the app's edit slot.
 *
 * Same channel the services use (`getAllMenuActions`), on a scope of its own: a tool is not a panel,
 * it has no icon and no level — it is a module that attaches itself to the running app.
 */
export const STUDIO_TOOLS_SCOPE = 'studioTools';
const loadedTools = new Set();
/**
 * Loads whatever the site project (or one of its dependencies) declares as an editing tool.
 *
 * This is how the master frontend gets an editor without naming the project that provides one. The
 * widget string IS the module path (`_102020_/l2/aura/studio/studioEditTool` ->
 * `/_102020_/l2/aura/studio/studioEditTool.js`), the same shape the services use, and the module
 * registers itself on the slot when it evaluates (studioEditSlot).
 *
 * Best-effort by design: no plugin, no tool, no error — a client app with no Studio simply has no
 * editing tools, which is exactly the intended behaviour.
 */
export async function loadStudioTools(siteProject, api = globalThis.mls, 
// Injected so a test can watch WHICH modules are asked for without a network or a real module.
load = (url) => import(/* @vite-ignore */ url)) {
    const project = siteProject || api?.actualProject || 0;
    if (!project || !api?.plugin?.loadAll || !api.plugin.getAllMenuActions)
        return [];
    const loaded = [];
    for (const candidate of collectScanProjects(project, api)) {
        try {
            await api.stor?.server?.loadProjectInfoIfNeeded?.(candidate);
            await api.plugin.loadAll(candidate, false);
            const actions = api.plugin.getAllMenuActions(candidate, { scope: STUDIO_TOOLS_SCOPE }) ?? [];
            for (const action of actions.sort((a, b) => (a.priority || 1) - (b.priority || 1))) {
                const widget = action?.widget;
                // Same guard as the services: a malformed entry produces requests like /_1_/l2/undefined.js.
                if (!widget || !/^_\d{6,}_/u.test(widget) || loadedTools.has(widget))
                    continue;
                loadedTools.add(widget);
                await load(`/${widget}.js`);
                loaded.push(widget);
            }
        }
        catch (err) {
            console.warn('[studioServices] edit tool scan failed for', candidate, err);
        }
    }
    return loaded;
}
/** Only for tests: forget which tools were already imported. */
export function resetStudioTools() {
    loadedTools.clear();
}
