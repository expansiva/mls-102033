/// <mls fileReference="_102033_/l2/cbe/studioDraft.ts" enhancement="_blank" />
const DRAFT_SLUG = /^(team|user)-[a-z0-9_.-]{1,64}$/;
const USER_DRAFT_TOKEN = 'user';
/// **collab_i18n_start**
const message_en = {
    sessionRequired: 'Sign in to open your draft.',
};
const messages = {
    en: message_en,
    pt: {
        sessionRequired: 'Entre na sua conta para abrir o seu rascunho.',
    },
    es: {
        sessionRequired: 'Inicie sesión para abrir su borrador.',
    },
};
/// **collab_i18n_end**
function draftText(key) {
    const requested = typeof document !== 'undefined' ? document.documentElement.lang || 'en' : 'en';
    const primary = requested.trim().toLowerCase().split('-')[0];
    return (messages[primary] ?? messages.en)[key];
}
function isDraftRequest(slug) {
    return slug === USER_DRAFT_TOKEN || DRAFT_SLUG.test(slug);
}
export function defaultDraftFor(project, defaultDraft) {
    if (defaultDraft !== undefined && DRAFT_SLUG.test(defaultDraft))
        return defaultDraft;
    return USER_DRAFT_TOKEN;
}
export function isVmDriver(driver) {
    const version = driver?.driverVersion;
    return typeof version === 'string' && version.startsWith('1.0.0-vm');
}
function isRecord(value) {
    return !!value && typeof value === 'object';
}
function errorText(err) {
    return err instanceof Error ? err.message : String(err);
}
/** Token the shell sends with `draftEnter`: `studio.defaultDraft` when it is a slug, otherwise `user`. */
export async function resolveDefaultDraft(project, deps) {
    let configured;
    try {
        const conf = await deps.getProjectConf(project);
        configured = conf?.studio?.defaultDraft;
    }
    catch (err) {
        console.warn('[studioDraft] getProjectConf failed; using user draft:', err);
    }
    return defaultDraftFor(project, configured);
}
export function resolveDefaultDraftFromMls(project) {
    const api = mls;
    return resolveDefaultDraft(project, {
        getProjectConf: (prj) => api.l5.getProjectConf(prj),
    });
}
/**
 * `POST /exec` `{action:'draftEnter', project, draft}`.
 * Same request shape as `studioDraftFiles` `postExec`. The server may not be published yet:
 * callers inject `postExec` (tests pass a fake).
 */
export async function postDraftEnter(body) {
    let response;
    try {
        response = await fetch('/exec', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    try {
        return await response.json();
    }
    catch (err) {
        throw new Error(errorText(err));
    }
}
export async function enterDraft(project, slug, deps) {
    if (!Number.isInteger(project) || project < 1) {
        console.error('[studioDraft] draftEnter: invalid project:', project);
        return { statusCode: 400, ok: false };
    }
    if (!isDraftRequest(slug)) {
        console.error('[studioDraft] draftEnter: invalid slug:', slug);
        return { statusCode: 400, ok: false };
    }
    let parsed;
    try {
        parsed = await deps.postExec({ action: 'draftEnter', project, draft: slug });
    }
    catch (err) {
        console.error('[studioDraft] draftEnter failed:', errorText(err));
        return { statusCode: 0, ok: false };
    }
    if (!isRecord(parsed) || parsed.ok !== true) {
        const statusCode = isRecord(parsed) && typeof parsed.statusCode === 'number' ? parsed.statusCode : 0;
        const error = refusalError(parsed);
        console.error('[studioDraft] draftEnter rejected:', statusCode, error ?? '');
        const refused = { statusCode, ok: false };
        if (error)
            refused.error = error;
        return refused;
    }
    const statusCode = typeof parsed.statusCode === 'number' ? parsed.statusCode : 200;
    if (statusCode < 200 || statusCode >= 300) {
        const error = refusalError(parsed);
        console.error('[studioDraft] draftEnter rejected:', statusCode, error ?? '');
        const refused = { statusCode, ok: false };
        if (error)
            refused.error = error;
        return refused;
    }
    const returned = typeof parsed.slug === 'string' && DRAFT_SLUG.test(parsed.slug)
        ? parsed.slug
        : (DRAFT_SLUG.test(slug) ? slug : undefined);
    if (!returned) {
        console.error('[studioDraft] draftEnter: response slug missing');
        return { statusCode, ok: false };
    }
    const response = { statusCode, ok: true, slug: returned };
    if (typeof parsed.head === 'string')
        response.head = parsed.head;
    return response;
}
function refusalError(parsed) {
    if (!isRecord(parsed))
        return undefined;
    if (typeof parsed.msg === 'string' && parsed.msg.length > 0)
        return parsed.msg;
    if (typeof parsed.error === 'string' && parsed.error.length > 0)
        return parsed.error;
    return undefined;
}
function browserServiceWorkerModeDeps() {
    return {
        controller: navigator.serviceWorker?.controller ?? undefined,
        MessageChannel: globalThis.MessageChannel,
    };
}
/** The page has no service worker in control yet (first visit, or none). An expected state, not a failure. */
export class ServiceWorkerUnavailableError extends Error {
}
/** One round-trip on `ports[0]` (MessageChannel). Reply is the mode state, or `"Error: <cause>"`. */
export function sendServiceWorkerMode(message, deps = browserServiceWorkerModeDeps()) {
    const controller = deps.controller;
    if (!controller) {
        return Promise.reject(new ServiceWorkerUnavailableError('service worker controller is not available'));
    }
    const channel = new deps.MessageChannel();
    const timeoutMs = deps.timeoutMs ?? 3000;
    // Node keeps the process alive while a port is open. The browser has no `unref`.
    const nodePort = channel.port1;
    nodePort.unref?.();
    channel.port2.unref?.();
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            channel.port1.close();
            reject(new Error(`service worker ${message.action} timed out`));
        }, timeoutMs);
        channel.port1.onmessage = (event) => {
            clearTimeout(timer);
            channel.port1.close();
            resolve(event.data);
        };
        channel.port1.start();
        try {
            controller.postMessage(message, [channel.port2]);
        }
        catch (err) {
            clearTimeout(timer);
            channel.port1.close();
            reject(err instanceof Error ? err : new Error(errorText(err)));
        }
    });
}
let modeMirror = { mode: 'production' };
export function modeState() {
    const state = { mode: modeMirror.mode };
    if (modeMirror.project !== undefined)
        state.project = modeMirror.project;
    if (modeMirror.draft !== undefined)
        state.draft = modeMirror.draft;
    return state;
}
/** Draft slug while the tab is in studio. Production has none. */
export function activeDraft() {
    if (modeMirror.mode !== 'studio')
        return undefined;
    return modeMirror.draft;
}
/** Replaces the mirror. A production state keeps no draft slug. */
export function rememberCollabMode(state) {
    const next = { mode: state.mode === 'studio' ? 'studio' : 'production' };
    if (typeof state.project === 'number')
        next.project = state.project;
    if (next.mode === 'studio' && typeof state.draft === 'string' && state.draft.length > 0)
        next.draft = state.draft;
    modeMirror = next;
}
function collabModeStateFromReply(reply) {
    if (!isRecord(reply))
        return null;
    if (reply.mode !== 'studio' && reply.mode !== 'production')
        return null;
    const state = { mode: reply.mode };
    if (typeof reply.project === 'number')
        state.project = reply.project;
    if (typeof reply.draft === 'string')
        state.draft = reply.draft;
    return state;
}
/**
 * One service-worker reply applied to the mirror.
 * A failure (`Error`, `"Error: …"`, or an unreadable body) is logged and the tab stays in production.
 */
export function applyRecordedModeReply(reply, reportError) {
    if (reply instanceof Error) {
        reportError(`[studioDraft] getMode: ${reply.message}`);
        rememberCollabMode({ mode: 'production' });
        return modeState();
    }
    if (typeof reply === 'string') {
        reportError(reply);
        rememberCollabMode({ mode: 'production' });
        return modeState();
    }
    const parsed = collabModeStateFromReply(reply);
    if (!parsed) {
        reportError('[studioDraft] getMode: unexpected service worker reply');
        rememberCollabMode({ mode: 'production' });
        return modeState();
    }
    rememberCollabMode(parsed);
    return modeState();
}
/** Boot query `{action:'getMode'}` so the tab is born in the mode the service worker stored. */
export async function loadRecordedMode(deps) {
    let reply;
    try {
        reply = await deps.send({ action: 'getMode' });
    }
    catch (err) {
        if (err instanceof ServiceWorkerUnavailableError) {
            deps.reportWarning(`[studioDraft] getMode: ${err.message}; this tab stays in production`);
            rememberCollabMode({ mode: 'production' });
            return modeState();
        }
        reply = err instanceof Error ? err : new Error(errorText(err));
    }
    const previous = modeState();
    const state = applyRecordedModeReply(reply, deps.reportError);
    if (deps.stillCurrent && !deps.stillCurrent()) {
        rememberCollabMode(previous);
        return modeState();
    }
    return state;
}
/**
 * Studio: `draftEnter`, then `{action:'setMode', mode:'studio', project, draft}`.
 * Production: only `{action:'setMode', mode:'production'}`.
 * A service-worker `"Error: …"` leaves the mode unchanged.
 */
export async function requestModeChange(current, next, deps) {
    let message;
    if (next === 'production') {
        message = { action: 'setMode', mode: 'production' };
    }
    else {
        if (!Number.isInteger(deps.project) || deps.project < 1) {
            deps.reportError(`[shell] setMode: project is not available (${deps.project})`);
            return { mode: current };
        }
        let slug;
        try {
            slug = await deps.resolveDraft(deps.project);
        }
        catch (err) {
            deps.reportError(`[shell] setMode: draft slug failed: ${errorText(err)}`);
            return { mode: current };
        }
        if (!isDraftRequest(slug)) {
            deps.reportError(`[shell] setMode: draft slug is invalid: ${slug}`);
            return { mode: current };
        }
        const entered = await deps.enterDraft(deps.project, slug);
        if (!entered.ok || !entered.slug) {
            if (entered.statusCode === 401 && entered.error === 'draft.session_required') {
                deps.reportError(draftText('sessionRequired'));
            }
            else {
                deps.reportError(`[shell] draftEnter failed: ${entered.statusCode}`);
            }
            return { mode: current };
        }
        message = { action: 'setMode', mode: 'studio', project: deps.project, draft: entered.slug };
    }
    let reply;
    try {
        reply = await deps.sendToServiceWorker(message);
    }
    catch (err) {
        deps.reportError(`[shell] setMode: ${errorText(err)}`);
        return { mode: current };
    }
    if (typeof reply === 'string') {
        deps.reportError(reply);
        return { mode: current };
    }
    const parsed = collabModeStateFromReply(reply);
    if (!parsed || parsed.mode !== next) {
        deps.reportError('[shell] setMode: unexpected service worker reply');
        return { mode: current };
    }
    rememberCollabMode(parsed);
    return { mode: next };
}
export function readCollabModeNotice(data) {
    if (!isRecord(data) || data.type !== 'collab-mode')
        return null;
    if (data.mode !== 'studio' && data.mode !== 'production')
        return null;
    const notice = { mode: data.mode };
    if (typeof data.project === 'number')
        notice.project = data.project;
    if (typeof data.draft === 'string')
        notice.draft = data.draft;
    return notice;
}
/**
 * Mode broadcast from the service worker: the mode to show here. The caller applies it locally and
 * must not call `setMode` (that would echo the change back to the service worker).
 */
export function applyCollabModeNotice(current, data) {
    const notice = readCollabModeNotice(data);
    if (!notice)
        return current;
    rememberCollabMode(notice);
    return notice.mode;
}
