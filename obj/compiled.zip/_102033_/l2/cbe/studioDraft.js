/// <mls fileReference="_102033_/l2/cbe/studioDraft.ts" enhancement="_blank" />
// Default draft cookie for Studio on a VM project. The server reads `collab-draft`
// on /exec (st05); the name and the attribute string are the contract.
import { getRuntimeLanguage } from '/_102033_/l2/shared/languageRuntime.js';
const DRAFT_SLUG = /^(team|user)-[a-z0-9_.-]{1,64}$/;
export function readDraftCookie(cookieString) {
    if (!cookieString)
        return undefined;
    for (const part of cookieString.split(';')) {
        const trimmed = part.trim();
        const eq = trimmed.indexOf('=');
        if (eq <= 0)
            continue;
        if (trimmed.slice(0, eq) !== 'collab-draft')
            continue;
        const value = trimmed.slice(eq + 1).trim();
        return value.length > 0 ? value : undefined;
    }
    return undefined;
}
export function buildDraftCookie(slug, secure) {
    const cookie = `collab-draft=${slug}; Path=/; SameSite=Lax`;
    return secure ? `${cookie}; Secure` : cookie;
}
export function defaultDraftFor(project, defaultDraft) {
    if (defaultDraft !== undefined && DRAFT_SLUG.test(defaultDraft))
        return defaultDraft;
    return `team-${project}`;
}
export function isVmDriver(driver) {
    const version = driver?.driverVersion;
    return typeof version === 'string' && version.startsWith('1.0.0-vm');
}
function currentDraftSlug() {
    return readDraftCookie(document.cookie ?? '') ?? null;
}
export async function ensureDefaultDraftCookie(project) {
    const unchanged = () => ({ slug: currentDraftSlug(), changed: false });
    try {
        const api = mls;
        let driver;
        try {
            driver = await api.stor.others.getDefaultDriver(project);
        }
        catch (err) {
            console.warn('[studioDraft] getDefaultDriver failed; draft cookie not set:', err);
            return unchanged();
        }
        if (!isVmDriver(driver))
            return unchanged();
        const before = currentDraftSlug();
        let configured;
        if (!before) {
            try {
                const conf = await api.l5.getProjectConf(project);
                configured = conf?.studio?.defaultDraft;
            }
            catch (err) {
                console.warn('[studioDraft] getProjectConf failed; using team draft:', err);
            }
        }
        const slug = before ?? defaultDraftFor(project, configured);
        let detail;
        try {
            const response = await fetch('/desenv?draft=' + encodeURIComponent(slug) + '&to=/', { redirect: 'manual', credentials: 'same-origin' });
            const accepted = response.type === 'opaqueredirect' ||
                (response.status >= 200 && response.status < 300) ||
                response.status === 302;
            const after = currentDraftSlug();
            if (accepted && after)
                return { slug: after, changed: before !== after };
            detail = String(response.status);
        }
        catch (err) {
            detail = err instanceof Error ? err.message : String(err);
        }
        console.warn('[studio] rascunho indisponível: ' + detail);
        if (before) {
            try {
                await fetch('/desenv/sair', { redirect: 'manual', credentials: 'same-origin' });
            }
            catch (err) {
                console.warn('[studio] rascunho indisponível: ' + (err instanceof Error ? err.message : String(err)));
            }
        }
        return { slug: null, changed: false };
    }
    catch (err) {
        console.warn('[studioDraft] ensureDefaultDraftCookie failed:', err);
        return { slug: null, changed: false };
    }
}
const DRAFT_NOTICE_TEXT = {
    en: {
        seeing: 'You are seeing the draft {slug}.',
        viewProduction: 'View production',
    },
    pt: {
        seeing: 'Você está vendo o rascunho {slug}.',
        viewProduction: 'Ver a produção',
    },
};
export function draftNotice(cookieString, studioModeOn, path) {
    if (studioModeOn)
        return null;
    const slug = readDraftCookie(cookieString);
    if (!slug)
        return null;
    return { slug, href: '/desenv/sair?to=' + encodeURIComponent(path) };
}
export function draftNoticeText(slug) {
    const language = getRuntimeLanguage(Object.keys(DRAFT_NOTICE_TEXT), document.documentElement.lang || 'en');
    const row = DRAFT_NOTICE_TEXT[language] ?? DRAFT_NOTICE_TEXT.en;
    return {
        seeing: row.seeing.replace('{slug}', slug),
        viewProduction: row.viewProduction,
    };
}
