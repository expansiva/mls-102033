/// <mls fileReference="_102033_/l2/cbe/studioDraftL2.ts" enhancement="_blank" />
// Compile, in this browser, the l2 sources the current draft changed against main.
// The draft text comes from /exec.
// It is applied on the editor model directly: storFile.getContent() would return production,
// except an included path that still has a local copy. That text is getContent(), the same text Save sent.
const DRAFT_SLUG = /^(team|user)-[a-z0-9_.-]{1,64}$/;
const L2_STATUS = new Set(['A', 'M', 'R']);
const L2_IMPORT = /^\/?_(\d+)_\/l2\/(.+?)(\.js)?$/;
/** One cache since st32. The draft copy is the same name with `~<slug>` before `?v=`. */
const DRAFT_CACHE_NAME = 'mls-v2';
/** `/local/_<project>_<path>.js~<slug>?v=<17 digits or sha>`. Production has no `~`. */
const DRAFT_COMPILED_L2_URL = /^\/local\/_(\d+)_(.+)\.js~([^?]+)\?v=([^&]+)$/;
function errorText(err) {
    return err instanceof Error ? err.message : String(err);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/** l2 TypeScript sources, excluding tests and declarations. Folder may be nested. */
function parseL2Ts(path) {
    if (!path.startsWith('l2/') || !path.endsWith('.ts'))
        return undefined;
    if (path.endsWith('.d.ts') || path.endsWith('.test.ts'))
        return undefined;
    const rest = path.slice(3, -3);
    if (rest.length === 0 || rest.startsWith('/') || rest.endsWith('/'))
        return undefined;
    const slash = rest.lastIndexOf('/');
    const folder = slash === -1 ? '' : rest.slice(0, slash);
    const shortName = slash === -1 ? rest : rest.slice(slash + 1);
    if (!shortName || (slash !== -1 && !folder))
        return undefined;
    return { folder, shortName };
}
/** `/_102047_/l2/a/b/c.js` → the stor identity of that l2 source. Anything else → null. */
export function importToL2File(importName) {
    const match = L2_IMPORT.exec(importName);
    if (!match)
        return null;
    const rest = match[2];
    const slash = rest.lastIndexOf('/');
    const folder = slash === -1 ? '' : rest.slice(0, slash);
    const shortName = slash === -1 ? rest : rest.slice(slash + 1);
    if (!shortName || (slash !== -1 && !folder))
        return null;
    return { project: Number(match[1]), folder, shortName };
}
export function draftL2Targets(files) {
    const targets = [];
    for (const file of files) {
        if (!L2_STATUS.has(file.status))
            continue;
        if (!parseL2Ts(file.path))
            continue;
        targets.push(file.path);
    }
    return targets;
}
async function postExec(body) {
    let response;
    try {
        response = await fetch('/exec', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    let parsed;
    try {
        parsed = await response.json();
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    if (!response.ok) {
        const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : `HTTP ${response.status}`;
        throw new Error(msg);
    }
    return parsed;
}
async function requestDraftDiff(project, slug) {
    const parsed = await postExec({ action: 'draftDiff', project, draft: slug, names: true });
    if (!isRecord(parsed) || parsed.status !== 'files' || typeof parsed.head !== 'string' || parsed.head.length === 0) {
        const code = isRecord(parsed) && typeof parsed.code === 'string' ? parsed.code : 'bad response';
        throw new Error(code);
    }
    if (!Array.isArray(parsed.files))
        throw new Error('draftDiff response has no files array');
    const files = [];
    for (const item of parsed.files) {
        if (!isRecord(item) || typeof item.status !== 'string' || typeof item.path !== 'string') {
            throw new Error('draftDiff file entry is invalid');
        }
        const sha = item.sha;
        if (typeof sha !== 'string' && sha !== null)
            throw new Error('draftDiff file entry is invalid');
        files.push({ status: item.status, path: item.path, sha });
    }
    return { head: parsed.head, files };
}
async function requestDraftTexts(project, paths) {
    const texts = new Map();
    if (paths.length === 0)
        return texts;
    const parsed = await postExec({ action: 'getContents', project, shortPaths: [...paths] });
    if (!isRecord(parsed) || parsed.statusCode !== 200 || !Array.isArray(parsed.files)) {
        const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : 'getContents failed';
        throw new Error(msg);
    }
    for (const item of parsed.files) {
        if (!isRecord(item) || typeof item.shortPath !== 'string') {
            console.error('[studioDraftL2] getContents file entry is invalid');
            continue;
        }
        if (typeof item.content !== 'string') {
            console.error(`[studioDraftL2] ${item.shortPath}: getContents missing content`);
            continue;
        }
        texts.set(item.shortPath, item.encoding === 'base64' ? atob(item.content) : item.content);
    }
    return texts;
}
function l2FileBase(project, loc) {
    return {
        project,
        level: 2,
        shortName: loc.shortName,
        folder: loc.folder,
        extension: '.ts',
    };
}
function storFileFor(project, loc) {
    const base = l2FileBase(project, loc);
    const existing = mls.stor.files[mls.stor.getKeyToFile(base)];
    if (existing)
        return existing;
    // Not registered yet (a file the draft added). Identity fields are enough for
    // createModelTS and the cache key; getContent would serve the release.
    const unused = (name) => Promise.reject(new Error(`[studioDraftL2] ${name} is not used`));
    return {
        ...base,
        versionRef: '',
        projectDependencies: null,
        isLocalVersionOutdated: false,
        inLocalStorage: false,
        status: 'nochange',
        hasError: false,
        getContent: () => unused('getContent'),
        getHistory: () => unused('getHistory'),
        getHistoryContent: () => unused('getHistoryContent'),
        saveContentInCacheIfNeed: () => unused('saveContentInCacheIfNeed'),
        getOrCreateModel: () => unused('getOrCreateModel'),
    };
}
export async function applyDraft(project, path, text) {
    const loc = parseL2Ts(path);
    if (!loc)
        throw new Error(`not an l2 source: ${path}`);
    const existing = mls.editor.getModels(project, loc.shortName, loc.folder, 2)?.ts;
    const model = existing ?? await mls.editor.createModelTS(storFileFor(project, loc), text);
    model.model.setValue(text);
    const { setModelEventAny } = await import('/_102027_/l2/libModel.js');
    await setModelEventAny(model, model.storFile);
}
function workerPath(project, loc) {
    return `_${project}_${loc.folder ? `${loc.folder}/` : ''}${loc.shortName}.js`;
}
/** Compiles one l2 source and keeps the bytes. `saveCache` stays false: the worker stores the draft copy. */
export async function compileDraftForWorker(project, path) {
    const loc = parseL2Ts(path);
    if (!loc)
        throw new Error(`not an l2 source: ${path}`);
    const model = mls.editor.getModels(project, loc.shortName, loc.folder, 2)?.ts;
    if (!model)
        throw new Error(`model missing: ${path}`);
    if (model.compilerResults)
        model.compilerResults.modelNeedCompile = true;
    const ok = await mls.l2.typescript.compileAndPostProcess(model, true, false);
    if (!ok)
        return null;
    const version = model.compilerResults?.cacheVersion;
    const content = model.compilerResults?.prodJS;
    if (!version || !content) {
        console.error(`[studioDraftL2] ${path}: compile produced no version or prodJS`);
        return null;
    }
    return { path: workerPath(project, loc), version, content };
}
/** `addIfNeed` posts `{action:'add', path, version, content, contentType}` on `registration.active`. This adds `draft`. */
async function postDraftAdd(message) {
    const sw = globalThis.navigator?.serviceWorker;
    if (!sw || typeof MessageChannel === 'undefined') {
        throw new Error('service workers are not supported in this browser');
    }
    const registration = await sw.ready;
    const worker = registration.active;
    if (!worker)
        throw new Error('no active service worker to receive the message');
    const channel = new MessageChannel();
    const nodePort = channel.port1;
    nodePort.unref?.();
    channel.port2.unref?.();
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            channel.port1.close();
            reject(new Error('service worker add timed out'));
        }, 3000);
        channel.port1.onmessage = (event) => {
            clearTimeout(timer);
            channel.port1.close();
            const data = event.data;
            if (typeof data === 'string' && data.startsWith('Error')) {
                reject(new Error(data));
                return;
            }
            resolve(data);
        };
        try {
            worker.postMessage(message, [channel.port2]);
        }
        catch (err) {
            clearTimeout(timer);
            channel.port1.close();
            reject(err instanceof Error ? err : new Error(errorText(err)));
        }
    });
}
/** `/local/_<project>_….js~<slug>?v=…` of this draft → `l2/….ts`. Production, another slug, another project → undefined. */
function compiledDraftL2Source(project, slug, url) {
    let path = url;
    if (!path.startsWith('/')) {
        try {
            const parsed = new URL(url);
            path = parsed.pathname + parsed.search;
        }
        catch (err) {
            console.error(`[studioDraftL2] ${url}: ${errorText(err)}`);
            return undefined;
        }
    }
    const match = DRAFT_COMPILED_L2_URL.exec(path);
    if (!match || Number(match[1]) !== project || match[3] !== slug || match[4].length === 0)
        return undefined;
    return `l2/${match[2]}.ts`;
}
function browserCaches() {
    return globalThis.caches ?? undefined;
}
/** Drop `~<slug>` l2 entries in `mls-v2` that are no longer in `keep` or a local edit. Production keys stay. */
export async function forgetStaleDraftL2(project, slug, keep, deps = {}) {
    const caches = deps.caches ?? browserCaches();
    const hasLocalEdit = deps.hasLocalEdit ?? defaultHasLocalEdit;
    const count = caches ? await deleteStaleCompiled(project, slug, keep, caches, hasLocalEdit) : 0;
    console.info(`[studioDraftL2] forgot ${count} compiled l2 entries`);
    return count;
}
async function deleteStaleCompiled(project, slug, keep, caches, hasLocalEdit) {
    let names;
    try {
        names = await caches.keys();
    }
    catch (err) {
        console.warn(`[studioDraftL2] forget stale caches: ${errorText(err)}`);
        return 0;
    }
    if (!names.includes(DRAFT_CACHE_NAME))
        return 0;
    let cache;
    try {
        cache = await caches.open(DRAFT_CACHE_NAME);
    }
    catch (err) {
        console.warn(`[studioDraftL2] forget stale ${DRAFT_CACHE_NAME}: ${errorText(err)}`);
        return 0;
    }
    let requests;
    try {
        requests = await cache.keys();
    }
    catch (err) {
        console.warn(`[studioDraftL2] forget stale ${DRAFT_CACHE_NAME}: ${errorText(err)}`);
        return 0;
    }
    let count = 0;
    for (const request of requests) {
        const source = compiledDraftL2Source(project, slug, request.url);
        if (!source || keep.has(source))
            continue;
        let local = false;
        try {
            local = hasLocalEdit(project, source);
        }
        catch (err) {
            console.error(`[studioDraftL2] ${source}: ${errorText(err)}`);
            continue;
        }
        if (local)
            continue;
        try {
            if (await cache.delete(request))
                count += 1;
        }
        catch (err) {
            console.error(`[studioDraftL2] ${request.url}: ${errorText(err)}`);
        }
    }
    return count;
}
/** `getURL` with the draft sha. Studio mode looks up the draft copy before the release copy. */
async function cachedDraftUrl(project, path, sha) {
    const loc = parseL2Ts(path);
    if (!loc) {
        console.error(`[studioDraftL2] ${path}: cache check is not an l2 source`);
        return null;
    }
    return mls.stor.cache.getURL(project, loc.folder || null, loc.shortName, '.js', sha);
}
const defaultPublishDeps = {
    draftDiff: requestDraftDiff,
    readDraftTexts: requestDraftTexts,
    apply: applyDraft,
    compile: compileDraftForWorker,
    postAdd: postDraftAdd,
    hasLocalEdit: defaultHasLocalEdit,
    cachedDraft: cachedDraftUrl,
};
/** CRC of the local source. The service worker stores this as `?v=` so a saved copy is not the cached sha. */
function textCrc(text) {
    const bytes = new TextEncoder().encode(text);
    let crc = 0xffffffff;
    for (const byte of bytes) {
        crc ^= byte;
        for (let bit = 0; bit < 8; bit += 1) {
            const mask = -(crc & 1);
            crc = (crc >>> 1) ^ (0xedb88320 & mask);
        }
    }
    return ((crc ^ 0xffffffff) >>> 0).toString(16).padStart(8, '0');
}
async function defaultReadLocalText(project, path) {
    const loc = parseL2Ts(path);
    if (!loc)
        return null;
    const file = mls.stor.files[mls.stor.getKeyToFile(l2FileBase(project, loc))];
    if (!file)
        return null;
    const content = await file.getContent();
    return typeof content === 'string' ? content : null;
}
async function localTextOf(deps, project, path) {
    const read = deps.readLocalText ?? defaultReadLocalText;
    try {
        const text = await read(project, path);
        if (typeof text !== 'string') {
            console.error(`[studioDraftL2] ${path}: local text is missing`);
            return null;
        }
        return text;
    }
    catch (err) {
        console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
        return null;
    }
}
export async function publishDraftL2(project, slug, deps = defaultPublishDeps, known, include) {
    if (!DRAFT_SLUG.test(slug)) {
        console.error(`[studioDraftL2] ${slug}: draft slug is invalid; versions were not sent`);
        return { sent: 0, keep: null };
    }
    let diff;
    if (known) {
        diff = known;
    }
    else {
        try {
            diff = await deps.draftDiff(project, slug);
        }
        catch (err) {
            console.error(`[studioDraftL2] draftDiff: ${errorText(err)}`);
            return { sent: 0, keep: null };
        }
    }
    const byPath = new Map(diff.files.map((file) => [file.path, file]));
    const included = new Set(include ?? []);
    const keep = new Set(draftL2Targets(diff.files));
    const pending = [];
    for (const path of draftL2Targets(diff.files)) {
        const local = deps.hasLocalEdit(project, path);
        if (local && !included.has(path)) {
            console.info(`[studioDraftL2] ${path}: local edit kept`);
            continue;
        }
        if (local) {
            const localText = await localTextOf(deps, project, path);
            if (localText === null)
                continue;
            const version = textCrc(localText);
            let cached = null;
            try {
                cached = await deps.cachedDraft(project, path, version);
            }
            catch (err) {
                console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
            }
            if (cached)
                continue;
            pending.push({ path, version, localText });
            continue;
        }
        const sha = byPath.get(path)?.sha;
        if (typeof sha !== 'string' || sha.length === 0) {
            console.error(`[studioDraftL2] ${path}: draft sha is missing; compiled copy was not sent`);
            continue;
        }
        let cached = null;
        try {
            cached = await deps.cachedDraft(project, path, sha);
        }
        catch (err) {
            console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
        }
        if (cached)
            continue;
        pending.push({ path, version: sha });
    }
    if (pending.length === 0)
        return { sent: 0, keep };
    const texts = new Map();
    for (const item of pending) {
        if (item.localText !== undefined)
            texts.set(item.path, item.localText);
    }
    const draftPaths = pending.filter((item) => item.localText === undefined).map((item) => item.path);
    if (draftPaths.length > 0) {
        try {
            const read = await deps.readDraftTexts(project, draftPaths);
            for (const [path, text] of read)
                texts.set(path, text);
        }
        catch (err) {
            console.error(`[studioDraftL2] getContents: ${errorText(err)}`);
            if (texts.size === 0)
                return { sent: 0, keep };
        }
    }
    const applied = [];
    for (const item of pending) {
        const text = texts.get(item.path);
        if (text === undefined) {
            console.error(`[studioDraftL2] ${item.path}: getContents missing content`);
            continue;
        }
        try {
            await deps.apply(project, item.path, text);
            applied.push(item);
        }
        catch (err) {
            console.error(`[studioDraftL2] ${item.path}: ${errorText(err)}`);
        }
    }
    let sent = 0;
    for (const item of applied) {
        try {
            const compiled = await deps.compile(project, item.path);
            if (!compiled) {
                console.error(`[studioDraftL2] ${item.path}: compile failed`);
                continue;
            }
            await deps.postAdd({
                action: 'add',
                path: compiled.path,
                version: item.version,
                content: compiled.content,
                contentType: 'application/javascript',
                draft: slug,
            });
            sent += 1;
        }
        catch (err) {
            console.error(`[studioDraftL2] ${item.path}: ${errorText(err)}`);
        }
    }
    return { sent, keep };
}
function defaultHasLocalEdit(project, path) {
    const loc = parseL2Ts(path);
    if (!loc) {
        console.error(`[studioDraftL2] ${path}: local edit check is not an l2 source`);
        return false;
    }
    const base = l2FileBase(project, loc);
    return mls.stor.files[mls.stor.getKeyToFile(base)]?.inLocalStorage === true;
}
