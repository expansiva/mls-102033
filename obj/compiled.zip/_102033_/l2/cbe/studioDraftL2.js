/// <mls fileReference="_102033_/l2/cbe/studioDraftL2.ts" enhancement="_blank" />
// Compile, in this browser, the l2 sources the current draft changed against main.
// The draft text comes from /exec (the collab-draft cookie selects the copy).
// It is applied on the editor model directly: storFile.getContent() would return production.
const MARKER_KEY = 'collabDraftL2Synced';
const L2_STATUS = new Set(['A', 'M', 'R']);
const IMPORT_DEPTH = 3;
const L2_IMPORT = /^\/?_(\d+)_\/l2\/(.+?)(\.js)?$/;
function errorText(err) {
    return err instanceof Error ? err.message : String(err);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/** l2 TypeScript sources, excluding tests and declarations. Folder may be nested. */
function parseL2Ts(path) {
    if (!path.startsWith('l2/') || !path.endsWith('.ts'))
        return undefined;
    if (path.endsWith('.d.ts') || path.endsWith('.test.ts'))
        return undefined;
    const rest = path.slice(3, -3);
    if (rest.length === 0 || rest.startsWith('/') || rest.endsWith('/'))
        return undefined;
    const slash = rest.lastIndexOf('/');
    const folder = slash === -1 ? '' : rest.slice(0, slash);
    const shortName = slash === -1 ? rest : rest.slice(slash + 1);
    if (!shortName || (slash !== -1 && !folder))
        return undefined;
    return { folder, shortName };
}
/** `/_102047_/l2/a/b/c.js` → the stor identity of that l2 source. Anything else → null. */
export function importToL2File(importName) {
    const match = L2_IMPORT.exec(importName);
    if (!match)
        return null;
    const rest = match[2];
    const slash = rest.lastIndexOf('/');
    const folder = slash === -1 ? '' : rest.slice(0, slash);
    const shortName = slash === -1 ? rest : rest.slice(slash + 1);
    if (!shortName || (slash !== -1 && !folder))
        return null;
    return { project: Number(match[1]), folder, shortName };
}
function visitKey(file) {
    return `${file.project}:${file.folder}:${file.shortName}`;
}
export function draftL2Targets(files) {
    const targets = [];
    for (const file of files) {
        if (!L2_STATUS.has(file.status))
            continue;
        if (!parseL2Ts(file.path))
            continue;
        targets.push(file.path);
    }
    return targets;
}
async function postExec(body) {
    let response;
    try {
        response = await fetch('/exec', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    let parsed;
    try {
        parsed = await response.json();
    }
    catch (err) {
        throw new Error(errorText(err));
    }
    if (!response.ok) {
        const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : `HTTP ${response.status}`;
        throw new Error(msg);
    }
    return parsed;
}
async function requestDraftDiff(project, slug) {
    const parsed = await postExec({ action: 'draftDiff', project, draft: slug, names: true });
    if (!isRecord(parsed) || parsed.status !== 'files' || typeof parsed.head !== 'string' || parsed.head.length === 0) {
        const code = isRecord(parsed) && typeof parsed.code === 'string' ? parsed.code : 'bad response';
        throw new Error(code);
    }
    if (!Array.isArray(parsed.files))
        throw new Error('draftDiff response has no files array');
    const files = [];
    for (const item of parsed.files) {
        if (!isRecord(item) || typeof item.status !== 'string' || typeof item.path !== 'string') {
            throw new Error('draftDiff file entry is invalid');
        }
        files.push({ status: item.status, path: item.path });
    }
    return { head: parsed.head, files };
}
async function requestDraftText(project, path) {
    const parsed = await postExec({ action: 'getContents', project, shortPaths: [path] });
    if (!isRecord(parsed) || parsed.statusCode !== 200 || !Array.isArray(parsed.files)) {
        const msg = isRecord(parsed) && typeof parsed.msg === 'string' ? parsed.msg : 'getContents failed';
        throw new Error(msg);
    }
    const file = parsed.files.find((item) => isRecord(item) && item.shortPath === path);
    if (!isRecord(file) || typeof file.content !== 'string')
        throw new Error('getContents missing content');
    return file.encoding === 'base64' ? atob(file.content) : file.content;
}
function l2FileBase(project, loc) {
    return {
        project,
        level: 2,
        shortName: loc.shortName,
        folder: loc.folder,
        extension: '.ts',
    };
}
function storFileFor(project, loc) {
    const base = l2FileBase(project, loc);
    const existing = mls.stor.files[mls.stor.getKeyToFile(base)];
    if (existing)
        return existing;
    // Not registered yet (a file the draft added). Identity fields are enough for
    // createModelTS and the cache key; getContent would serve the release.
    const unused = (name) => Promise.reject(new Error(`[studioDraftL2] ${name} is not used`));
    return {
        ...base,
        versionRef: '',
        projectDependencies: null,
        isLocalVersionOutdated: false,
        inLocalStorage: false,
        status: 'nochange',
        hasError: false,
        getContent: () => unused('getContent'),
        getHistory: () => unused('getHistory'),
        getHistoryContent: () => unused('getHistoryContent'),
        saveContentInCacheIfNeed: () => unused('saveContentInCacheIfNeed'),
        getOrCreateModel: () => unused('getOrCreateModel'),
    };
}
function asModelTS(model) {
    if (model.storFile.extension !== '.ts')
        return undefined;
    return model;
}
async function loadImportModels(model, depth, visited) {
    const key = visitKey(model.storFile);
    if (visited.has(key))
        return;
    visited.add(key);
    if (depth <= 0)
        return;
    let imports = [];
    try {
        await mls.l2.typescript.compileAndPostProcess(model, false, false);
        imports = model.compilerResults?.imports ?? [];
    }
    catch (err) {
        console.warn(`[studioDraftL2] ${key}: ${errorText(err)}`);
        return;
    }
    for (const importName of imports) {
        const info = importToL2File(importName);
        if (!info || visited.has(visitKey(info)))
            continue;
        try {
            const storFile = mls.stor.files[mls.stor.getKeyToFile(l2FileBase(info.project, info))];
            if (!storFile)
                continue;
            const existing = mls.editor.getModels(info.project, info.shortName, info.folder, 2)?.ts;
            const created = existing ?? await storFile.getOrCreateModel();
            const dep = asModelTS(created);
            if (!dep) {
                console.warn(`[studioDraftL2] ${importName}: model is not typescript`);
                continue;
            }
            await loadImportModels(dep, depth - 1, visited);
        }
        catch (err) {
            console.warn(`[studioDraftL2] ${importName}: ${errorText(err)}`);
        }
    }
}
async function applyDraft(project, path, text) {
    const loc = parseL2Ts(path);
    if (!loc)
        throw new Error(`not an l2 source: ${path}`);
    const existing = mls.editor.getModels(project, loc.shortName, loc.folder, 2)?.ts;
    const model = existing ?? await mls.editor.createModelTS(storFileFor(project, loc), text);
    model.model.setValue(text);
}
async function compileDraft(project, path) {
    const loc = parseL2Ts(path);
    if (!loc)
        throw new Error(`not an l2 source: ${path}`);
    const model = mls.editor.getModels(project, loc.shortName, loc.folder, 2)?.ts;
    if (!model)
        throw new Error(`model missing: ${path}`);
    await loadImportModels(model, IMPORT_DEPTH, new Set());
    // The probe compile records this version with modelNeedCompile false (mls.js compile).
    // Without this, the final compile returns the missing-import errors and skips the cache.
    if (model.compilerResults)
        model.compilerResults.modelNeedCompile = true;
    return mls.l2.typescript.compileAndPostProcess(model, true, true);
}
function defaultHasLocalEdit(project, path) {
    const loc = parseL2Ts(path);
    if (!loc) {
        console.error(`[studioDraftL2] ${path}: local edit check is not an l2 source`);
        return false;
    }
    const base = l2FileBase(project, loc);
    return mls.stor.files[mls.stor.getKeyToFile(base)]?.inLocalStorage === true;
}
const defaultDeps = {
    readMarker: () => sessionStorage.getItem(MARKER_KEY),
    writeMarker: (value) => sessionStorage.setItem(MARKER_KEY, value),
    draftDiff: requestDraftDiff,
    readDraftText: requestDraftText,
    apply: applyDraft,
    compile: compileDraft,
    hasLocalEdit: defaultHasLocalEdit,
};
export async function syncDraftL2(project, slug, deps = defaultDeps) {
    let diff;
    try {
        diff = await deps.draftDiff(project, slug);
    }
    catch (err) {
        console.error(`[studioDraftL2] draftDiff: ${errorText(err)}`);
        return { compiled: 0, head: null };
    }
    if (deps.readMarker() === `${slug}@${diff.head}`)
        return { compiled: 0, head: diff.head };
    const targets = draftL2Targets(diff.files);
    const ready = [];
    let failed = false;
    for (const path of targets) {
        if (deps.hasLocalEdit(project, path)) {
            console.info(`[studioDraftL2] ${path}: local edit kept`);
            continue;
        }
        try {
            const text = await deps.readDraftText(project, path);
            await deps.apply(project, path, text);
            ready.push(path);
        }
        catch (err) {
            failed = true;
            console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
        }
    }
    let compiled = 0;
    for (const path of ready) {
        try {
            const ok = await deps.compile(project, path);
            if (!ok) {
                failed = true;
                console.error(`[studioDraftL2] ${path}: compile failed`);
                continue;
            }
            compiled += 1;
        }
        catch (err) {
            failed = true;
            console.error(`[studioDraftL2] ${path}: ${errorText(err)}`);
        }
    }
    if (!failed)
        deps.writeMarker(`${slug}@${diff.head}`);
    return { compiled, head: diff.head };
}
